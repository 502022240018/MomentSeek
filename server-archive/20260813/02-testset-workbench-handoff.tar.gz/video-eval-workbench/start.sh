#!/usr/bin/env bash
set -euo pipefail

ROOT="/home/momentseek-29154/video-eval-workbench"
exec python3 "$ROOT/app.py" --host 127.0.0.1 --port "${PORT:-8791}"
