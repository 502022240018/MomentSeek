#!/usr/bin/env python3
"""Test-set overview module used by the unified workbench service."""

from __future__ import annotations

import argparse
import json
import mimetypes
import re
import socketserver
import subprocess
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, urlparse


APP_ROOT = Path("/home/momentseek-29154/video-eval-workbench")
CATALOG_PATH = APP_ROOT / "catalog" / "testset_summary_catalog.json"
REBUILD_LOCK = threading.Lock()
REBUILD_COMMAND = [
    "python3",
    str(APP_ROOT / "catalog_builder.py"),
    "--workbench-app",
    str(APP_ROOT / "app.py"),
    "--output",
    str(APP_ROOT),
]


HTML = r"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>MomentSeek 测试集总览</title>
  <style>
    :root{color-scheme:light;--bg:#f4f6f8;--panel:#fff;--ink:#17212b;--muted:#667482;--line:#dce3e9;--accent:#176b5b;--accent-soft:#e7f3f0;--blue:#315f9c;--orange:#a45a12;--purple:#7252a2;--danger:#a33843}
    *{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 Inter,"Noto Sans SC","Microsoft YaHei",sans-serif}.top{height:72px;padding:12px 18px;background:#12272d;color:#fff;display:flex;gap:14px;align-items:center;position:sticky;top:0;z-index:20}.brand{min-width:270px;font-size:20px;font-weight:800;letter-spacing:.02em}.brand small{display:block;font-size:11px;font-weight:500;color:#b9d2d5;margin-top:2px}.controls{display:flex;gap:8px;align-items:center;flex:1}.control{height:38px;border:1px solid #3b5056;border-radius:8px;background:#fff;color:#17212b;padding:0 10px;min-width:140px}.search{flex:1;min-width:220px}.shell{display:grid;grid-template-columns:270px minmax(420px,1fr) minmax(400px,46vw);height:calc(100vh - 72px);overflow:hidden}.sidebar,.catalog,.viewer{overflow:auto}.sidebar{padding:14px;border-right:1px solid var(--line);background:#eef2f4}.catalog{padding:14px}.viewer{padding:14px;border-left:1px solid var(--line);background:#edf1f4}.panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;box-shadow:0 1px 2px rgba(19,34,42,.04)}.stats{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px}.stat{padding:10px}.stat span{display:block;color:var(--muted);font-size:11px}.stat strong{display:block;font-size:22px;line-height:1.2;margin-top:2px}.section-title{font-size:12px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);font-weight:800;margin:14px 4px 8px}.type-list{display:grid;gap:6px}.type-button{width:100%;border:1px solid var(--line);border-radius:9px;background:#fff;padding:9px;text-align:left;cursor:pointer}.type-button:hover,.type-button.active{border-color:var(--accent);background:var(--accent-soft)}.type-button strong{display:block;font-size:13px}.type-counts{display:flex;gap:8px;color:var(--muted);font-size:11px;margin-top:3px}.result-head{display:flex;align-items:end;justify-content:space-between;margin-bottom:10px}.result-head h1{font-size:18px;margin:0}.result-head span{color:var(--muted);font-size:12px}.query-list{display:grid;gap:8px}.query-card{overflow:hidden}.query-card summary{list-style:none;cursor:pointer;padding:12px 14px;display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center}.query-card summary::-webkit-details-marker{display:none}.query-card[open] summary{border-bottom:1px solid var(--line);background:#fbfcfd}.query-text{font-size:15px;font-weight:750}.query-meta{color:var(--muted);font-size:11px;margin-top:3px}.counts{text-align:right;color:var(--muted);font-size:11px;white-space:nowrap}.counts strong{display:block;color:var(--ink);font-size:15px}.records{padding:8px;display:grid;gap:7px}.record{border:1px solid var(--line);border-radius:9px;padding:9px;background:#fafbfd}.record-head{display:flex;justify-content:space-between;gap:8px;align-items:flex-start}.record-name{font-weight:700;font-size:12px;overflow-wrap:anywhere}.record-meta{color:var(--muted);font-size:11px;margin-top:2px}.badges{display:flex;gap:4px;flex-wrap:wrap;justify-content:flex-end}.badge{display:inline-block;border-radius:999px;padding:2px 7px;font-size:10px;font-weight:750;background:#edf1f4;color:#45545f}.badge.approved{background:#e7f3f0;color:var(--accent)}.badge.fix{background:#fff0de;color:var(--orange)}.badge.official{background:#e9eef9;color:var(--blue)}.badge.ocr{background:#f1ebfa;color:var(--purple)}.segments{display:flex;gap:6px;flex-wrap:wrap;margin-top:8px}.segment{border:1px solid #b9c8d1;background:#fff;border-radius:7px;padding:5px 8px;cursor:pointer;font:600 11px/1.2 ui-monospace,SFMono-Regular,Consolas,monospace}.segment:hover{border-color:var(--accent);background:var(--accent-soft)}.no-segment{color:var(--danger);font-size:11px;margin-top:7px}.video-panel{position:sticky;top:0;overflow:hidden}.video-panel video{display:block;width:100%;max-height:52vh;background:#0c1114}.video-info{padding:12px}.video-info h2{font-size:16px;margin:0 0 4px;overflow-wrap:anywhere}.video-info p{margin:2px 0;color:var(--muted);font-size:12px}.timebar{display:flex;justify-content:space-between;padding:7px 12px;background:#12272d;color:#d8e8ea;font:600 12px ui-monospace,SFMono-Regular,Consolas,monospace}.empty{padding:28px;text-align:center;color:var(--muted)}.notice{padding:11px 12px;margin-top:10px;font-size:12px;color:#38505b}.source-note{font-size:11px;color:var(--muted);margin-top:9px}.clear{border:0;background:transparent;color:#cfe3e3;cursor:pointer;font-weight:700;padding:8px}.hidden{display:none!important}
    @media(max-width:1100px){.shell{grid-template-columns:240px 1fr}.viewer{position:fixed;right:12px;bottom:12px;width:min(520px,calc(100vw - 24px));height:auto;max-height:76vh;z-index:30;border:1px solid var(--line);border-radius:12px;box-shadow:0 16px 48px rgba(15,32,39,.24)}.viewer.closed{display:none}.top{height:auto;flex-wrap:wrap}.brand{min-width:100%}.shell{height:calc(100vh - 116px)}}
    @media(max-width:720px){.shell{display:block;height:auto}.sidebar{border:0}.catalog{overflow:visible}.controls{flex-wrap:wrap}.control{min-width:calc(50% - 4px)}.search{min-width:100%}.viewer{width:calc(100vw - 16px);right:8px;bottom:8px}.stats{grid-template-columns:repeat(4,1fr)}.stat strong{font-size:17px}}
  </style>
</head>
<body>
  <header class="top">
    <div class="brand">MomentSeek 测试集总览<small id="generated">自有审核数据 + 公开测试集</small></div>
    <div class="controls">
      <a href="/" class="clear">工作台</a>
      <a href="/review" class="clear">统一审核</a>
      <select id="source" class="control"><option value="">全部来源</option><option value="human_reviewed">自有审核数据</option><option value="public_benchmark">公开测试集</option></select>
      <select id="category" class="control"><option value="">全部一级类型</option></select>
      <select id="subcategory" class="control"><option value="">全部子类型</option></select>
      <select id="segmentFilter" class="control"><option value="">全部片段状态</option><option value="with">有片段</option><option value="without">无片段</option></select>
      <input id="search" class="control search" placeholder="搜索 Query、视频、数据集、ID">
      <button id="rebuild" class="control">重新汇总</button>
      <button id="clear" class="clear">清空筛选</button>
    </div>
  </header>
  <main class="shell">
    <aside class="sidebar">
      <div class="stats">
        <div class="panel stat"><span>唯一 Query</span><strong id="statSemantic">0</strong></div>
        <div class="panel stat"><span>Query-视频</span><strong id="statRecords">0</strong></div>
        <div class="panel stat"><span>片段</span><strong id="statSegments">0</strong></div>
        <div class="panel stat"><span>视频</span><strong id="statVideos">0</strong></div>
      </div>
      <div class="section-title">一级 Query 类型</div>
      <div id="typeList" class="type-list"></div>
      <div id="policy" class="panel notice"></div>
    </aside>
    <section class="catalog">
      <div class="result-head"><div><h1>Query—视频—片段</h1><span id="resultSummary"></span></div></div>
      <div id="queryList" class="query-list"></div>
    </section>
    <aside id="viewer" class="viewer closed">
      <div class="panel video-panel">
        <video id="video" controls preload="metadata"></video>
        <div class="timebar"><span>当前时间</span><strong id="clock">00:00:00.000</strong></div>
        <div class="video-info"><h2 id="videoTitle">选择片段开始播放</h2><p id="videoMeta">点击任意时间段即可查看对应视频。</p><p id="segmentMeta"></p></div>
      </div>
    </aside>
  </main>
  <script>
    let DATA=null, GROUPS=[], endTime=null, activeRecord="";
    const $=id=>document.getElementById(id);
    const esc=value=>String(value??"").replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));
    const clock=value=>{const total=Math.max(0,Number(value)||0),h=Math.floor(total/3600),m=Math.floor((total-h*3600)/60),s=total-h*3600-m*60;return `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${s.toFixed(3).padStart(6,"0")}`};
    async function load(){const response=await fetch('/api/catalog'); if(!response.ok) throw new Error(await response.text()); DATA=await response.json(); GROUPS=DATA.groups; buildFilters(); renderTypes(); apply(); $("generated").textContent=`自有审核数据 + 公开测试集 · 更新 ${new Date(DATA.summary.generated_at).toLocaleString()}`; $("policy").innerHTML=`<strong>当前口径</strong><div class="source-note">自有数据仅纳入“通过”和“修正”后的有效结果；公开集不含 ActivityNet Captions。相同最终分类下的同文本 Query 合并展示，多视频片段仍分别保留。</div>`;}
    async function rebuild(){const button=$("rebuild"),label=button.textContent;button.disabled=true;button.textContent="汇总中…";try{const response=await fetch('/api/catalog/rebuild',{method:'POST'});if(!response.ok)throw new Error(await response.text());await load();button.textContent="已更新";setTimeout(()=>button.textContent=label,1200);}catch(error){button.textContent="更新失败";alert(error.message);}finally{button.disabled=false;}}
    function buildFilters(){const categories=[...new Set(GROUPS.map(g=>g.category))].sort(),subs=[...new Set(GROUPS.map(g=>g.subcategory))].sort(); $("category").innerHTML='<option value="">全部一级类型</option>'+categories.map(x=>`<option>${esc(x)}</option>`).join(''); $("subcategory").innerHTML='<option value="">全部子类型</option>'+subs.map(x=>`<option>${esc(x)}</option>`).join('');}
    function filteredGroups(){const source=$("source").value,category=$("category").value,sub=$("subcategory").value,mode=$("segmentFilter").value,q=$("search").value.trim().toLowerCase(); return GROUPS.map(group=>{let records=group.records.filter(r=>!source||r.source_kind===source); if(!records.length||category&&group.category!==category||sub&&group.subcategory!==sub)return null; if(mode==='with')records=records.filter(r=>r.segments.length); if(mode==='without')records=records.filter(r=>!r.segments.length); if(!records.length)return null; const hay=[group.query,group.classification_id,group.category,group.subcategory,...records.flatMap(r=>[r.query_id,r.dataset_title,r.video_name])].join(' ').toLowerCase(); if(q&&!hay.includes(q))return null; return {...group,records,record_count:records.length,segment_count:records.reduce((n,r)=>n+r.segments.length,0),video_count:new Set(records.map(r=>r.record_id)).size};}).filter(Boolean);}
    function apply(){const groups=filteredGroups(),records=groups.flatMap(g=>g.records),segments=records.reduce((n,r)=>n+r.segments.length,0),videos=new Set(records.map(r=>r.dataset_id)); $("statSemantic").textContent=groups.length; $("statRecords").textContent=records.length; $("statSegments").textContent=segments; $("statVideos").textContent=videos.size; $("resultSummary").textContent=`${groups.length} 个唯一 Query · ${records.length} 条视频记录 · ${segments} 个片段`; renderGroups(groups); renderTypes();}
    function renderTypes(){const active=$("category").value,root=$("typeList"); root.innerHTML=DATA.category_distribution.map(row=>`<button class="type-button ${active===row.label?'active':''}" data-category="${esc(row.label)}"><strong>${esc(row.label)}</strong><span class="type-counts"><span>${row.unique_query_count} Query</span><span>${row.record_count} 记录</span><span>${row.segment_count} 片段</span></span></button>`).join(''); root.querySelectorAll('button').forEach(button=>button.onclick=()=>{$("category").value=button.dataset.category;apply();});}
    function sourceBadges(record){const status=record.review_status==='approved'?'approved':record.review_status==='fix'?'fix':'official'; return `<span class="badge ${status}">${esc(record.review_status_label)}</span>${record.subtitle_ocr_available?'<span class="badge ocr">字幕OCR</span>':''}`;}
    function renderGroups(groups){const root=$("queryList"); if(!groups.length){root.innerHTML='<div class="panel empty">没有匹配的 Query</div>';return;} root.innerHTML=groups.map((g,index)=>`<details class="panel query-card" ${groups.length<20||index<3?'open':''}><summary><div><div class="query-text">${esc(g.query)}</div><div class="query-meta">${esc(g.classification_id)} · ${esc(g.category)} · ${esc(g.subcategory)}</div></div><div class="counts"><strong>${g.segment_count} 段</strong>${g.record_count} 条视频记录</div></summary><div class="records">${g.records.map(r=>`<div class="record"><div class="record-head"><div><div class="record-name">${esc(r.video_name||r.dataset_title)}</div><div class="record-meta">${esc(r.dataset_title)} · ${esc(r.query_id)}</div></div><div class="badges">${sourceBadges(r)}</div></div>${r.segments.length?`<div class="segments">${r.segments.map(s=>`<button class="segment" data-record="${esc(r.record_id)}" data-start="${s.start_sec}" data-end="${s.end_sec}" data-query="${esc(g.query)}" data-video="${esc(r.video_name||r.dataset_title)}">${esc(s.time_range)}</button>`).join('')}</div>`:`<div class="no-segment">该有效 Query 当前没有正例片段</div>`}</div>`).join('')}</div></details>`).join(''); root.querySelectorAll('.segment').forEach(button=>button.onclick=()=>play(button.dataset));}
    function play(info){const video=$("video"),url=`/media/catalog-video?record=${encodeURIComponent(info.record)}`,seek=()=>{video.currentTime=Math.max(0,Number(info.start)||0);endTime=Number(info.end);video.play().catch(()=>{});}; if(activeRecord!==info.record){activeRecord=info.record;video.src=url;video.onloadedmetadata=seek;}else seek(); $("viewer").classList.remove('closed'); $("videoTitle").textContent=info.video; $("videoMeta").textContent=info.query; $("segmentMeta").textContent=`播放片段 ${clock(info.start)} – ${clock(info.end)}`;}
    for(const id of ['source','category','subcategory','segmentFilter'])$(id).addEventListener('change',apply); $("search").addEventListener('input',apply); $("rebuild").onclick=rebuild; $("clear").onclick=()=>{for(const id of ['source','category','subcategory','segmentFilter','search'])$(id).value='';apply();}; $("video").addEventListener('timeupdate',()=>{const video=$("video");$("clock").textContent=clock(video.currentTime);if(Number.isFinite(endTime)&&video.currentTime>=endTime){video.pause();endTime=null;}}); load().catch(error=>{$("queryList").innerHTML=`<div class="panel empty">加载失败：${esc(error.message)}</div>`});
  </script>
</body>
</html>"""


def read_catalog() -> dict[str, Any]:
    return json.loads(CATALOG_PATH.read_text(encoding="utf-8"))


def record_media_map(catalog: dict[str, Any]) -> dict[str, Path]:
    mapping = {}
    for group in catalog.get("groups") or []:
        for record in group.get("records") or []:
            path = Path(str(record.get("media_path") or ""))
            if path.is_file():
                mapping[str(record["record_id"])] = path
    return mapping


class ThreadingHTTPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.address_string()} - {fmt % args}")

    def send_bytes(self, body: bytes, content_type: str, status: int = 200) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def send_json(self, payload: Any) -> None:
        self.send_bytes(json.dumps(payload, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def send_video(self, path: Path) -> None:
        size = path.stat().st_size
        range_header = self.headers.get("Range") or ""
        match = re.match(r"bytes=(\d*)-(\d*)", range_header)
        start, end = 0, size - 1
        status = HTTPStatus.OK
        if match:
            start_text, end_text = match.groups()
            if start_text:
                start = int(start_text)
                end = int(end_text) if end_text else min(size - 1, start + 4 * 1024 * 1024 - 1)
            elif end_text:
                start = max(0, size - int(end_text))
            end = min(end, size - 1)
            if start > end or start >= size:
                self.send_error(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                return
            status = HTTPStatus.PARTIAL_CONTENT
        length = end - start + 1
        self.send_response(status)
        self.send_header("Content-Type", mimetypes.guess_type(path.name)[0] or "video/mp4")
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(length))
        if status == HTTPStatus.PARTIAL_CONTENT:
            self.send_header("Content-Range", f"bytes {start}-{end}/{size}")
        self.end_headers()
        with path.open("rb") as handle:
            handle.seek(start)
            remaining = length
            while remaining > 0:
                chunk = handle.read(min(1024 * 1024, remaining))
                if not chunk:
                    break
                self.wfile.write(chunk)
                remaining -= len(chunk)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                self.send_bytes(HTML.encode("utf-8"), "text/html; charset=utf-8")
            elif parsed.path == "/api/catalog":
                self.send_json(read_catalog())
            elif parsed.path == "/api/health":
                catalog = read_catalog()
                self.send_json({"ok": True, "generated_at": catalog["summary"]["generated_at"]})
            elif parsed.path == "/media/video":
                record = (parse_qs(parsed.query).get("record") or [""])[0]
                path = record_media_map(read_catalog()).get(record)
                if not path:
                    self.send_error(HTTPStatus.NOT_FOUND, quote(record))
                    return
                self.send_video(path)
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
        except BrokenPipeError:
            pass
        except Exception as exc:  # noqa: BLE001
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))

    def do_POST(self) -> None:
        if urlparse(self.path).path != "/api/rebuild":
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        try:
            if not REBUILD_LOCK.acquire(blocking=False):
                self.send_error(HTTPStatus.CONFLICT, "A catalog rebuild is already running")
                return
            try:
                completed = subprocess.run(
                    REBUILD_COMMAND,
                    capture_output=True,
                    text=True,
                    timeout=180,
                )
                if completed.returncode != 0:
                    raise RuntimeError(completed.stderr or completed.stdout or "Catalog rebuild failed")
            finally:
                REBUILD_LOCK.release()
            self.send_json({"ok": True, "summary": read_catalog()["summary"]})
        except Exception as exc:  # noqa: BLE001
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8786)
    args = parser.parse_args()
    if not CATALOG_PATH.is_file():
        raise FileNotFoundError(CATALOG_PATH)
    with ThreadingHTTPServer((args.host, args.port), Handler) as server:
        print(f"MomentSeek test-set summary listening on http://{args.host}:{args.port}")
        server.serve_forever()


if __name__ == "__main__":
    main()
