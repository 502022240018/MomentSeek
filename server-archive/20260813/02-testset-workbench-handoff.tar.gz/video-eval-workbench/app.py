from __future__ import annotations

import argparse
import difflib
import fcntl
import hashlib
import json
import math
import mimetypes
import os
import re
import socketserver
import subprocess
import uuid
import zipfile
from collections import Counter
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, quote, urlparse

import overview


APP_ROOT = Path("/home/momentseek-29154/video-eval-workbench")
CONFIG_PATH = APP_ROOT / "config" / "datasets.json"
ASSETS_PATH = APP_ROOT / "config" / "video_assets.json"
REVIEWS_DIR = APP_ROOT / "reviews"
MEDIA_DIR = APP_ROOT / "media"
# Unified datasets are registered explicitly by migrate_legacy_data.py.  Keep
# discovery scoped to a private import directory so the service never silently
# mixes new files into the registry.
QUERY_DIR = APP_ROOT / "imports"
VIDEO_DIR = Path("/home/momentseek-0724/0728/data/video")
CLASSIFICATION_MAP_PATH = Path("/home/momentseek-0724/0728/config/classification_map.json")
TRANSCODE_PROCESSES: dict[str, dict[str, Any]] = {}

DEFAULT_ANNOTATIONS = APP_ROOT / "imports" / "__no_default__.json"
DEFAULT_VIDEO_DIR = VIDEO_DIR


LANDING_HTML = r"""<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>MomentSeek 数据与评测工作台</title><style>
:root{color-scheme:light;--bg:#f3f6f8;--ink:#17212b;--muted:#667482;--line:#dbe3e8;--brand:#13333a;--accent:#176b5b;--blue:#315f9c}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 Inter,"Noto Sans SC","Microsoft YaHei",sans-serif}
header{background:var(--brand);color:#fff;padding:32px max(24px,calc((100vw - 1180px)/2))}header h1{margin:0;font-size:28px}header p{margin:8px 0 0;color:#c5d9dc}
main{max-width:1180px;margin:28px auto;padding:0 20px}.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}.card{display:block;background:#fff;border:1px solid var(--line);border-radius:14px;padding:22px;text-decoration:none;color:inherit;box-shadow:0 4px 18px #16232b0b}.card:hover{border-color:var(--accent);transform:translateY(-1px)}.card strong{display:block;font-size:19px;margin-bottom:7px}.card span{color:var(--muted)}.badge{display:inline-block;margin-top:16px;border-radius:999px;padding:4px 9px;background:#e7f3f0;color:var(--accent);font-weight:700;font-size:12px}.stats{margin-top:20px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:18px;display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.stat small{display:block;color:var(--muted)}.stat b{font-size:24px}.note{margin-top:18px;color:var(--muted)}@media(max-width:800px){.cards,.stats{grid-template-columns:1fr}.card{padding:18px}}
</style></head><body><header><h1>MomentSeek 数据与评测工作台</h1><p>一个入口管理自有标注、公开测试集、测试集总览与导出</p></header><main>
<div class="cards"><a class="card" href="/review?source=human_reviewed"><strong>自有数据审核</strong><span>审核、修正和新增 Query，维护时间片段与分类。</span><i class="badge">原 8766</i></a>
<a class="card" href="/review?source=public_benchmark"><strong>公开测试集</strong><span>浏览 QVHighlights、TVR 等公开数据，和业务数据隔离筛选。</span><i class="badge">原 8767</i></a>
<a class="card" href="/overview"><strong>测试集总览</strong><span>按来源、分类、Query 和片段统一汇总，并播放标准片段。</span><i class="badge">原 8786</i></a></div>
<div class="stats"><div class="stat"><small>全部数据集</small><b id="all">—</b></div><div class="stat"><small>自有数据集</small><b id="human">—</b></div><div class="stat"><small>公开数据集</small><b id="public">—</b></div><div class="stat"><small>测试集 Query</small><b id="queries">—</b></div></div>
<p class="note">兼容迁移阶段：审核结果仍写回原审核 JSON，旧平台保持可回退；统一入口不会改动原始标注 JSON。</p></main><script>
fetch('/api/workbench/health').then(r=>r.json()).then(x=>{document.getElementById('all').textContent=x.datasets.total;document.getElementById('human').textContent=x.datasets.human_reviewed;document.getElementById('public').textContent=x.datasets.public_benchmark;document.getElementById('queries').textContent=x.catalog.semantic_query_count??'—'}).catch(()=>{});
</script></body></html>"""


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def video_files(video_dir: Path) -> list[Path]:
    if not video_dir.exists():
        return []
    return sorted(
        path for path in video_dir.iterdir()
        if path.is_file() and path.suffix.lower() in {".mp4", ".mov", ".m4v", ".webm"}
    )


def video_fingerprint(path: Path) -> dict[str, Any]:
    """Fast, rename-safe content identity: size plus SHA-256 of head and tail."""
    size = path.stat().st_size
    chunk_size = min(1024 * 1024, size)
    import hashlib

    digest = hashlib.sha256()
    with path.open("rb") as handle:
        digest.update(handle.read(chunk_size))
        if size > chunk_size:
            handle.seek(max(0, size - chunk_size))
            digest.update(handle.read(chunk_size))
    return {"size_bytes": size, "sample_sha256": digest.hexdigest()}


def load_assets() -> dict[str, Any]:
    if not ASSETS_PATH.exists():
        return {"schema_version": 1, "assets": {}}
    payload = read_json(ASSETS_PATH)
    if not isinstance(payload.get("assets"), dict):
        payload["assets"] = {}
    return payload


def load_classifications() -> list[dict[str, Any]]:
    if not CLASSIFICATION_MAP_PATH.exists():
        return []
    raw = read_json(CLASSIFICATION_MAP_PATH)
    if not isinstance(raw, dict):
        return []
    rows = []
    for classification_id, item in raw.items():
        if not isinstance(item, dict):
            continue
        rows.append(
            {
                "id": str(classification_id),
                "category": str(item.get("category") or ""),
                "subcategory": str(item.get("subcategory") or ""),
                "enabled": bool(item.get("enabled", True)),
            }
        )
    return sorted(rows, key=lambda item: item["id"])


def save_assets(payload: dict[str, Any]) -> None:
    payload["updated_at"] = datetime.now(timezone.utc).isoformat()
    write_json(ASSETS_PATH, payload)


def locked_update_json(path: Path, default_payload: dict[str, Any], updater: Any) -> dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = path.with_suffix(path.suffix + ".lock")
    with lock_path.open("w", encoding="utf-8") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
        payload = read_json(path) if path.exists() else default_payload
        updated = updater(payload)
        write_json(path, updated)
        fcntl.flock(lock.fileno(), fcntl.LOCK_UN)
        return updated


def slugify(value: str, fallback: str = "dataset") -> str:
    text = re.sub(r"[^0-9A-Za-z_.-]+", "-", value).strip("-._").lower()
    return text or fallback


def normalize_text(value: str) -> str:
    return re.sub(r"[\W_]+", "", value, flags=re.UNICODE).lower()


def unique_id(base: str, existing: set[str]) -> str:
    candidate = base
    index = 2
    while candidate in existing:
        candidate = f"{base}-{index}"
        index += 1
    return candidate


def discover_default_proxy(annotation: dict[str, Any]) -> str:
    video_name = str(annotation.get("video_name") or "")
    if video_name and (MEDIA_DIR / video_name).exists():
        return str(MEDIA_DIR / video_name)
    video_id = str(annotation.get("video_id") or "")
    if video_id:
        slug = slugify(video_id)
        matches = sorted(MEDIA_DIR.glob(f"{slug}*.mp4"))
        if matches:
            return str(matches[0])
    return ""


def is_annotation_json(path: Path) -> bool:
    try:
        data = read_json(path)
    except Exception:
        return False
    return isinstance(data, dict) and isinstance(data.get("annotations"), list)


def make_dataset(
    annotation_path: Path,
    video_dir: Path,
    existing_ids: set[str],
    title: str | None = None,
    dataset_id: str | None = None,
    review_path: Path | None = None,
    proxy_video: Path | None = None,
) -> dict[str, Any]:
    annotation = read_json(annotation_path)
    video_id = str(annotation.get("video_id") or annotation_path.parent.name)
    ds_id = unique_id(slugify(dataset_id or video_id), existing_ids)
    legacy_review = REVIEWS_DIR / f"{ds_id}.review_annotations.json"
    review = review_path or (
        legacy_review if legacy_review.exists() else REVIEWS_DIR / ds_id / "review_annotations.json"
    )
    proxy = str(proxy_video) if proxy_video else discover_default_proxy(annotation)
    return {
        "id": ds_id,
        "title": title or str(annotation.get("video_name") or video_id),
        "annotation_path": str(annotation_path),
        "video_dir": str(video_dir),
        "review_path": str(review),
        "proxy_video": proxy,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


def discover_query_datasets(existing: list[dict[str, Any]]) -> list[dict[str, Any]]:
    known_paths = {str(Path(str(item.get("annotation_path") or "")).resolve()) for item in existing}
    known_ids = {str(item.get("id")) for item in existing if item.get("id")}
    discovered: list[dict[str, Any]] = []
    if not QUERY_DIR.exists():
        return discovered
    for path in sorted(QUERY_DIR.glob("*.json")):
        resolved = str(path.resolve())
        if resolved in known_paths or not is_annotation_json(path):
            continue
        dataset = make_dataset(path, VIDEO_DIR, known_ids)
        known_ids.add(str(dataset["id"]))
        known_paths.add(resolved)
        discovered.append(dataset)
    return discovered


def ensure_config() -> list[dict[str, Any]]:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    REVIEWS_DIR.mkdir(parents=True, exist_ok=True)
    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    if CONFIG_PATH.exists():
        data = read_json(CONFIG_PATH)
        datasets = list(data.get("datasets") or [])
        discovered = discover_query_datasets(datasets)
        if discovered:
            datasets.extend(discovered)
            save_datasets(datasets)
        return datasets
    datasets: list[dict[str, Any]] = []
    datasets.extend(discover_query_datasets(datasets))
    if not datasets and DEFAULT_ANNOTATIONS.exists():
        datasets.append(
            make_dataset(
                DEFAULT_ANNOTATIONS,
                DEFAULT_VIDEO_DIR,
                set(),
                dataset_id="flower_youth_silk_road_ep7",
                review_path=REVIEWS_DIR / "flower_youth_silk_road_ep7.review_annotations.json",
            )
        )
    write_json(CONFIG_PATH, {"schema_version": 1, "datasets": datasets})
    return datasets


def save_datasets(datasets: list[dict[str, Any]]) -> None:
    write_json(CONFIG_PATH, {"schema_version": 1, "datasets": datasets})


def find_dataset(dataset_id: str | None) -> dict[str, Any]:
    datasets = ensure_config()
    if not datasets:
        raise KeyError("No datasets registered.")
    if not dataset_id:
        return datasets[0]
    for dataset in datasets:
        if dataset.get("id") == dataset_id:
            return dataset
    raise KeyError(f"Unknown dataset: {dataset_id}")


def find_video(annotation: dict[str, Any], dataset: dict[str, Any]) -> Path | None:
    asset_id = str(dataset.get("asset_id") or "")
    asset = load_assets().get("assets", {}).get(asset_id, {}) if asset_id else {}
    asset_proxy = str(asset.get("browser_proxy_path") or "")
    if asset_proxy and Path(asset_proxy).exists():
        return Path(asset_proxy)
    proxy = str(dataset.get("proxy_video") or "")
    if proxy and Path(proxy).exists():
        return Path(proxy)
    asset_path_text = str(asset.get("current_video_path") or "")
    if asset_path_text and Path(asset_path_text).exists():
        return Path(asset_path_text)
    assigned = str(dataset.get("video_path") or "")
    if assigned and Path(assigned).exists():
        return Path(assigned)
    video_dir = Path(str(dataset["video_dir"]))
    video_name = str(annotation.get("video_name") or "")
    if video_name and (video_dir / video_name).exists():
        return video_dir / video_name
    candidates = video_files(video_dir)
    video_id = str(annotation.get("video_id") or "")
    if video_id:
        needle = normalize_text(video_id)
        for path in candidates:
            if needle in normalize_text(path.stem):
                return path
    # Original files are sometimes renamed to a shorter title.  Choose a file
    # only when the new name is clearly a substantial part of video_name;
    # never guess between unrelated files.
    name_key = normalize_text(video_name)
    matches: list[tuple[int, Path]] = []
    if len(name_key) >= 8:
        for path in candidates:
            candidate_key = normalize_text(path.stem)
            if len(candidate_key) < 8:
                continue
            source_episodes = set(re.findall(r"第\s*(\d+)\s*期", video_name))
            candidate_episodes = set(re.findall(r"第\s*(\d+)\s*期", path.stem))
            if source_episodes and candidate_episodes and source_episodes != candidate_episodes:
                continue
            if candidate_key in name_key or name_key in candidate_key:
                matches.append((1000 + min(len(candidate_key), len(name_key)), path))
                continue
            ratio = difflib.SequenceMatcher(None, name_key, candidate_key).ratio()
            common = difflib.SequenceMatcher(None, name_key, candidate_key).find_longest_match().size
            if ratio >= 0.68 and common >= 10:
                matches.append((int(ratio * 100) + common, path))
    if matches:
        matches.sort(key=lambda item: (-item[0], str(item[1])))
        if len(matches) == 1 or matches[0][0] > matches[1][0]:
            return matches[0][1]
    return candidates[0] if len(candidates) == 1 else None


def asset_id_for_dataset(dataset: dict[str, Any]) -> str:
    return str(dataset.get("asset_id") or f"vid_{slugify(str(dataset.get('id') or 'video'))}")


def record_video_path(asset: dict[str, Any], path: Path) -> None:
    value = str(path.resolve())
    history = list(asset.get("path_history") or [])
    if value not in history:
        history.append(value)
    asset["path_history"] = history
    asset["current_video_path"] = value
    asset["fingerprint"] = video_fingerprint(path)
    asset["last_seen_at"] = datetime.now(timezone.utc).isoformat()


def ensure_asset_registry() -> dict[str, Any]:
    datasets = ensure_config()
    registry = load_assets()
    assets = registry["assets"]
    datasets_changed = False
    registry_changed = False
    for dataset in datasets:
        asset_id = asset_id_for_dataset(dataset)
        if dataset.get("asset_id") != asset_id:
            dataset["asset_id"] = asset_id
            datasets_changed = True
        asset = assets.get(asset_id)
        if not asset:
            annotation = read_json(Path(str(dataset["annotation_path"])))
            raw_dataset = {**dataset, "proxy_video": ""}
            candidate = find_video(annotation, raw_dataset)
            asset = {
                "id": asset_id,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "annotation_paths": [str(dataset["annotation_path"])],
                "current_video_path": "",
                "path_history": [],
                "fingerprint": None,
                "last_seen_at": None,
            }
            if candidate:
                record_video_path(asset, candidate)
            assets[asset_id] = asset
            registry_changed = True
        elif str(dataset["annotation_path"]) not in list(asset.get("annotation_paths") or []):
            asset["annotation_paths"] = list(asset.get("annotation_paths") or []) + [str(dataset["annotation_path"])]
            registry_changed = True
        if not asset.get("current_video_path"):
            annotation = read_json(Path(str(dataset["annotation_path"])))
            candidate = find_video(annotation, {**dataset, "proxy_video": ""})
            if candidate:
                record_video_path(asset, candidate)
                registry_changed = True
    if datasets_changed:
        save_datasets(datasets)
    if registry_changed:
        save_assets(registry)
    return registry


def scan_asset_paths() -> dict[str, Any]:
    """Reconnect registered assets after files are renamed or moved in known video dirs."""
    registry = ensure_asset_registry()
    datasets = ensure_config()
    candidates: list[Path] = []
    for directory in {str(item.get("video_dir") or "") for item in datasets}:
        candidates.extend(video_files(Path(directory)))
    fingerprints: dict[str, dict[str, Any]] = {}
    for path in candidates:
        fingerprints[str(path.resolve())] = video_fingerprint(path)
    updated: list[str] = []
    missing: list[str] = []
    for asset_id, asset in registry["assets"].items():
        expected = asset.get("fingerprint") or {}
        if not expected:
            missing.append(asset_id)
            continue
        matched = next((Path(path) for path, fp in fingerprints.items() if fp == expected), None)
        if matched:
            before = str(asset.get("current_video_path") or "")
            record_video_path(asset, matched)
            if before != str(matched.resolve()):
                updated.append(asset_id)
        else:
            missing.append(asset_id)
    save_assets(registry)
    return {"updated_asset_ids": updated, "missing_asset_ids": missing, "scanned_files": len(candidates)}


def bind_asset_path(asset_id: str, video_path: Path) -> dict[str, Any]:
    if not video_path.exists() or not video_path.is_file():
        raise FileNotFoundError(video_path)
    registry = ensure_asset_registry()
    asset = registry["assets"].get(asset_id)
    if not asset:
        raise KeyError(f"Unknown asset: {asset_id}")
    record_video_path(asset, video_path)
    save_assets(registry)
    return asset


def rename_asset_file(asset_id: str, new_file_name: str) -> dict[str, Any]:
    """Rename a registered source video and persist its path history together."""
    if not new_file_name or Path(new_file_name).name != new_file_name:
        raise ValueError("请输入文件名，不要包含目录路径")
    registry = ensure_asset_registry()
    asset = registry["assets"].get(asset_id)
    if not asset:
        raise KeyError(f"Unknown asset: {asset_id}")
    source_text = str(asset.get("current_video_path") or "")
    if not source_text:
        raise ValueError("该资产尚未绑定原视频，请先手动绑定")
    source = Path(source_text)
    if not source.exists() or not source.is_file():
        raise FileNotFoundError(source)
    target = source.with_name(new_file_name)
    if target.suffix.lower() != source.suffix.lower():
        raise ValueError(f"文件扩展名必须保持为 {source.suffix}")
    if target == source:
        return asset
    if target.exists():
        raise FileExistsError(f"目标文件已存在：{target.name}")
    source.rename(target)
    try:
        record_video_path(asset, target)
        save_assets(registry)
    except Exception:
        target.rename(source)
        raise
    return asset


def probe_video_codec(path: Path) -> str:
    result = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_name", "-of", "default=noprint_wrappers=1:nokey=1", str(path)],
        capture_output=True,
        text=True,
        check=True,
    )
    return result.stdout.strip().lower()


def refresh_transcodes(registry: dict[str, Any]) -> bool:
    changed = False
    for asset_id, asset in registry["assets"].items():
        state = dict(asset.get("transcode") or {})
        if state.get("status") != "running":
            continue
        process = TRANSCODE_PROCESSES.get(asset_id, {}).get("process")
        exit_code = process.poll() if process else None
        if process is not None and exit_code is None:
            continue
        if process is None:
            try:
                os.kill(int(state.get("pid") or 0), 0)
                continue
            except OSError:
                exit_code = 0
        temporary = Path(str(state.get("temporary_path") or ""))
        output = Path(str(state.get("output_path") or ""))
        if exit_code == 0 and temporary.exists():
            try:
                probe_video_codec(temporary)
                os.replace(temporary, output)
                asset["browser_proxy_path"] = str(output)
                state["status"] = "ready"
                state["completed_at"] = datetime.now(timezone.utc).isoformat()
            except Exception as exc:  # noqa: BLE001
                state["status"] = "failed"
                state["error"] = str(exc)
        else:
            state["status"] = "failed"
            state["error"] = f"ffmpeg exited with code {exit_code}"
        asset["transcode"] = state
        TRANSCODE_PROCESSES.pop(asset_id, None)
        changed = True
    if changed:
        save_assets(registry)
    return changed


def transcode_asset_to_h264(asset_id: str) -> dict[str, Any]:
    registry = ensure_asset_registry()
    refresh_transcodes(registry)
    asset = registry["assets"].get(asset_id)
    if not asset:
        raise KeyError(f"Unknown asset: {asset_id}")
    source_text = str(asset.get("current_video_path") or "")
    source = Path(source_text)
    if not source.exists():
        raise FileNotFoundError("该资产尚未绑定可转码的原视频")
    codec = probe_video_codec(source)
    if codec == "h264":
        asset["transcode"] = {"status": "not_needed", "codec": codec, "message": "原视频已是 H.264"}
        save_assets(registry)
        return asset
    existing = dict(asset.get("transcode") or {})
    if existing.get("status") == "running":
        return asset
    MEDIA_DIR.mkdir(parents=True, exist_ok=True)
    output = MEDIA_DIR / f"{asset_id}.h264-720p.mp4"
    temporary = MEDIA_DIR / f"{asset_id}.h264-720p.pending.mp4"
    log_path = MEDIA_DIR / f"{asset_id}.h264-720p.ffmpeg.log"
    if temporary.exists():
        temporary.unlink()
    command = [
        "ffmpeg", "-y", "-hide_banner", "-stats_period", "5", "-i", str(source),
        "-map", "0:v:0", "-map", "0:a:0?", "-vf", "scale=-2:720",
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "24", "-pix_fmt", "yuv420p",
        "-c:a", "aac", "-b:a", "96k", "-movflags", "+faststart", str(temporary),
    ]
    with log_path.open("wb") as log:
        process = subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT)
    TRANSCODE_PROCESSES[asset_id] = {"process": process}
    asset["transcode"] = {
        "status": "running", "source_codec": codec, "pid": process.pid,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "output_path": str(output), "temporary_path": str(temporary), "log_path": str(log_path),
    }
    save_assets(registry)
    return asset


def public_assets() -> list[dict[str, Any]]:
    registry = ensure_asset_registry()
    refresh_transcodes(registry)
    datasets = ensure_config()
    owners: dict[str, list[dict[str, str]]] = {}
    for dataset in datasets:
        owners.setdefault(asset_id_for_dataset(dataset), []).append(
            {"dataset_id": str(dataset["id"]), "title": str(dataset.get("title") or dataset["id"])}
        )
    rows = []
    for asset_id, asset in sorted(registry["assets"].items()):
        rows.append(
            {
                "id": asset_id,
                "current_video_path": asset.get("current_video_path") or "",
                "path_history": asset.get("path_history") or [],
                "fingerprint": asset.get("fingerprint"),
                "last_seen_at": asset.get("last_seen_at"),
                "browser_proxy_path": asset.get("browser_proxy_path") or "",
                "transcode": asset.get("transcode") or {},
                "datasets": owners.get(asset_id, []),
            }
        )
    return rows


def compact_annotation(dataset: dict[str, Any]) -> dict[str, Any]:
    annotation_path = Path(str(dataset["annotation_path"]))
    annotation = read_json(annotation_path)
    assets = ensure_asset_registry().get("assets", {})
    asset = assets.get(asset_id_for_dataset(dataset), {})
    annotations = list(annotation.get("annotations") or [])
    review = load_review(dataset)
    for added_query in (review.get("added_queries") or {}).values():
        item = dict(added_query)
        item_review = (review.get("items") or {}).get(str(item.get("query_id")), {})
        if item_review.get("segments_override") is True:
            item["segments"] = list(item_review.get("corrected_segments") or [])
        annotations.append(item)
    video_path = find_video(annotation, dataset)
    categories: dict[str, dict[str, Any]] = {}
    total_segments = 0
    for item in annotations:
        key = str(item.get("classification_id") or item.get("category") or "uncategorized")
        bucket = categories.setdefault(
            key,
            {
                "id": str(item.get("classification_id") or ""),
                "label": str(item.get("category") or "未分类"),
                "queries": 0,
                "segments": 0,
            },
        )
        bucket["queries"] += 1
        segment_count = len(item.get("segments") or [])
        bucket["segments"] += segment_count
        total_segments += segment_count
    return {
        "dataset": public_dataset(dataset),
        "asset": {
            "id": asset_id_for_dataset(dataset),
            "current_video_path": asset.get("current_video_path") or "",
            "fingerprint": asset.get("fingerprint"),
            "last_seen_at": asset.get("last_seen_at"),
        },
        "video": {
            "id": annotation.get("video_id"),
            "name": annotation.get("video_name"),
            "duration_sec": annotation.get("video_duration_sec"),
            "duration_time": annotation.get("video_duration_time"),
            "media_url": f"/media/video?dataset={quote(str(dataset['id']))}" if video_path else "",
            "media_exists": bool(video_path),
            "media_file": video_path.name if video_path else "",
            "using_proxy": bool(
                video_path and str(video_path) in {
                    str(dataset.get("proxy_video") or ""),
                    str(asset.get("browser_proxy_path") or ""),
                }
            ),
        },
        "summary": annotation.get("summary") or {},
        "workflow": annotation.get("workflow") or {},
        "quality_check": annotation.get("quality_check") or {},
        "fixed_overlays": annotation.get("fixed_overlays") or [],
        "categories": sorted(categories.values(), key=lambda row: row["id"] or row["label"]),
        "totals": {
            "queries": len(annotations),
            "segments": total_segments,
            "needs_human_review": sum(1 for item in annotations if item.get("needs_human_review")),
            "no_answer": sum(1 for item in annotations if not item.get("segments")),
        },
        "annotations": annotations,
    }


def public_dataset(dataset: dict[str, Any]) -> dict[str, Any]:
    annotation_path = Path(str(dataset["annotation_path"]))
    exists = annotation_path.exists()
    title = str(dataset.get("title") or dataset.get("id") or "")
    details: dict[str, Any] = {}
    if exists:
        try:
            annotation = read_json(annotation_path)
            review = load_review(dataset)
            details = {
                "video_name": annotation.get("video_name"),
                "video_id": annotation.get("video_id"),
                "duration_time": annotation.get("video_duration_time"),
                "query_count": len(annotation.get("annotations") or []) + len(review.get("added_queries") or {}),
                "review_count": len(review.get("items") or {}),
            }
        except Exception:
            details = {}
    asset_id = asset_id_for_dataset(dataset)
    asset = load_assets().get("assets", {}).get(asset_id, {})
    return {
        "id": dataset.get("id"),
        "source_kind": dataset.get("source_kind") or "human_reviewed",
        "asset_id": asset_id,
        "title": title,
        "display_name": dataset.get("display_name") or "",
        "annotation_path": dataset.get("annotation_path"),
        "video_dir": dataset.get("video_dir"),
        "review_path": dataset.get("review_path"),
        "proxy_video": dataset.get("proxy_video") or "",
        "current_video_path": asset.get("current_video_path") or "",
        "annotation_exists": exists,
        **details,
    }


def empty_review(dataset: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": 2,
        "dataset_id": dataset.get("id"),
        "source_annotations": dataset.get("annotation_path"),
        "source_annotation_fingerprint": annotation_file_fingerprint(dataset),
        "review_path": dataset.get("review_path"),
        "updated_at": None,
        "items": {},
        "added_queries": {},
        "stale_count": 0,
        "stale_query_ids": [],
    }


def export_all_reviews() -> bytes:
    from io import BytesIO

    buffer = BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        manifest = []
        for dataset in ensure_config():
            public = public_dataset(dataset)
            review = load_review(dataset)
            dataset_id = str(dataset["id"])
            archive.writestr(
                f"{dataset_id}/review_annotations.json",
                json.dumps(review, ensure_ascii=False, indent=2) + "\n",
            )
            archive.writestr(
                f"{dataset_id}/dataset.json",
                json.dumps(public, ensure_ascii=False, indent=2) + "\n",
            )
            manifest.append(public)
        archive.writestr(
            "manifest.json",
            json.dumps(
                {
                    "exported_at": datetime.now(timezone.utc).isoformat(),
                    "datasets": manifest,
                },
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
        )
    return buffer.getvalue()


def annotation_file_fingerprint(dataset: dict[str, Any]) -> str:
    path = Path(str(dataset["annotation_path"]))
    if not path.exists():
        return ""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def annotation_item_fingerprint(item: dict[str, Any]) -> str:
    segments = []
    for segment in item.get("segments") or []:
        segments.append(
            {
                "start_sec": round(float(segment.get("start_sec") or 0), 3),
                "end_sec": round(float(segment.get("end_sec") or 0), 3),
            }
        )
    payload = {
        "query": str(item.get("query") or ""),
        "classification_id": str(item.get("classification_id") or ""),
        "category": str(item.get("category") or ""),
        "subcategory": str(item.get("subcategory") or ""),
        "segments": segments,
    }
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def stored_added_queries(dataset: dict[str, Any]) -> dict[str, dict[str, Any]]:
    path = Path(str(dataset["review_path"]))
    if not path.exists():
        return {}
    stored = read_json(path)
    added = stored.get("added_queries")
    return dict(added) if isinstance(added, dict) else {}


def annotation_items_by_id(dataset: dict[str, Any]) -> dict[str, dict[str, Any]]:
    annotation = read_json(Path(str(dataset["annotation_path"])))
    items = {
        str(item.get("query_id")): item
        for item in annotation.get("annotations") or []
        if item.get("query_id")
    }
    items.update(stored_added_queries(dataset))
    return items


def load_review(dataset: dict[str, Any]) -> dict[str, Any]:
    path = Path(str(dataset["review_path"]))
    if not path.exists():
        return empty_review(dataset)
    stored = read_json(path)
    stored_items = stored.get("items") if isinstance(stored.get("items"), dict) else {}
    added_queries = stored.get("added_queries") if isinstance(stored.get("added_queries"), dict) else {}
    annotations = annotation_items_by_id(dataset)
    active_items: dict[str, Any] = {}
    stale_query_ids = []
    for query_id, item_review in stored_items.items():
        annotation_item = annotations.get(str(query_id))
        saved_fingerprint = str(item_review.get("source_item_fingerprint") or "")
        current_fingerprint = annotation_item_fingerprint(annotation_item) if annotation_item else ""
        if saved_fingerprint and current_fingerprint == saved_fingerprint:
            active_items[str(query_id)] = item_review
        else:
            stale_query_ids.append(str(query_id))
    review = dict(stored)
    review["schema_version"] = 2
    review["source_annotation_fingerprint"] = annotation_file_fingerprint(dataset)
    review["items"] = active_items
    review["added_queries"] = added_queries
    review["stale_count"] = len(stale_query_ids)
    review["stale_query_ids"] = stale_query_ids
    return review


def parse_range(header: str, size: int) -> tuple[int, int] | None:
    match = re.match(r"bytes=(\d*)-(\d*)$", header.strip())
    if not match:
        return None
    start_text, end_text = match.groups()
    if not start_text and not end_text:
        return None
    if start_text:
        start = int(start_text)
        end = int(end_text) if end_text else size - 1
    else:
        suffix = int(end_text)
        start = max(0, size - suffix)
        end = size - 1
    if start >= size or end < start:
        return None
    return start, min(end, size - 1)


HTML = r"""<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MomentSeek 统一审核</title>
  <style>
    :root { color-scheme: light; --bg:#f6f7f9; --panel:#fff; --soft:#eef2f6; --text:#17202a; --muted:#607080; --line:#d9e0e7; --accent:#0f7b6c; --danger:#b4232f; --warn:#a05a00; }
    * { box-sizing: border-box; }
    [hidden] { display:none !important; }
    body { margin:0; background:var(--bg); color:var(--text); font-family:"Microsoft YaHei", Inter, system-ui, sans-serif; letter-spacing:0; }
    button,input,select,textarea { font:inherit; }
    button { cursor:pointer; }
    .topbar { position:sticky; top:0; z-index:20; display:flex; align-items:center; gap:10px; min-height:64px; padding:10px 16px; background:rgba(246,247,249,.95); border-bottom:1px solid var(--line); backdrop-filter:blur(12px); }
    .brand { min-width:210px; font-weight:600; }
    .brand small { display:block; margin-top:3px; color:var(--muted); font-weight:400; }
    .search { flex:1; min-width:180px; }
    .category-filter { max-width:230px; }
    .input,.select,.btn { min-height:38px; border:1px solid var(--line); border-radius:6px; background:var(--panel); color:var(--text); padding:8px 10px; }
    .btn.primary { background:var(--accent); border-color:var(--accent); color:#fff; }
    .btn.warn { color:var(--warn); border-color:#e3b56d; }
    .btn.danger { color:var(--danger); border-color:#e5a5aa; }
    .layout { display:grid; grid-template-columns:minmax(360px,43vw) minmax(420px,1fr); height:calc(100vh - 64px); min-height:0; overflow:hidden; }
    .left { display:flex; flex-direction:column; height:100%; min-height:0; overflow:hidden; border-right:1px solid var(--line); background:var(--panel); min-width:0; }
    .video-wrap { flex:0 0 auto; padding:16px; border-bottom:1px solid var(--line); }
    video { display:block; width:100%; max-height:42vh; background:#05070a; border-radius:6px; }
    .video-missing { display:grid; place-items:center; min-height:260px; border:1px dashed var(--line); border-radius:6px; color:var(--muted); text-align:center; padding:20px; background:var(--soft); }
    .timeline { position:relative; height:42px; margin-top:12px; border:1px solid var(--line); border-radius:6px; background:linear-gradient(90deg,#e8edf2,#f7f8fa); overflow:hidden; }
    .tick { position:absolute; top:0; bottom:0; min-width:2px; border:0; padding:0; background:rgba(15,123,108,.45); }
    .tick.active { background:var(--danger); box-shadow:0 0 0 2px rgba(180,35,47,.18); }
    .meta-grid { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:8px; padding:12px 16px 16px; border-bottom:1px solid var(--line); }
    .stat { padding:10px; background:var(--soft); border-radius:6px; }
    .stat span { display:block; color:var(--muted); font-size:12px; }
    .stat strong { display:block; margin-top:5px; font-size:18px; font-weight:600; }
    .list { flex:1 1 auto; height:auto; min-height:0; overflow:auto; }
    .row { width:100%; display:grid; grid-template-columns:74px 1fr auto; gap:9px; align-items:start; text-align:left; padding:11px 14px; border:0; border-bottom:1px solid var(--line); background:transparent; color:var(--text); }
    .row:hover,.row.active { background:#eef7f5; }
    .qid { color:var(--muted); font-variant-numeric:tabular-nums; }
    .row-query { overflow:hidden; display:-webkit-box; -webkit-box-orient:vertical; -webkit-line-clamp:2; line-height:1.35; }
    .badge { display:inline-block; padding:3px 6px; border-radius:999px; background:var(--soft); color:var(--muted); font-size:12px; white-space:nowrap; }
    .badge.review { color:var(--warn); background:#fff4df; }
    .badge.done,.badge.approved { color:var(--accent); background:#e3f4f0; }
    .badge.fix,.badge.reject { color:var(--danger); background:#ffe7e9; }
    .right { min-width:0; height:100%; overflow-y:auto; padding:18px; }
    .detail-head { display:flex; align-items:start; justify-content:space-between; gap:18px; margin-bottom:14px; }
    h1 { margin:0; font-size:22px; line-height:1.35; font-weight:600; }
    h2 { margin:0 0 10px; font-size:15px; font-weight:600; }
    .subline { margin-top:8px; color:var(--muted); line-height:1.5; }
    .panel { margin-bottom:14px; padding:14px; border:1px solid var(--line); border-radius:8px; background:var(--panel); }
    .segments { display:grid; gap:8px; }
    .segment { display:grid; grid-template-columns:minmax(140px,1fr) auto auto; align-items:center; gap:8px; padding:9px 10px; border:1px solid var(--line); border-radius:6px; background:#fbfcfd; }
    .segment.active { border-color:var(--danger); }
    .segment-time { font-variant-numeric:tabular-nums; }
    .segment-actions { display:flex; flex-wrap:wrap; justify-content:flex-end; gap:6px; }
    .time-toolbar { display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:8px; color:var(--muted); font-size:13px; }
    .time-toolbar strong { color:var(--text); font-size:15px; font-variant-numeric:tabular-nums; }
    .video-controls { display:flex; align-items:center; gap:7px; margin-top:8px; }
    .video-controls .jump-part { width:62px; min-width:0; }
    .video-controls .jump-second { width:82px; }
    .panel-title { display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .time-editor { display:grid; grid-template-columns:repeat(2,minmax(150px,1fr)); gap:10px; padding:12px; border:1px solid var(--line); border-radius:6px; background:#fbfcfd; }
    .time-editor-actions { grid-column:1 / -1; display:flex; flex-wrap:wrap; gap:8px; }
    .corrected-list { grid-column:1 / -1; display:grid; gap:6px; }
    .corrected-row { display:grid; grid-template-columns:1fr auto; align-items:center; gap:8px; padding:7px 9px; border-radius:5px; background:var(--soft); font-variant-numeric:tabular-nums; }
    .reason-grid { display:flex; flex-wrap:wrap; gap:8px; }
    .reason-option { display:flex; align-items:center; gap:6px; padding:7px 9px; border:1px solid var(--line); border-radius:6px; background:#fff; color:var(--text); }
    .reason-option input { width:auto; min-height:0; margin:0; }
    .shortcut-help { color:var(--muted); font-size:12px; line-height:1.6; }
    .stale-notice { margin-bottom:14px; padding:10px 12px; border:1px solid #e3b56d; border-radius:6px; color:#7a4b00; background:#fff4df; line-height:1.5; }
    .checks { display:grid; grid-template-columns:repeat(2,minmax(220px,1fr)); gap:10px; }
    .field { display:grid; gap:6px; color:var(--muted); font-size:13px; }
    .field select,.field textarea,.field input { width:100%; min-height:38px; padding:8px 10px; border:1px solid var(--line); border-radius:6px; background:#fff; color:var(--text); }
    .field textarea { min-height:82px; resize:vertical; }
    .wide { grid-column:1 / -1; }
    .actions { position:sticky; bottom:0; display:flex; gap:8px; padding:12px 0 0; background:linear-gradient(transparent,var(--bg) 24%); }
    .actions .primary { flex:1; }
    table { width:100%; border-collapse:collapse; font-size:13px; }
    th,td { padding:7px 8px; border-bottom:1px solid var(--line); text-align:left; vertical-align:top; }
    th { color:var(--muted); font-weight:500; }
    .modal-backdrop { position:fixed; inset:0; display:none; place-items:center; background:rgba(17,24,39,.35); z-index:50; padding:20px; }
    .modal-backdrop.open { display:grid; }
    .modal { width:min(760px,100%); background:var(--panel); border-radius:8px; border:1px solid var(--line); padding:16px; box-shadow:0 18px 50px rgba(17,24,39,.22); }
    .form-grid { display:grid; gap:10px; }
    .asset-list { max-height:62vh; overflow:auto; display:grid; gap:10px; }
    .asset-row { border:1px solid var(--line); border-radius:6px; padding:10px; background:#fbfcfd; }
    .asset-row code { display:block; font-size:12px; color:var(--muted); overflow-wrap:anywhere; margin:4px 0; }
    .asset-bind { display:grid; grid-template-columns:1fr auto; gap:8px; margin-top:8px; }
    .toast { position:fixed; left:50%; bottom:22px; transform:translate(-50%,14px); opacity:0; pointer-events:none; padding:10px 14px; border-radius:6px; background:#1f2933; color:white; transition:.18s ease; z-index:60; }
    .toast.show { opacity:1; transform:translate(-50%,0); }
    @media (max-width:980px) { .topbar { align-items:stretch; flex-wrap:wrap; } .brand { min-width:100%; } .layout { display:block; height:auto; overflow:visible; } .left,.right { height:auto; overflow:visible; } .list { flex:none; height:280px; overflow:auto; } .checks { grid-template-columns:1fr; } }
  </style>
</head>
<body>
  <header class="topbar">
    <div class="brand">MomentSeek 统一审核<small id="videoName">加载中</small></div>
    <a href="/" class="btn">工作台</a>
    <a href="/overview" class="btn">测试集总览</a>
    <select id="sourceSelect" class="select" title="按数据来源筛选">
      <option value="">全部来源</option><option value="human_reviewed">自有数据</option><option value="public_benchmark">公开测试集</option>
    </select>
    <select id="datasetSelect" class="select"></select>
    <button id="addQueryBtn" class="btn primary">新增 Query</button>
    <button id="addDatasetBtn" class="btn">添加数据集</button>
    <button id="assetsBtn" class="btn">视频资产</button>
    <input id="search" class="input search" placeholder="搜索 query / 分类 / 时间">
    <select id="categoryFilter" class="select category-filter" title="按一级分类筛选 Query">
      <option value="">全部一级分类</option>
    </select>
    <select id="subcategoryFilter" class="select category-filter" title="按子类筛选 Query">
      <option value="">全部子类</option>
    </select>
    <select id="filter" class="select">
      <option value="all">全部</option><option value="needs_review">需人工复核</option><option value="no_answer">无答案</option><option value="pending">未审核</option><option value="approved">已通过</option><option value="fix">需修正</option><option value="reject">删除</option>
    </select>
    <button id="exportBtn" class="btn">导出</button>
    <button id="exportAllBtn" class="btn">导出全部</button>
    <button id="reloadBtn" class="btn">刷新</button>
  </header>
  <main class="layout">
    <section class="left">
      <div class="video-wrap">
        <video id="video" controls preload="metadata"></video>
        <div id="videoMissing" class="video-missing" hidden>未找到可播放视频文件</div>
        <div class="time-toolbar"><span>当前播放时间</span><strong id="currentTimeMs">00:00:00.000</strong></div>
        <div class="video-controls"><button id="rewind5Btn" type="button" class="btn">−5秒</button><button id="forward5Btn" type="button" class="btn">+5秒</button><input id="jumpHour" class="input jump-part" type="number" min="0" step="1" placeholder="时"><input id="jumpMinute" class="input jump-part" type="number" min="0" max="59" step="1" placeholder="分"><input id="jumpSecond" class="input jump-part jump-second" type="number" min="0" max="59.999" step="0.001" placeholder="秒"><button id="jumpTimeBtn" type="button" class="btn">跳转</button></div>
        <div id="timeline" class="timeline" aria-label="标注时间轴"></div>
      </div>
      <div class="meta-grid">
        <div class="stat"><span>Query</span><strong id="statQueries">0</strong></div>
        <div class="stat"><span>片段</span><strong id="statSegments">0</strong></div>
        <div class="stat"><span>需复核</span><strong id="statNeeds">0</strong></div>
        <div class="stat"><span>进度</span><strong id="statProgress">0%</strong></div>
      </div>
      <div id="list" class="list"></div>
    </section>
    <section class="right">
      <div id="staleNotice" class="stale-notice" hidden></div>
      <div class="detail-head"><div><h1 id="queryTitle">请选择一条标注</h1><div id="queryMeta" class="subline"></div></div><div id="statusBadge" class="badge">pending</div></div>
      <div class="panel"><div class="panel-title"><h2>时间段</h2><span id="segmentModeBadge" class="badge">原标注</span></div><div id="segments" class="segments"></div></div>
      <div class="panel">
        <h2>审核结论</h2>
        <div class="checks">
          <label class="field">Query 是否可作为检索题<select id="query_ok"><option value="">未判断</option><option value="yes">是</option><option value="partial">基本可用但需改写</option><option value="no">否</option></select></label>
          <label class="field">时间段是否准确<select id="segments_ok"><option value="">未判断</option><option value="yes">准确</option><option value="partial">边界需微调</option><option value="no">不准确</option><option value="na">无答案题，不适用</option></select></label>
          <label class="field">覆盖是否全面<select id="coverage_ok"><option value="">未判断</option><option value="yes">全面</option><option value="partial">可能遗漏少量片段</option><option value="no">明显遗漏</option><option value="na">无答案题，不适用</option></select></label>
          <label class="field">分类是否合理<select id="category_ok"><option value="">未判断</option><option value="yes">合理</option><option value="partial">可接受但不理想</option><option value="no">不合理</option></select></label>
          <label class="field">复核建议一级分类<select id="selected_category"><option value="">保持原分类 / 未选择</option></select></label>
          <label class="field">复核建议子类<select id="selected_classification_id"><option value="">请先选择一级分类</option></select></label>
          <label class="field">最终状态<select id="status"><option value="pending">未审核</option><option value="approved">通过</option><option value="fix">需修正</option><option value="reject">删除/不采用</option></select></label>
          <label class="field">建议 query 改写<input id="suggested_query" placeholder="可留空"></label>
          <div class="field wide"><span>结构化修正时间段（保存精度 0.001 秒）</span><div class="time-editor">
            <label class="field">起点（秒）<input id="correctedStart" type="number" min="0" step="0.001" placeholder="例如 12.345"></label>
            <label class="field">终点（秒）<input id="correctedEnd" type="number" min="0" step="0.001" placeholder="例如 18.760"></label>
            <div class="time-editor-actions"><button id="captureStartBtn" type="button" class="btn">当前时间设为起点</button><button id="captureEndBtn" type="button" class="btn">当前时间设为终点</button><button id="addCorrectedSegmentBtn" type="button" class="btn primary">新增时间段</button><button id="cancelSegmentEditBtn" type="button" class="btn" hidden>取消编辑</button><button id="clearCorrectedSegmentsBtn" type="button" class="btn danger">删除全部时间段</button><button id="restoreOriginalSegmentsBtn" type="button" class="btn">恢复原始时间段</button></div>
            <div id="correctedSegments" class="corrected-list"></div>
          </div></div>
          <div class="field wide"><span>修改原因（可多选）</span><div id="reasonCodes" class="reason-grid">
            <label class="reason-option"><input type="checkbox" value="query_mismatch">Query描述错误</label>
            <label class="reason-option"><input type="checkbox" value="wrong_segment">时间定位错误</label>
            <label class="reason-option"><input type="checkbox" value="boundary_inaccurate">边界不准</label>
            <label class="reason-option"><input type="checkbox" value="missing_query">遗漏Query</label>
            <label class="reason-option"><input type="checkbox" value="missing_segment">遗漏片段</label>
            <label class="reason-option"><input type="checkbox" value="duplicate_query">重复Query</label>
            <label class="reason-option"><input type="checkbox" value="category_wrong">分类错误</label>
            <label class="reason-option"><input type="checkbox" value="ocr_error">OCR/字幕错误</label>
            <label class="reason-option"><input type="checkbox" value="low_value">无检索价值</label>
          </div></div>
          <label class="field wide">遗漏或修正时间段<textarea id="missing_segments" placeholder="兼容旧审核记录；新修正建议优先使用上方结构化时间段"></textarea></label>
          <label class="field wide">审核备注<textarea id="notes" placeholder="记录不准确原因、画面证据、是否需全片抽查"></textarea></label>
        </div>
      </div>
      <div class="panel"><h2>分类覆盖</h2><table><thead><tr><th>分类</th><th>Query</th><th>片段</th></tr></thead><tbody id="categoryRows"></tbody></table></div>
      <div class="shortcut-help">快捷键：A 通过并下一条 · F 标记需修正 · R 删除并下一条 · 空格 播放/暂停 · [ / ] 前后微调 40ms · Ctrl+Enter 保存并下一条</div>
      <div class="actions"><button id="prevBtn" class="btn">上一条</button><button id="markFixBtn" class="btn warn">标记需修正</button><button id="saveBtn" class="btn primary">保存并下一条</button><button id="nextBtn" class="btn">下一条</button></div>
    </section>
  </main>
  <div id="queryModal" class="modal-backdrop">
    <div class="modal">
      <h2>新增 Query</h2>
      <div class="form-grid">
        <label class="field">Query 文本<textarea id="newQueryText" placeholder="输入需要补充的检索 Query"></textarea></label>
        <label class="field">一级分类<select id="newQueryCategory"><option value="">请选择一级分类</option></select></label>
        <label class="field">子类<select id="newQueryClassification"><option value="">请先选择一级分类</option></select></label>
        <div class="subline">创建后会自动选中新 Query；请使用时间段编辑器新增、修改或删除片段。原始标注 JSON 不会被改动。</div>
        <div class="actions"><button id="cancelQueryBtn" class="btn">取消</button><button id="createQueryBtn" class="btn primary">创建 Query</button></div>
      </div>
    </div>
  </div>
  <div id="datasetModal" class="modal-backdrop">
    <div class="modal">
      <h2>添加标注数据集</h2>
      <div class="form-grid">
        <label class="field">显示名称<input id="newTitle" placeholder="可留空，默认使用 video_name"></label>
        <label class="field">final_annotations.json 路径<input id="newAnnotations" placeholder="/home/.../final_annotations.json"></label>
        <label class="field">原视频目录<input id="newVideoDir" placeholder="/home/.../data/video"></label>
        <label class="field">H.264 代理视频路径<input id="newProxy" placeholder="可留空；建议放 /home/momentseek-29154/annotation-review/media/"></label>
        <div class="actions"><button id="cancelDatasetBtn" class="btn">取消</button><button id="createDatasetBtn" class="btn primary">添加</button></div>
      </div>
    </div>
  </div>
  <div id="assetModal" class="modal-backdrop">
    <div class="modal">
      <div class="detail-head"><div><h2>视频资产管理</h2><div class="subline">资产 ID 不随改名变化；扫描会用内容指纹找回已改名或移动的视频。</div></div><button id="scanAssetsBtn" class="btn">扫描并重新关联</button></div>
      <div id="assetRows" class="asset-list"></div>
      <div class="actions"><button id="closeAssetsBtn" class="btn primary">完成</button></div>
    </div>
  </div>
  <div id="toast" class="toast"></div>
  <script>
    let ALL_DATASETS=[], DATASETS=[], DATA=null, REVIEW=null, CLASSIFICATIONS=[], filtered=[], selectedIndex=0, selectedQueryId="", activeSegmentId="", currentDataset="", segmentEndSec=null, draftCorrectedSegments=[], editorDirty=false, segmentsOverride=false, editingSegmentIndex=-1;
    const fields=["query_ok","segments_ok","coverage_ok","category_ok","selected_category","selected_classification_id","status","suggested_query","missing_segments","notes"];
    const $=id=>document.getElementById(id);
    function toast(text){const el=$("toast"); el.textContent=text; el.className="toast show"; clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.className="toast",1800);}
    async function api(path, options){const res=await fetch(path, options); if(!res.ok) throw new Error(await res.text()); return res.json();}
    function datasetParam(){return encodeURIComponent(currentDataset || "");}
    function reviewFor(item){const id=item.query_id; if(!REVIEW.items[id]) REVIEW.items[id]={query_id:id,status:"pending",updated_at:null}; return REVIEW.items[id];}
    function itemStatus(item){return reviewFor(item).status || "pending";}
    function effectiveItemSegments(item){const review=REVIEW&&REVIEW.items&&REVIEW.items[item.query_id]; return review&&review.segments_override===true?(review.corrected_segments||[]):(item.segments||[]);}
    function setSelection(index){if(!filtered.length){selectedIndex=0; selectedQueryId=""; return;} selectedIndex=Math.max(0,Math.min(index,filtered.length-1)); selectedQueryId=filtered[selectedIndex].query_id; activeSegmentId=""; segmentEndSec=null;}
    function normalizeSelection(){if(!filtered.length){selectedIndex=0; selectedQueryId=""; return;} const index=filtered.findIndex(item=>item.query_id===selectedQueryId); if(index>=0){selectedIndex=index; return;} setSelection(Math.min(selectedIndex,filtered.length-1));}
    function escapeHtml(text){return String(text).replace(/[&<>"']/g,ch=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[ch]));}
    function statusLabel(v){return {pending:"未审",approved:"通过",fix:"修正",reject:"删除"}[v] || v || "未审";}
    function roundMs(value){return Math.round(Number(value)*1000)/1000;}
    function formatClockMs(value){const total=Math.max(0,Number(value)||0), hour=Math.floor(total/3600), minute=Math.floor((total-hour*3600)/60), second=total-hour*3600-minute*60; return `${String(hour).padStart(2,"0")}:${String(minute).padStart(2,"0")}:${second.toFixed(3).padStart(6,"0")}`;}
    function formatSeconds(value){const total=Number(value)||0, minute=Math.floor(total/60), second=total-minute*60; return `${minute}分${second.toFixed(3).padStart(6,"0")}秒`;}
    function cloneSegments(segments){return (segments||[]).map((segment,index)=>({segment_id:segment.segment_id||`working_${index}`,start_sec:roundMs(segment.start_sec),end_sec:roundMs(segment.end_sec),duration_sec:roundMs(Number(segment.end_sec)-Number(segment.start_sec))}));}
    function resetSegmentEditor(){editingSegmentIndex=-1; editorDirty=false; $("correctedStart").value=""; $("correctedEnd").value=""; $("addCorrectedSegmentBtn").textContent="新增时间段"; $("cancelSegmentEditBtn").hidden=true;}
    function setEditorSegment(start,end,index=-1){if(Number.isFinite(Number(start))) $("correctedStart").value=roundMs(start).toFixed(3); if(Number.isFinite(Number(end))) $("correctedEnd").value=roundMs(end).toFixed(3); editingSegmentIndex=index; editorDirty=false; $("addCorrectedSegmentBtn").textContent=index>=0?"保存时间修改":"新增时间段"; $("cancelSegmentEditBtn").hidden=index<0;}
    function beginSegmentEdit(index){const segment=draftCorrectedSegments[index]; if(!segment) return; setEditorSegment(segment.start_sec,segment.end_sec,index); $("correctedStart").focus(); toast(`正在编辑第 ${index+1} 段`);}
    function markSegmentsChanged(){segmentsOverride=true; $("status").value="fix";}
    function deleteSegment(index){if(!draftCorrectedSegments[index]) return; draftCorrectedSegments.splice(index,1); markSegmentsChanged(); resetSegmentEditor(); renderCorrectedSegments(); renderTimeline(); syncReview(); toast("时间段已删除，保存后写入审核结果");}
    function renderSegmentRows(root){root.innerHTML=""; if(!draftCorrectedSegments.length){root.innerHTML=`<div class="segment"><span>${segmentsOverride?"当前有效时间段为 0 段；保存后表示删除该 Query 的全部原时间段。":"原标注没有时间段，可在下方新增。"}</span><span class="badge ${segmentsOverride?"fix":""}">${segmentsOverride?"已修改":"原标注"}</span><span></span></div>`; return;} draftCorrectedSegments.forEach((segment,index)=>{const start=Number(segment.start_sec)||0,end=Number(segment.end_sec)||start,row=document.createElement("div"); row.className="segment"+(segment.segment_id===activeSegmentId?" active":""); row.innerHTML=`<span class="segment-time">${formatClockMs(start)} – ${formatClockMs(end)}</span><span class="badge">${(end-start).toFixed(3)}s</span><span class="segment-actions"><button type="button" class="btn play-segment">播放</button><button type="button" class="btn edit-segment">编辑</button><button type="button" class="btn danger delete-segment">删除</button></span>`; row.querySelector(".play-segment").onclick=()=>seek(segment); row.querySelector(".edit-segment").onclick=()=>beginSegmentEdit(index); row.querySelector(".delete-segment").onclick=()=>deleteSegment(index); root.appendChild(row);});}
    function renderCorrectedSegments(){renderSegmentRows($("segments")); const item=filtered[selectedIndex]; if(item&&item.needs_human_review&&item.review_reason){const reason=document.createElement("div"); reason.className="segment"; reason.innerHTML=`<span>${escapeHtml(item.review_reason)}</span><span class="badge review">需复核</span><span></span>`; $("segments").appendChild(reason);} $("segmentModeBadge").className=`badge ${segmentsOverride?"fix":""}`; $("segmentModeBadge").textContent=segmentsOverride?`已修改 · ${draftCorrectedSegments.length} 段`:`原标注 · ${draftCorrectedSegments.length} 段`; $("correctedSegments").innerHTML=`<div class="subline">当前有效 ${draftCorrectedSegments.length} 段；可在上方“时间段”列表播放、编辑或删除。${segmentsOverride?" 保存后将整组替换原时间段。":" 尚未改动原时间段。"}</div>`;}
    function commitPendingCorrectedSegment(force=false){if(!force&&!editorDirty) return true; const start=roundMs($("correctedStart").value), end=roundMs($("correctedEnd").value); if(!Number.isFinite(start)||!Number.isFinite(end)||end<=start){toast("修正时间未保存：终点必须大于起点"); return false;} const segment={segment_id:editingSegmentIndex>=0&&draftCorrectedSegments[editingSegmentIndex]?draftCorrectedSegments[editingSegmentIndex].segment_id:`working_${Date.now()}`,start_sec:start,end_sec:end,duration_sec:roundMs(end-start)}; if(editingSegmentIndex>=0&&draftCorrectedSegments[editingSegmentIndex]) draftCorrectedSegments[editingSegmentIndex]=segment; else {const existing=draftCorrectedSegments.findIndex(row=>Math.abs(row.start_sec-start)<.0005&&Math.abs(row.end_sec-end)<.0005); if(existing>=0) draftCorrectedSegments[existing]=segment; else draftCorrectedSegments.push(segment);} draftCorrectedSegments.sort((a,b)=>a.start_sec-b.start_sec); markSegmentsChanged(); resetSegmentEditor(); renderCorrectedSegments(); renderTimeline(); return true;}
    function addCorrectedSegment(){if(!commitPendingCorrectedSegment(true)) return; syncReview(); toast("时间段已保存到当前审核草稿");}
    function renderCategoryOptions(){const select=$("selected_category"), value=select.value, categories=[...new Set(CLASSIFICATIONS.map(item=>item.category))]; select.innerHTML='<option value="">保持原分类 / 未选择</option>'+categories.map(category=>`<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`).join(""); select.value=value;}
    function renderSubcategoryOptions(){const select=$("selected_classification_id"), value=select.value, category=$("selected_category").value, rows=CLASSIFICATIONS.filter(item=>item.category===category); select.innerHTML=category?'<option value="">请选择子类</option>'+rows.map(item=>`<option value="${escapeHtml(item.id)}">${escapeHtml(`${item.id} · ${item.subcategory}${item.enabled?"":"（当前停用）"}`)}</option>`).join(""):'<option value="">请先选择一级分类</option>'; select.value=value;}
    function queryCategoryKey(item){return item.category||"未分类";}
    function querySubcategoryKey(item){return item.classification_id||item.subcategory||"未分类";}
    function renderQuerySubcategoryFilter(){const select=$("subcategoryFilter"), previous=select.value, category=$("categoryFilter").value, counts=new Map(); for(const item of DATA.annotations){if(category&&queryCategoryKey(item)!==category) continue; const key=querySubcategoryKey(item), row=counts.get(key)||{count:0,id:item.classification_id||"",label:item.subcategory||"未分类"}; row.count++; counts.set(key,row);} const rows=[...counts.entries()].sort((a,b)=>(a[1].id||a[1].label).localeCompare(b[1].id||b[1].label,"zh-CN",{numeric:true})); select.innerHTML='<option value="">全部子类</option>'+rows.map(([key,row])=>`<option value="${escapeHtml(key)}">${escapeHtml(`${row.id?row.id+" · ":""}${row.label}（${row.count}）`)}</option>`).join(""); select.value=counts.has(previous)?previous:"";}
    function renderQueryCategoryFilters(){const select=$("categoryFilter"), previous=select.value, counts=new Map(); for(const item of DATA.annotations){const key=queryCategoryKey(item); counts.set(key,(counts.get(key)||0)+1);} const rows=[...counts.entries()].sort((a,b)=>a[0].localeCompare(b[0],"zh-CN",{numeric:true})); select.innerHTML='<option value="">全部一级分类</option>'+rows.map(([category,count])=>`<option value="${escapeHtml(category)}">${escapeHtml(`${category}（${count}）`)}</option>`).join(""); select.value=counts.has(previous)?previous:""; renderQuerySubcategoryFilter();}
    function renderNewQuerySubcategories(){const select=$("newQueryClassification"), previous=select.value, category=$("newQueryCategory").value, rows=CLASSIFICATIONS.filter(item=>item.enabled&&item.category===category); select.innerHTML=category?'<option value="">请选择子类</option>'+rows.map(item=>`<option value="${escapeHtml(item.id)}">${escapeHtml(`${item.id} · ${item.subcategory}`)}</option>`).join(""):'<option value="">请先选择一级分类</option>'; select.value=rows.some(item=>item.id===previous)?previous:"";}
    function renderNewQueryCategories(){const select=$("newQueryCategory"), previous=select.value, categories=[...new Set(CLASSIFICATIONS.filter(item=>item.enabled).map(item=>item.category))]; select.innerHTML='<option value="">请选择一级分类</option>'+categories.map(category=>`<option value="${escapeHtml(category)}">${escapeHtml(category)}</option>`).join(""); select.value=categories.includes(previous)?previous:""; renderNewQuerySubcategories();}
    function openQueryModal(){const item=filtered[selectedIndex]; $("newQueryText").value=""; renderNewQueryCategories(); if(item&&[...$("newQueryCategory").options].some(option=>option.value===item.category)){$("newQueryCategory").value=item.category; renderNewQuerySubcategories(); if([...$("newQueryClassification").options].some(option=>option.value===item.classification_id)) $("newQueryClassification").value=item.classification_id;} $("queryModal").classList.add("open"); $("newQueryText").focus();}
    async function createQuery(){const query=$("newQueryText").value.trim(), classificationId=$("newQueryClassification").value; if(!query){toast("请输入 Query 文本"); return;} if(!classificationId){toast("请选择一级分类和子类"); return;} const button=$("createQueryBtn"); button.disabled=true; try{const result=await api(`/api/queries?dataset=${datasetParam()}`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({query,classification_id:classificationId})}); $("queryModal").classList.remove("open"); $("search").value=""; $("filter").value="all"; $("categoryFilter").value=""; $("subcategoryFilter").value=""; await boot(currentDataset); selectedQueryId=result.query.query_id; applyFilters(); toast("Query 已新增，请继续添加时间段");} finally {button.disabled=false;}}
    async function loadClassifications(){CLASSIFICATIONS=(await api("/api/classifications")).classifications; renderCategoryOptions(); renderSubcategoryOptions(); renderNewQueryCategories();}
    function datasetDisplayName(dataset){return dataset.display_name || (dataset.current_video_path ? (dataset.current_video_path.split("/").pop() || dataset.title || dataset.id) : (dataset.title || dataset.id));}
    function renderDatasetOptions(selectId){const source=$("sourceSelect").value; DATASETS=ALL_DATASETS.filter(d=>!source||d.source_kind===source); $("datasetSelect").innerHTML=DATASETS.map(d=>`<option value="${escapeHtml(d.id)}">${escapeHtml(datasetDisplayName(d))}</option>`).join(""); const requested=selectId||currentDataset; currentDataset=DATASETS.some(d=>d.id===requested)?requested:((DATASETS[0]&&DATASETS[0].id)||""); $("datasetSelect").value=currentDataset;}
    async function loadDatasets(selectId){ALL_DATASETS=(await api("/api/datasets")).datasets; const params=new URLSearchParams(location.search), requestedSource=params.get("source")||""; if(requestedSource&&[...$("sourceSelect").options].some(option=>option.value===requestedSource)) $("sourceSelect").value=requestedSource; renderDatasetOptions(selectId || params.get("dataset") || "");}
    async function boot(selectId){await loadDatasets(selectId); await loadClassifications(); if(!currentDataset){toast("还没有数据集"); return;} DATA=await api(`/api/annotations?dataset=${datasetParam()}`); REVIEW=await api(`/api/review?dataset=${datasetParam()}`); $("videoName").textContent=`${DATA.video.name || DATA.dataset.title || ""} · ${DATA.video.duration_time || ""}${DATA.video.using_proxy ? " · H.264代理" : ""}`; if(DATA.video.media_url){$("video").src=DATA.video.media_url; $("video").hidden=false; $("videoMissing").hidden=true;} else {$("video").removeAttribute("src"); $("video").hidden=true; $("videoMissing").hidden=false;} const stale=Number(REVIEW.stale_count)||0; $("staleNotice").hidden=!stale; $("staleNotice").textContent=stale?`检测到 ${stale} 条其他标注版本的历史审核，因 Query 内容或时间段指纹不一致，已保留在原审核文件中但不会回填到当前版本。`:""; renderCategories(); renderQueryCategoryFilters(); selectedIndex=0; selectedQueryId=""; applyFilters();}
    function applyFilters(){const q=$("search").value.trim().toLowerCase(), filter=$("filter").value, category=$("categoryFilter").value, subcategory=$("subcategoryFilter").value; filtered=DATA.annotations.filter(item=>{const status=itemStatus(item), itemSegments=effectiveItemSegments(item); const text=[item.query_id,item.query,item.classification_id,item.category,item.subcategory,...itemSegments.map(s=>s.time_range||`${s.start_sec||""} ${s.end_sec||""}`)].join(" ").toLowerCase(); if(q&&!text.includes(q)) return false; if(category&&queryCategoryKey(item)!==category) return false; if(subcategory&&querySubcategoryKey(item)!==subcategory) return false; if(filter==="all") return true; if(filter==="needs_review") return item.needs_human_review; if(filter==="no_answer") return !itemSegments.length; return status===filter;}); normalizeSelection(); renderList(); renderDetail(); renderStats();}
    function renderStats(){const statuses=DATA.annotations.map(item=>itemStatus(item)); const done=statuses.filter(s=>s!=="pending").length; $("statQueries").textContent=DATA.totals.queries; $("statSegments").textContent=DATA.totals.segments; $("statNeeds").textContent=DATA.totals.needs_human_review; $("statProgress").textContent=`${DATA.annotations.length?Math.round(done/DATA.annotations.length*100):0}%`;}
    function renderTimeline(){const root=$("timeline"); root.innerHTML=""; const duration=Number(DATA.video.duration_sec)||0; for(const item of DATA.annotations){const itemSegments=item.query_id===selectedQueryId?draftCorrectedSegments:(item.segments||[]); for(const seg of itemSegments){const start=Number(seg.start_sec)||0, end=Number(seg.end_sec)||start+1; const tick=document.createElement("button"); tick.className="tick"+(seg.segment_id===activeSegmentId?" active":""); tick.style.left=`${duration?start/duration*100:0}%`; tick.style.width=`${duration?Math.max(.15,(end-start)/duration*100):.2}%`; tick.title=`${item.query_id} ${formatClockMs(start)} – ${formatClockMs(end)}`; tick.onclick=()=>{const index=filtered.findIndex(row=>row.query_id===item.query_id); if(index>=0){if(item.query_id!==selectedQueryId){setSelection(index); renderList(); renderDetail();} seek(seg);}}; root.appendChild(tick);}}}
    function renderList(){const root=$("list"); root.innerHTML=""; if(!filtered.length){root.innerHTML='<div class="row"><span></span><span class="row-query">没有匹配项</span><span></span></div>'; return;} filtered.forEach((item,index)=>{const row=document.createElement("button"); row.className="row"+(item.query_id===selectedQueryId?" active":""); row.onclick=()=>{setSelection(index); renderList(); renderDetail();}; const status=itemStatus(item), shortId=item.manual_added?"人工":(item.query_id?item.query_id.replace(/^.*_q/,"q"):""), segmentCount=effectiveItemSegments(item).length; row.innerHTML=`<span class="qid">${escapeHtml(shortId)}</span><span><span class="row-query">${escapeHtml(item.query||"")}</span><span class="subline">${item.manual_added?"人工新增 · ":""}${escapeHtml(item.classification_id||"")} · ${segmentCount} 段</span></span><span class="badge ${status}">${statusLabel(status)}</span>`; root.appendChild(row);}); const active=root.querySelector(".row.active"); if(active) active.scrollIntoView({block:"nearest"});}
    function renderDetail(){
      const item=filtered[selectedIndex]; if(!item) return;
      const review=reviewFor(item);
      $("queryTitle").textContent=item.query||item.query_id||"";
      $("queryMeta").textContent=[item.manual_added?"人工新增":null,item.query_id,item.classification_id,item.category,item.subcategory,`置信度 ${item.confidence??"-"}`].filter(Boolean).join(" · ");
      $("statusBadge").className=`badge ${review.status||"pending"}`; $("statusBadge").textContent=statusLabel(review.status||"pending");
      for(const field of fields) $(field).value=review[field] || (field==="status"?"pending":"");
      const selectedId=review.selected_classification_id || item.classification_id || "", selected=CLASSIFICATIONS.find(row=>row.id===selectedId); $("selected_category").value=review.selected_category || (selected&&selected.category) || ""; renderSubcategoryOptions(); $("selected_classification_id").value=selectedId;
      const hasSavedOverride=review.segments_override===true||review.corrected_segments_mode==="replace"||Array.isArray(review.corrected_segments)&&review.corrected_segments.length>0; segmentsOverride=hasSavedOverride; draftCorrectedSegments=cloneSegments(hasSavedOverride?review.corrected_segments:item.segments); resetSegmentEditor(); renderCorrectedSegments();
      const reasonCodes=new Set(review.reason_codes||[]); $("reasonCodes").querySelectorAll('input[type="checkbox"]').forEach(input=>input.checked=reasonCodes.has(input.value));
      renderTimeline();
    }
    function renderCategories(){$("categoryRows").innerHTML=DATA.categories.map(item=>`<tr><td>${escapeHtml(item.id?`${item.id} · ${item.label}`:item.label)}</td><td>${item.queries}</td><td>${item.segments}</td></tr>`).join("");}
    function syncReview(){const item=filtered[selectedIndex]; if(!item) return null; const review=reviewFor(item); for(const field of fields) review[field]=$(field).value; const selected=CLASSIFICATIONS.find(row=>row.id===review.selected_classification_id); review.selected_category=selected?selected.category:""; review.selected_subcategory=selected?selected.subcategory:""; review.segments_override=segmentsOverride; review.corrected_segments=segmentsOverride?draftCorrectedSegments.map(segment=>({...segment})):[]; review.corrected_segments_mode=segmentsOverride?"replace":"inherit"; review.reason_codes=[...$("reasonCodes").querySelectorAll('input[type="checkbox"]:checked')].map(input=>input.value); review.query_id=item.query_id; review.updated_at=new Date().toISOString(); return review;}
    async function save(next=false){if(!commitPendingCorrectedSegment(false)) return false; const oldPosition=selectedIndex, review=syncReview(); if(!review) return false; const savedId=review.query_id; REVIEW=await api(`/api/review?dataset=${datasetParam()}`,{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({query_id:review.query_id,review})}); toast("已保存"); applyFilters(); if(next&&filtered.length){const stillVisible=filtered.findIndex(item=>item.query_id===savedId); setSelection(stillVisible>=0?Math.min(stillVisible+1,filtered.length-1):Math.min(oldPosition,filtered.length-1)); renderList(); renderDetail();} return true;}
    async function exportAfterSave(url){if(await save(false)) location.href=url;}
    async function markFix(){$("status").value="fix"; await save(false);}
    function seek(seg){const video=$("video"), start=Number(seg.start_sec), end=Number(seg.end_sec); activeSegmentId=seg.segment_id||""; segmentEndSec=Number.isFinite(end)&&end>start?end:null; if(!video.hidden&&Number.isFinite(start)){video.currentTime=Math.max(0,start); video.play().catch(()=>{});} renderTimeline(); renderCorrectedSegments();}
    function deleteAllSegments(){if(draftCorrectedSegments.length&&!confirm("确定删除当前 Query 的全部时间段吗？可用“恢复原始时间段”撤销。")) return; draftCorrectedSegments=[]; markSegmentsChanged(); resetSegmentEditor(); renderCorrectedSegments(); renderTimeline(); syncReview(); toast("已删除全部时间段，保存后生效");}
    function restoreOriginalSegments(){const item=filtered[selectedIndex]; if(!item) return; draftCorrectedSegments=cloneSegments(item.segments); segmentsOverride=false; resetSegmentEditor(); renderCorrectedSegments(); renderTimeline(); syncReview(); toast("已恢复原始标注时间段，保存后生效");}
    function setVideoTime(seconds){const video=$("video"); if(video.hidden){toast("当前数据集没有可播放视频"); return;} const duration=Number.isFinite(video.duration)?video.duration:Number(DATA.video.duration_sec)||Infinity; video.currentTime=Math.max(0,Math.min(Number(seconds)||0,duration)); segmentEndSec=null; updateCurrentTime();}
    function nudgeVideo(seconds){setVideoTime(Number($("video").currentTime||0)+seconds);}
    function jumpToSpecifiedTime(){const hourText=$("jumpHour").value,minuteText=$("jumpMinute").value,secondText=$("jumpSecond").value; if(!hourText&&!minuteText&&!secondText){toast("请分别填写时、分、秒"); return;} const hour=Number(hourText||0),minute=Number(minuteText||0),second=Number(secondText||0); if(!Number.isFinite(hour)||!Number.isFinite(minute)||!Number.isFinite(second)||hour<0||minute<0||minute>=60||second<0||second>=60){toast("时间格式无效：分和秒需在 0–59 之间"); return;} setVideoTime(hour*3600+minute*60+second);}
    async function createDataset(){const payload={title:$("newTitle").value.trim(),annotation_path:$("newAnnotations").value.trim(),video_dir:$("newVideoDir").value.trim(),proxy_video:$("newProxy").value.trim()}; const result=await api("/api/datasets",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify(payload)}); $("datasetModal").classList.remove("open"); toast("数据集已添加"); await boot(result.dataset.id);}
    async function loadAssets(){const result=await api("/api/assets"); const root=$("assetRows"); root.innerHTML=""; for(const asset of result.assets){const row=document.createElement("div"); row.className="asset-row"; const annotationNames=(asset.datasets||[]).map(item=>item.title).join("；")||"未关联数据集"; const displayName=asset.current_video_path?(asset.current_video_path.split("/").pop()||annotationNames):annotationNames; const rename=asset.current_video_path?`<div class="asset-bind"><input class="input rename-input" placeholder="新文件名，例如 ep7_final.mp4"><button class="btn warn rename-btn">重命名原文件</button></div>`:""; const state=asset.transcode||{}, stateText={running:"正在生成 H.264 兼容版",ready:"H.264 兼容版已就绪",not_needed:"原视频已是 H.264",failed:"转码失败，请重试"}[state.status]||""; const transcode=asset.current_video_path?`<div class="asset-bind"><span class="subline">${escapeHtml(stateText)}</span><button class="btn transcode-btn" ${state.status==="running"?"disabled":""}>生成 H.264 兼容版</button></div>`:""; row.innerHTML=`<strong>${escapeHtml(displayName)}</strong><code>${escapeHtml(asset.id)}</code><div class="subline">标注标题：${escapeHtml(annotationNames)}</div><div class="subline">${asset.current_video_path?`当前：${escapeHtml(asset.current_video_path)}`:"尚未绑定原视频"}</div><div class="asset-bind"><input class="input bind-input" placeholder="输入当前原视频绝对路径后绑定"><button class="btn primary bind-btn">保存关联</button></div>${rename}${transcode}`; const input=row.querySelector(".bind-input"); input.value=asset.current_video_path||""; row.querySelector(".bind-btn").onclick=async()=>{await api("/api/assets/bind",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({asset_id:asset.id,video_path:input.value.trim()})}); toast("视频关联已保存"); await loadAssets(); await boot(currentDataset);}; const renameInput=row.querySelector(".rename-input"); if(renameInput){renameInput.value=asset.current_video_path.split("/").pop()||""; row.querySelector(".rename-btn").onclick=async()=>{const name=renameInput.value.trim(); if(!name||!confirm(`确定将原文件改名为：${name}？`)) return; await api("/api/assets/rename",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({asset_id:asset.id,new_file_name:name})}); toast("原文件已重命名，历史已保留"); await loadAssets(); await boot(currentDataset);};} const transcodeBtn=row.querySelector(".transcode-btn"); if(transcodeBtn){transcodeBtn.onclick=async()=>{await api("/api/assets/transcode-h264",{method:"POST",headers:{"content-type":"application/json"},body:JSON.stringify({asset_id:asset.id})}); toast("已开始生成 H.264 兼容版，可稍后刷新查看状态"); await loadAssets();};} root.appendChild(row);}}
    async function scanAssets(){const result=await api("/api/assets/scan",{method:"POST",headers:{"content-type":"application/json"},body:"{}"}); toast(`已扫描 ${result.scanned_files} 个视频，更新 ${result.updated_asset_ids.length} 个关联`); await loadAssets(); await boot(currentDataset);}
    $("sourceSelect").onchange=()=>{renderDatasetOptions(""); history.replaceState(null,"",`/review?source=${encodeURIComponent($("sourceSelect").value)}`); if(currentDataset) boot(currentDataset);};
    $("datasetSelect").onchange=()=>{currentDataset=$("datasetSelect").value; history.replaceState(null,"",`/review?source=${encodeURIComponent($("sourceSelect").value)}&dataset=${encodeURIComponent(currentDataset)}`); boot(currentDataset);};
    $("search").oninput=applyFilters; $("filter").onchange=applyFilters; $("categoryFilter").onchange=()=>{renderQuerySubcategoryFilter(); applyFilters();}; $("subcategoryFilter").onchange=applyFilters; $("reloadBtn").onclick=()=>boot(currentDataset); $("exportBtn").onclick=()=>exportAfterSave(`/api/review/export?dataset=${datasetParam()}`).catch(err=>toast(err.message)); $("exportAllBtn").onclick=()=>exportAfterSave("/api/review/export-all").catch(err=>toast(err.message)); $("saveBtn").onclick=()=>save(true); $("markFixBtn").onclick=markFix; $("prevBtn").onclick=()=>{setSelection(selectedIndex-1); renderList(); renderDetail();}; $("nextBtn").onclick=()=>{setSelection(selectedIndex+1); renderList(); renderDetail();};
    $("addQueryBtn").onclick=openQueryModal; $("cancelQueryBtn").onclick=()=>$("queryModal").classList.remove("open"); $("createQueryBtn").onclick=()=>createQuery().catch(err=>toast(err.message)); $("newQueryCategory").onchange=renderNewQuerySubcategories;
    $("addDatasetBtn").onclick=()=>$("datasetModal").classList.add("open"); $("cancelDatasetBtn").onclick=()=>$("datasetModal").classList.remove("open"); $("createDatasetBtn").onclick=()=>createDataset().catch(err=>toast(err.message));
    $("assetsBtn").onclick=()=>{ $("assetModal").classList.add("open"); loadAssets().catch(err=>toast(err.message)); }; $("closeAssetsBtn").onclick=()=>$("assetModal").classList.remove("open"); $("scanAssetsBtn").onclick=()=>scanAssets().catch(err=>toast(err.message)); $("selected_category").onchange=()=>{renderSubcategoryOptions(); syncReview();};
    $("captureStartBtn").onclick=()=>{$("correctedStart").value=roundMs($("video").currentTime).toFixed(3); editorDirty=true;};
    $("captureEndBtn").onclick=()=>{$("correctedEnd").value=roundMs($("video").currentTime).toFixed(3); editorDirty=true;};
    $("addCorrectedSegmentBtn").onclick=addCorrectedSegment;
    $("cancelSegmentEditBtn").onclick=resetSegmentEditor; $("clearCorrectedSegmentsBtn").onclick=deleteAllSegments; $("restoreOriginalSegmentsBtn").onclick=restoreOriginalSegments;
    $("correctedStart").addEventListener("input",()=>editorDirty=true); $("correctedEnd").addEventListener("input",()=>editorDirty=true);
    $("rewind5Btn").onclick=()=>nudgeVideo(-5); $("forward5Btn").onclick=()=>nudgeVideo(5); $("jumpTimeBtn").onclick=jumpToSpecifiedTime; for(const id of ["jumpHour","jumpMinute","jumpSecond"]){$(id).addEventListener("keydown",event=>{if(event.key==="Enter"){event.preventDefault(); jumpToSpecifiedTime();}});}
    function updateCurrentTime(){$("currentTimeMs").textContent=formatClockMs($("video").currentTime);}
    $("video").addEventListener("timeupdate",()=>{const video=$("video"); updateCurrentTime(); if(segmentEndSec!==null&&video.currentTime>=segmentEndSec){video.pause(); video.currentTime=segmentEndSec; segmentEndSec=null; updateCurrentTime();}});
    $("video").addEventListener("seeking",updateCurrentTime); $("video").addEventListener("loadedmetadata",updateCurrentTime);
    for(const field of fields){$(field).addEventListener("change",syncReview); $(field).addEventListener("input",syncReview);}
    $("reasonCodes").querySelectorAll('input[type="checkbox"]').forEach(input=>input.addEventListener("change",syncReview));
    function editingText(event){const tag=(event.target&&event.target.tagName||"").toLowerCase(); return tag==="input"||tag==="textarea"||tag==="select"||event.target&&event.target.isContentEditable;}
    window.addEventListener("keydown",event=>{if(event.ctrlKey&&event.key==="Enter"){event.preventDefault(); save(true); return;} if(editingText(event)) return; const key=event.key.toLowerCase(), video=$("video"); if(key==="a"){event.preventDefault(); $("status").value="approved"; save(true);} else if(key==="f"){event.preventDefault(); $("status").value="fix"; syncReview(); toast("已标记需修正，可继续填写修正内容");} else if(key==="r"){event.preventDefault(); $("status").value="reject"; save(true);} else if(event.code==="Space"){event.preventDefault(); video.paused?video.play().catch(()=>{}):video.pause();} else if(event.key==="["||event.key==="]"){event.preventDefault(); video.pause(); video.currentTime=Math.max(0,video.currentTime+(event.key==="["?-0.04:0.04)); updateCurrentTime();}});
    boot().catch(err=>toast(err.message));
  </script>
</body>
</html>
"""


class ThreadingHTTPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class ReviewHandler(BaseHTTPRequestHandler):
    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"{self.address_string()} - {fmt % args}")

    def dataset_id(self) -> str | None:
        params = parse_qs(urlparse(self.path).query)
        values = params.get("dataset") or []
        return values[0] if values else None

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        try:
            if path == "/":
                self.send_text(LANDING_HTML, "text/html; charset=utf-8")
            elif path == "/review":
                self.send_text(HTML, "text/html; charset=utf-8")
            elif path == "/overview":
                self.send_text(overview.HTML, "text/html; charset=utf-8")
            elif path == "/api/workbench/health":
                datasets = ensure_config()
                sources = Counter(str(item.get("source_kind") or "human_reviewed") for item in datasets)
                catalog_summary = (overview.read_catalog().get("summary") or {}) if overview.CATALOG_PATH.is_file() else {}
                self.send_json({
                    "ok": True,
                    "datasets": {
                        "total": len(datasets),
                        "human_reviewed": sources.get("human_reviewed", 0),
                        "public_benchmark": sources.get("public_benchmark", 0),
                    },
                    "catalog": catalog_summary,
                })
            elif path == "/api/catalog":
                self.send_json(overview.read_catalog())
            elif path == "/api/datasets":
                ensure_asset_registry()
                self.send_json({"datasets": [public_dataset(d) for d in ensure_config()]})
            elif path == "/api/assets":
                self.send_json({"assets": public_assets()})
            elif path == "/api/classifications":
                self.send_json({"classifications": load_classifications()})
            elif path == "/api/annotations":
                self.send_json(compact_annotation(find_dataset(self.dataset_id())))
            elif path == "/api/review":
                self.send_json(load_review(find_dataset(self.dataset_id())))
            elif path == "/api/review/export":
                dataset = find_dataset(self.dataset_id())
                self.send_download(load_review(dataset), Path(str(dataset["review_path"])).name)
            elif path == "/api/review/export-all":
                self.send_zip(export_all_reviews(), "momentseek_annotation_reviews.zip")
            elif path == "/media/video":
                self.send_video(find_dataset(self.dataset_id()))
            elif path == "/media/catalog-video":
                record = (parse_qs(urlparse(self.path).query).get("record") or [""])[0]
                media_path = overview.record_media_map(overview.read_catalog()).get(record)
                if not media_path:
                    self.send_error(HTTPStatus.NOT_FOUND, quote(record))
                else:
                    self.send_video_path(media_path)
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
        except KeyError as exc:
            self.send_error(HTTPStatus.NOT_FOUND, str(exc))
        except Exception as exc:  # noqa: BLE001
            self.send_error(HTTPStatus.INTERNAL_SERVER_ERROR, str(exc))

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        try:
            if path == "/api/catalog/rebuild":
                if not overview.REBUILD_LOCK.acquire(blocking=False):
                    self.send_error(HTTPStatus.CONFLICT, "A catalog rebuild is already running")
                    return
                try:
                    completed = subprocess.run(
                        overview.REBUILD_COMMAND,
                        capture_output=True,
                        text=True,
                        timeout=180,
                    )
                    if completed.returncode != 0:
                        raise RuntimeError(completed.stderr or completed.stdout or "Catalog rebuild failed")
                finally:
                    overview.REBUILD_LOCK.release()
                self.send_json({"ok": True, "summary": overview.read_catalog()["summary"]})
                return
            payload = json.loads(self.rfile.read(int(self.headers.get("content-length") or "0")).decode("utf-8"))
            if path == "/api/datasets":
                self.create_dataset(payload)
            elif path == "/api/assets/scan":
                self.send_json(scan_asset_paths())
            elif path == "/api/assets/bind":
                asset = bind_asset_path(str(payload.get("asset_id") or ""), Path(str(payload.get("video_path") or "")))
                self.send_json({"asset": asset})
            elif path == "/api/assets/rename":
                asset = rename_asset_file(str(payload.get("asset_id") or ""), str(payload.get("new_file_name") or ""))
                self.send_json({"asset": asset})
            elif path == "/api/assets/transcode-h264":
                asset = transcode_asset_to_h264(str(payload.get("asset_id") or ""))
                self.send_json({"asset": asset})
            elif path == "/api/review":
                self.save_review(payload)
            elif path == "/api/queries":
                self.create_query(payload)
            else:
                self.send_error(HTTPStatus.NOT_FOUND)
        except Exception as exc:  # noqa: BLE001
            self.send_error(HTTPStatus.BAD_REQUEST, str(exc))

    def create_dataset(self, payload: dict[str, Any]) -> None:
        annotation_path = Path(str(payload.get("annotation_path") or ""))
        video_dir = Path(str(payload.get("video_dir") or ""))
        if not annotation_path.exists():
            raise FileNotFoundError(annotation_path)
        if not video_dir.exists():
            raise FileNotFoundError(video_dir)
        datasets = ensure_config()
        dataset = make_dataset(
            annotation_path,
            video_dir,
            {str(item["id"]) for item in datasets},
            title=str(payload.get("title") or "") or None,
            dataset_id=str(payload.get("id") or "") or None,
            proxy_video=Path(str(payload["proxy_video"])) if payload.get("proxy_video") else None,
        )
        datasets.append(dataset)
        save_datasets(datasets)
        ensure_asset_registry()
        self.send_json({"dataset": public_dataset(dataset), "datasets": [public_dataset(d) for d in datasets]})

    def create_query(self, payload: dict[str, Any]) -> None:
        dataset = find_dataset(self.dataset_id())
        query = str(payload.get("query") or "").strip()
        classification_id = str(payload.get("classification_id") or "").strip()
        if not query:
            raise ValueError("Query text is required")
        if len(query) > 500:
            raise ValueError("Query text must be 500 characters or fewer")
        classification = next(
            (item for item in load_classifications() if item.get("id") == classification_id),
            None,
        )
        if not classification:
            raise ValueError(f"Unknown classification: {classification_id}")
        existing_items = annotation_items_by_id(dataset)
        normalized_query = normalize_text(query)
        if any(normalize_text(str(item.get("query") or "")) == normalized_query for item in existing_items.values()):
            raise ValueError("An identical Query already exists in this dataset")

        created_at = datetime.now(timezone.utc).isoformat()
        query_id = f"{dataset['id']}_manual_{uuid.uuid4().hex[:12]}"
        annotation_item = {
            "query_id": query_id,
            "canonical_query_id": None,
            "query_origin": "human_added",
            "manual_added": True,
            "created_at": created_at,
            "query": query,
            "classification_id": classification_id,
            "category": str(classification.get("category") or ""),
            "subcategory": str(classification.get("subcategory") or ""),
            "label_strength": "human",
            "segments": [],
            "confidence": 1.0,
            "needs_human_review": False,
            "review_reason": "",
        }
        item_review = {
            "query_id": query_id,
            "status": "fix",
            "updated_at": created_at,
            "query_ok": "yes",
            "segments_ok": "",
            "coverage_ok": "",
            "category_ok": "yes",
            "selected_category": str(classification.get("category") or ""),
            "selected_classification_id": classification_id,
            "selected_subcategory": str(classification.get("subcategory") or ""),
            "suggested_query": "",
            "missing_segments": "",
            "notes": "人工新增 Query",
            "reason_codes": ["missing_query"],
            "segments_override": False,
            "corrected_segments_mode": "inherit",
            "corrected_segments": [],
            "source_item_fingerprint": annotation_item_fingerprint(annotation_item),
            "source_query": query,
            "source_classification_id": classification_id,
            "source_segments": [],
        }

        def update(review: dict[str, Any]) -> dict[str, Any]:
            if not isinstance(review.get("items"), dict):
                review["items"] = {}
            if not isinstance(review.get("added_queries"), dict):
                review["added_queries"] = {}
            if any(
                normalize_text(str(item.get("query") or "")) == normalized_query
                for item in review["added_queries"].values()
            ):
                raise ValueError("An identical manually added Query already exists")
            review["schema_version"] = 2
            review["dataset_id"] = dataset.get("id")
            review["source_annotations"] = dataset.get("annotation_path")
            review["source_annotation_fingerprint"] = annotation_file_fingerprint(dataset)
            review["review_path"] = dataset.get("review_path")
            review["added_queries"][query_id] = annotation_item
            review["items"][query_id] = item_review
            review["updated_at"] = created_at
            review.pop("stale_count", None)
            review.pop("stale_query_ids", None)
            return review

        locked_update_json(Path(str(dataset["review_path"])), empty_review(dataset), update)
        self.send_json({"query": annotation_item, "review": load_review(dataset)})

    def save_review(self, payload: dict[str, Any]) -> None:
        dataset = find_dataset(self.dataset_id())
        query_id = str(payload["query_id"])
        item_review = dict(payload["review"])
        annotation_item = annotation_items_by_id(dataset).get(query_id)
        if not annotation_item:
            raise KeyError(f"Query no longer exists in current annotations: {query_id}")
        segments_override = bool(
            item_review.get("segments_override") is True
            or item_review.get("corrected_segments_mode") == "replace"
            or item_review.get("corrected_segments")
        )
        corrected_segments = []
        if segments_override:
            for segment in item_review.get("corrected_segments") or []:
                start = round(float(segment.get("start_sec")), 3)
                end = round(float(segment.get("end_sec")), 3)
                if not math.isfinite(start) or not math.isfinite(end) or start < 0 or end <= start:
                    raise ValueError("Each corrected segment must have finite start/end and end > start")
                corrected_segments.append(
                    {
                        "segment_id": str(segment.get("segment_id") or ""),
                        "start_sec": start,
                        "end_sec": end,
                        "duration_sec": round(end - start, 3),
                    }
                )
            corrected_segments.sort(key=lambda segment: segment["start_sec"])
        item_review["segments_override"] = segments_override
        item_review["corrected_segments_mode"] = "replace" if segments_override else "inherit"
        item_review["corrected_segments"] = corrected_segments
        updated_at = datetime.now(timezone.utc).isoformat()
        item_review["query_id"] = query_id
        item_review["updated_at"] = updated_at
        item_review["source_item_fingerprint"] = annotation_item_fingerprint(annotation_item)
        item_review["source_query"] = str(annotation_item.get("query") or "")
        item_review["source_classification_id"] = str(annotation_item.get("classification_id") or "")
        item_review["source_segments"] = [
            {
                "start_sec": round(float(segment.get("start_sec") or 0), 3),
                "end_sec": round(float(segment.get("end_sec") or 0), 3),
            }
            for segment in annotation_item.get("segments") or []
        ]

        def update(review: dict[str, Any]) -> dict[str, Any]:
            if not isinstance(review.get("items"), dict):
                review["items"] = {}
            review["schema_version"] = 2
            review["dataset_id"] = dataset.get("id")
            review["source_annotations"] = dataset.get("annotation_path")
            review["source_annotation_fingerprint"] = annotation_file_fingerprint(dataset)
            review["review_path"] = dataset.get("review_path")
            review["items"][query_id] = item_review
            review["updated_at"] = updated_at
            review.pop("stale_count", None)
            review.pop("stale_query_ids", None)
            return review

        locked_update_json(Path(str(dataset["review_path"])), empty_review(dataset), update)
        self.send_json(load_review(dataset))

    def send_text(self, text: str, content_type: str) -> None:
        data = text.encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("content-type", content_type)
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_json(self, payload: Any) -> None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_download(self, payload: Any, filename: str) -> None:
        data = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(HTTPStatus.OK)
        self.send_header("content-type", "application/json; charset=utf-8")
        self.send_header("content-disposition", f"attachment; filename*=UTF-8''{quote(filename)}")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_zip(self, data: bytes, filename: str) -> None:
        self.send_response(HTTPStatus.OK)
        self.send_header("content-type", "application/zip")
        self.send_header("content-disposition", f"attachment; filename*=UTF-8''{quote(filename)}")
        self.send_header("content-length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_video(self, dataset: dict[str, Any]) -> None:
        annotation = read_json(Path(str(dataset["annotation_path"])))
        video_path = find_video(annotation, dataset)
        if not video_path or not video_path.exists():
            self.send_error(HTTPStatus.NOT_FOUND, "video not found")
            return
        size = video_path.stat().st_size
        content_type = mimetypes.guess_type(video_path.name)[0] or "video/mp4"
        range_header = self.headers.get("range")
        if range_header:
            span = parse_range(range_header, size)
            if not span:
                self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                self.send_header("content-range", f"bytes */{size}")
                self.end_headers()
                return
            start, end = span
            self.send_response(HTTPStatus.PARTIAL_CONTENT)
            self.send_header("content-type", content_type)
            self.send_header("accept-ranges", "bytes")
            self.send_header("content-range", f"bytes {start}-{end}/{size}")
            self.send_header("content-length", str(end - start + 1))
            self.end_headers()
            with video_path.open("rb") as handle:
                handle.seek(start)
                remaining = end - start + 1
                while remaining > 0:
                    chunk = handle.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    remaining -= len(chunk)
                    self.wfile.write(chunk)
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("content-type", content_type)
        self.send_header("accept-ranges", "bytes")
        self.send_header("content-length", str(size))
        self.end_headers()
        with video_path.open("rb") as handle:
            while True:
                chunk = handle.read(1024 * 1024)
                if not chunk:
                    break
                self.wfile.write(chunk)

    def send_video_path(self, video_path: Path) -> None:
        if not video_path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND, "video not found")
            return
        size = video_path.stat().st_size
        content_type = mimetypes.guess_type(video_path.name)[0] or "video/mp4"
        range_header = self.headers.get("range")
        if range_header:
            span = parse_range(range_header, size)
            if not span:
                self.send_response(HTTPStatus.REQUESTED_RANGE_NOT_SATISFIABLE)
                self.send_header("content-range", f"bytes */{size}")
                self.end_headers()
                return
            start, end = span
            self.send_response(HTTPStatus.PARTIAL_CONTENT)
            self.send_header("content-type", content_type)
            self.send_header("accept-ranges", "bytes")
            self.send_header("content-range", f"bytes {start}-{end}/{size}")
            self.send_header("content-length", str(end - start + 1))
            self.end_headers()
            with video_path.open("rb") as handle:
                handle.seek(start)
                remaining = end - start + 1
                while remaining > 0:
                    chunk = handle.read(min(1024 * 1024, remaining))
                    if not chunk:
                        break
                    remaining -= len(chunk)
                    self.wfile.write(chunk)
            return
        self.send_response(HTTPStatus.OK)
        self.send_header("content-type", content_type)
        self.send_header("accept-ranges", "bytes")
        self.send_header("content-length", str(size))
        self.end_headers()
        with video_path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                self.wfile.write(chunk)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Serve the unified MomentSeek data and evaluation workbench.")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8791)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    datasets = ensure_config()
    server = ThreadingHTTPServer((args.host, args.port), ReviewHandler)
    print(f"MomentSeek data and evaluation workbench: http://{args.host}:{args.port}/")
    print(f"config: {CONFIG_PATH}")
    print(f"datasets: {len(datasets)}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
