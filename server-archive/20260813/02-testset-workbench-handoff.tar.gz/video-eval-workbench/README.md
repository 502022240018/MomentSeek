# MomentSeek 数据与评测工作台

统一原 8766 自有标注审核、8767 公开测试集审核和 8786 测试集总览。

平台运行所需的全部代码均在本目录：

- `app.py`：统一审核与HTTP服务；
- `overview.py`：测试集总览页面；
- `catalog_builder.py`：测试集汇总构建器；
- `migrate_legacy_data.py`：旧注册表兼容迁移；
- `verify_deployment.py`：部署验证；
- `start.sh`：启动入口。

运行时不再导入旧 `annotation-review`、`public-benchmark-review` 或
`/home/momentseek-29154/tools` 下的代码。视频、标注、审核JSON、分类文件
和公开集目录仍作为外部数据引用。

## 当前迁移模式

第一阶段采用兼容式迁移：

- 一个代码目录、一个 Python 服务、一个浏览器入口；
- 合并两套数据集与视频资产注册表；
- 原始标注 JSON 只读；
- 已有审核结果仍写回原 `review_path`，因此旧平台可以随时回退；
- 测试集总览继续使用现有 catalog 和构建脚本。

此阶段不停止旧 8766、8767、8786 服务。

## 部署

```bash
python3 migrate_legacy_data.py
nohup ./start.sh > logs/workbench.log 2>&1 &
```

默认监听 `127.0.0.1:8791`：

- `/`：统一入口；
- `/review?source=human_reviewed`：自有数据审核；
- `/review?source=public_benchmark`：公开测试集；
- `/overview`：测试集总览。

## 数据安全

迁移脚本只读取旧配置并生成统一注册表，不移动视频、不修改原始标注、不复制或重写审核结果。统一平台保存审核时沿用数据集原来的 `review_path`。
