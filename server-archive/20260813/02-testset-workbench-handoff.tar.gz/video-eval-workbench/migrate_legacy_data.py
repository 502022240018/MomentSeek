#!/usr/bin/env python3
"""Build a unified registry without moving or rewriting legacy review data."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def atomic_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def tagged_datasets(root: Path, source_kind: str) -> list[dict[str, Any]]:
    payload = read_json(root / "config" / "datasets.json")
    rows = []
    for source in payload.get("datasets") or []:
        row = dict(source)
        row["source_kind"] = source_kind
        row["legacy_root"] = str(root)
        rows.append(row)
    return rows


def tagged_assets(root: Path, source_kind: str) -> dict[str, dict[str, Any]]:
    payload = read_json(root / "config" / "video_assets.json")
    rows = {}
    for asset_id, source in (payload.get("assets") or {}).items():
        row = dict(source)
        row["source_kind"] = source_kind
        row["legacy_root"] = str(root)
        rows[str(asset_id)] = row
    return rows


def migrate(human_root: Path, public_root: Path, output_root: Path) -> dict[str, Any]:
    human = tagged_datasets(human_root, "human_reviewed")
    public = tagged_datasets(public_root, "public_benchmark")
    datasets = human + public
    ids = [str(row["id"]) for row in datasets]
    duplicates = sorted({dataset_id for dataset_id in ids if ids.count(dataset_id) > 1})
    if duplicates:
        raise ValueError(f"Duplicate dataset IDs: {duplicates}")

    assets = tagged_assets(human_root, "human_reviewed")
    for asset_id, asset in tagged_assets(public_root, "public_benchmark").items():
        if asset_id in assets:
            raise ValueError(f"Duplicate asset ID: {asset_id}")
        assets[asset_id] = asset

    missing_annotations = [
        str(row.get("annotation_path"))
        for row in datasets
        if not Path(str(row.get("annotation_path") or "")).is_file()
    ]
    if missing_annotations:
        raise FileNotFoundError(
            "Missing annotation files:\n" + "\n".join(missing_annotations[:20])
        )

    output_root.mkdir(parents=True, exist_ok=True)
    for name in ("imports", "media", "reviews", "logs"):
        (output_root / name).mkdir(exist_ok=True)

    datasets_payload = {
        "schema_version": 2,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "migration_mode": "legacy_paths_compatible",
        "datasets": datasets,
    }
    assets_payload = {
        "schema_version": 2,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "migration_mode": "legacy_paths_compatible",
        "assets": assets,
    }
    atomic_json(output_root / "config" / "datasets.json", datasets_payload)
    atomic_json(output_root / "config" / "video_assets.json", assets_payload)

    manifest = {
        "schema_version": 1,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "source_roots": {
            "human_reviewed": str(human_root),
            "public_benchmark": str(public_root),
        },
        "counts": {
            "datasets": len(datasets),
            "human_reviewed_datasets": len(human),
            "public_benchmark_datasets": len(public),
            "assets": len(assets),
            "existing_review_files": sum(
                Path(str(row.get("review_path") or "")).is_file() for row in datasets
            ),
            "missing_annotation_files": len(missing_annotations),
        },
        "source_checksums": {
            "human_datasets": sha256(human_root / "config" / "datasets.json"),
            "human_assets": sha256(human_root / "config" / "video_assets.json"),
            "public_datasets": sha256(public_root / "config" / "datasets.json"),
            "public_assets": sha256(public_root / "config" / "video_assets.json"),
        },
        "write_policy": {
            "annotations": "read_only",
            "existing_reviews": "write_through_to_legacy_review_path",
            "new_datasets": "stored_under_unified_root",
        },
    }
    atomic_json(output_root / "migration_manifest.json", manifest)
    return manifest


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--human-root",
        type=Path,
        default=Path("/home/momentseek-29154/annotation-review"),
    )
    parser.add_argument(
        "--public-root",
        type=Path,
        default=Path("/home/momentseek-29154/public-benchmark-review"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("/home/momentseek-29154/video-eval-workbench"),
    )
    args = parser.parse_args()
    print(
        json.dumps(
            migrate(args.human_root, args.public_root, args.output_root),
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
