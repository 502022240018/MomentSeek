#!/usr/bin/env python3
"""Verify registry fidelity and read-only HTTP behavior after deployment."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request, urlopen


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def get_json(url: str) -> dict:
    with urlopen(url, timeout=30) as response:
        assert response.status == 200, (response.status, url)
        return json.load(response)


def verify(
    base_url: str,
    human_root: Path,
    public_root: Path,
    unified_root: Path,
) -> dict:
    human = read_json(human_root / "config" / "datasets.json").get("datasets") or []
    public = read_json(public_root / "config" / "datasets.json").get("datasets") or []
    unified = read_json(unified_root / "config" / "datasets.json").get("datasets") or []
    expected_ids = {str(row["id"]) for row in human + public}
    actual_ids = {str(row["id"]) for row in unified}
    assert expected_ids == actual_ids
    assert len(unified) == len(expected_ids)
    assert sum(row.get("source_kind") == "human_reviewed" for row in unified) == len(human)
    assert sum(row.get("source_kind") == "public_benchmark" for row in unified) == len(public)
    assert all(Path(str(row["annotation_path"])).is_file() for row in unified)

    pages = {}
    for path in ("/", "/review?source=human_reviewed", "/review?source=public_benchmark", "/overview"):
        with urlopen(base_url + path, timeout=30) as response:
            body = response.read()
            assert response.status == 200 and b"<!doctype html>" in body.lower()
            pages[path] = len(body)

    health = get_json(base_url + "/api/workbench/health")
    api_datasets = get_json(base_url + "/api/datasets")["datasets"]
    assert health["datasets"]["total"] == len(unified)
    assert len(api_datasets) == len(unified)
    assert {row["id"] for row in api_datasets} == actual_ids

    samples = {}
    for source_kind in ("human_reviewed", "public_benchmark"):
        sample = next(
            row for row in api_datasets
            if row["source_kind"] == source_kind and row["annotation_exists"]
        )
        dataset_id = quote(str(sample["id"]))
        annotations = get_json(base_url + f"/api/annotations?dataset={dataset_id}")
        review = get_json(base_url + f"/api/review?dataset={dataset_id}")
        assert annotations["dataset"]["id"] == sample["id"]
        assert review["dataset_id"] == sample["id"]
        samples[source_kind] = {
            "dataset_id": sample["id"],
            "queries": annotations["totals"]["queries"],
            "review_items": len(review.get("items") or {}),
        }

    range_sample = next(row for row in api_datasets if row.get("current_video_path"))
    request = Request(
        base_url + "/media/video?dataset=" + quote(str(range_sample["id"])),
        headers={"Range": "bytes=0-1023"},
    )
    with urlopen(request, timeout=30) as response:
        body = response.read()
        assert response.status == 206 and len(body) == 1024

    catalog = get_json(base_url + "/api/catalog")
    return {
        "ok": True,
        "dataset_counts": {
            "total": len(unified),
            "human_reviewed": len(human),
            "public_benchmark": len(public),
        },
        "catalog_summary": catalog.get("summary") or {},
        "page_bytes": pages,
        "samples": samples,
        "video_range_dataset": range_sample["id"],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-url", default="http://127.0.0.1:8791")
    parser.add_argument("--human-root", type=Path, default=Path("/home/momentseek-29154/annotation-review"))
    parser.add_argument("--public-root", type=Path, default=Path("/home/momentseek-29154/public-benchmark-review"))
    parser.add_argument("--unified-root", type=Path, default=Path("/home/momentseek-29154/video-eval-workbench"))
    args = parser.parse_args()
    print(json.dumps(verify(args.base_url, args.human_root, args.public_root, args.unified_root), ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
