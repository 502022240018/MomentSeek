"""Benchmark a local Qwen3-VL model on the labelled phase-1 rerank set."""

from __future__ import annotations

import argparse
import json
import math
import re
import statistics
import time
from collections import defaultdict
from pathlib import Path

import torch
import torch_npu  # noqa: F401
from PIL import Image
from transformers import AutoModelForImageTextToText, AutoProcessor


SPATIAL_COMPRESSION = 32
NUMBER_RE = re.compile(r"(?<!\d)([0-3](?:\.\d+)?)(?!\d)")


def percentile(values: list[float], fraction: float) -> float:
    if len(values) == 1:
        return values[0]
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] * (upper - position) + ordered[upper] * (position - lower)


def dcg(relevances: list[int], limit: int) -> float:
    return sum((2**rel - 1) / math.log2(rank + 2) for rank, rel in enumerate(relevances[:limit]))


def query_metrics(rows: list[dict], score_key: str) -> dict[str, float]:
    ranked = sorted(rows, key=lambda row: (-float(row[score_key]), row["original_rank"]))
    relevance = [int(row["relevance"]) for row in ranked]
    # Phase-1 contains valid queries whose best candidate is labelled 2. Treat
    # both 2 (strong, one missing constraint) and 3 (fully relevant) as hits;
    # nDCG below continues to preserve the full graded 0..3 distinction.
    positives = [index + 1 for index, rel in enumerate(relevance) if rel >= 2]
    ideal = sorted(relevance, reverse=True)
    return {
        "mrr": 1.0 / positives[0] if positives else 0.0,
        "hit_at_1": float(bool(positives and positives[0] <= 1)),
        "hit_at_3": float(bool(positives and positives[0] <= 3)),
        "ndcg_at_3": dcg(relevance, 3) / dcg(ideal, 3) if dcg(ideal, 3) else 0.0,
        "ndcg_at_20": dcg(relevance, 20) / dcg(ideal, 20) if dcg(ideal, 20) else 0.0,
    }


def aggregate(rows: list[dict], score_key: str) -> dict:
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        grouped[row["query_id"]].append(row)
    per_query = {qid: query_metrics(items, score_key) for qid, items in grouped.items()}
    keys = next(iter(per_query.values())).keys()
    return {
        "relevant_threshold": 2,
        "queries": len(per_query),
        **{key: round(statistics.mean(item[key] for item in per_query.values()), 4) for key in keys},
        "per_query": per_query,
    }


def load_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--min-visual-tokens", type=int, default=128)
    parser.add_argument("--max-visual-tokens", type=int, default=256)
    parser.add_argument("--max-new-tokens", type=int, default=12)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--disable-thinking", action="store_true")
    parser.add_argument(
        "--scoring-mode", choices=("generate", "yes-no-logits"), default="generate"
    )
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()

    candidate_path = args.dataset / "candidates" / "candidate_sets.jsonl"
    annotation_path = args.dataset / "annotations.jsonl"
    annotations = {
        item["candidate_id"]: item for item in load_jsonl(annotation_path)
    }
    candidates: list[dict] = []
    query_meta: dict[str, dict] = {}
    for query_row in load_jsonl(candidate_path):
        query_meta[query_row["query_id"]] = query_row
        for candidate in query_row["candidates"]:
            annotation = annotations[candidate["candidate_id"]]
            candidates.append({
                "query_id": query_row["query_id"],
                "query": query_row["query"],
                "split": query_row.get("split", "unknown"),
                "category": query_row.get("category", "unknown"),
                "language": query_row.get("language", "unknown"),
                "constraints": query_row.get("constraints", []),
                "candidate_id": candidate["candidate_id"],
                "original_rank": candidate["rank"],
                "baseline_score": candidate["baseline_score"],
                "frame_paths": candidate["model_input"]["frame_paths"],
                "relevance": annotation["relevance"],
            })
    if args.limit:
        candidates = candidates[: args.limit]

    device = torch.device("npu:0")
    load_started = time.perf_counter()
    # Qwen3-VL is decoder-only. Left padding is required for batched
    # generation; right padding can make shorter samples decode from padding.
    processor = AutoProcessor.from_pretrained(
        args.model, local_files_only=True, padding_side="left"
    )
    processor.image_processor.size = {
        "shortest_edge": args.min_visual_tokens * SPATIAL_COMPRESSION**2,
        "longest_edge": args.max_visual_tokens * SPATIAL_COMPRESSION**2,
    }
    model = AutoModelForImageTextToText.from_pretrained(
        args.model, local_files_only=True, dtype=torch.bfloat16,
        low_cpu_mem_usage=True, attn_implementation="eager",
    ).eval().to(device)
    yes_token_ids = processor.tokenizer.encode("Yes", add_special_tokens=False)
    no_token_ids = processor.tokenizer.encode("No", add_special_tokens=False)
    if args.scoring_mode == "yes-no-logits":
        if len(yes_token_ids) != 1 or len(no_token_ids) != 1:
            raise RuntimeError(
                f"Yes/No must each be one token, got Yes={yes_token_ids}, No={no_token_ids}"
            )
        print(json.dumps({
            "yes_token_id": yes_token_ids[0], "no_token_id": no_token_ids[0]
        }), flush=True)
    torch.npu.synchronize()
    load_seconds = time.perf_counter() - load_started
    torch.npu.empty_cache()
    torch.npu.reset_peak_memory_stats()

    rows: list[dict] = []
    latencies: list[float] = []
    for batch_start in range(0, len(candidates), args.batch_size):
        batch = candidates[batch_start:batch_start + args.batch_size]
        rendered_batch = []
        flat_images = []
        for candidate in batch:
            images = [Image.open(args.dataset / path).convert("RGB") for path in candidate["frame_paths"]]
            flat_images.extend(images)
            if args.scoring_mode == "yes-no-logits":
                prompt = (
                    "You are a video retrieval relevance judge. The images are ordered "
                    "frames from one candidate video segment.\n"
                    f"Search query: {candidate['query']}\n"
                    f"Required constraints: {'; '.join(candidate['constraints'])}\n"
                    "Does this video segment visually satisfy the search query and its "
                    "required constraints? Answer only Yes or No."
                )
            else:
                prompt = (
                    "你是视频检索精排器。以下图片按时间顺序来自同一个候选片段。\n"
                    f"检索需求：{candidate['query']}\n"
                    f"约束：{'；'.join(candidate['constraints'])}\n"
                    "请判断该片段满足全部需求的程度，只输出0到3之间的一个数字："
                    "3=完全满足，2=大部分满足但缺少一个关键条件，"
                    "1=只满足少数条件，0=无关。"
                )
            content = [{"type": "image", "image": image} for image in images]
            content.append({"type": "text", "text": prompt})
            messages = [{"role": "user", "content": content}]
            template_kwargs = {
                "tokenize": False,
                "add_generation_prompt": True,
            }
            if args.disable_thinking:
                template_kwargs["enable_thinking"] = False
            rendered_batch.append(processor.apply_chat_template(messages, **template_kwargs))
        inputs = processor(text=rendered_batch, images=flat_images, padding=True, return_tensors="pt")
        inputs = {key: value.to(device) if isinstance(value, torch.Tensor) else value for key, value in inputs.items()}
        started = time.perf_counter()
        with torch.inference_mode():
            if args.scoring_mode == "yes-no-logits":
                outputs = model(**inputs, logits_to_keep=1, return_dict=True)
            else:
                generated = model.generate(
                    **inputs, max_new_tokens=args.max_new_tokens, do_sample=False
                )
        torch.npu.synchronize()
        elapsed = time.perf_counter() - started
        input_tokens = int(inputs["input_ids"].shape[1])
        if args.scoring_mode == "yes-no-logits":
            next_logits = outputs.logits[:, -1, :]
            binary_logits = next_logits[:, [yes_token_ids[0], no_token_ids[0]]].float()
            scores = torch.softmax(binary_logits, dim=-1)[:, 0].cpu().tolist()
            answers = [f"P(Yes)={score:.8f}" for score in scores]
        else:
            answers = processor.batch_decode(
                generated[:, input_tokens:], skip_special_tokens=True
            )
        per_candidate = elapsed / len(batch)
        for offset, (candidate, answer) in enumerate(zip(batch, answers)):
            answer = answer.strip()
            if args.scoring_mode == "yes-no-logits":
                score = float(scores[offset])
            else:
                match = NUMBER_RE.search(answer)
                score = min(3.0, max(0.0, float(match.group(1)))) if match else 0.0
            row = {**candidate, "rerank_score": score, "answer": answer,
                   "latency_seconds": round(per_candidate, 4), "batch_seconds": round(elapsed, 4),
                   "input_tokens": input_tokens}
            rows.append(row)
            latencies.append(per_candidate)
            index = batch_start + offset + 1
            print(json.dumps({"progress": f"{index}/{len(candidates)}", "candidate_id": candidate["candidate_id"],
                              "score": score, "label": candidate["relevance"],
                              "batch_seconds": round(elapsed, 3)}, ensure_ascii=False), flush=True)

    report = {
        "model": str(args.model),
        "dataset": str(args.dataset),
        "candidates": len(rows),
        "batch_size": args.batch_size,
        "scoring_mode": args.scoring_mode,
        "visual_tokens_per_image": {"min": args.min_visual_tokens, "max": args.max_visual_tokens},
        "load_seconds": round(load_seconds, 3),
        "latency_seconds": {"mean": round(statistics.mean(latencies), 3),
                            "p50": round(percentile(latencies, .5), 3),
                            "p95": round(percentile(latencies, .95), 3)},
        "candidates_per_second": round(len(rows) / sum(latencies), 4),
        "peak_allocated_gib": round(torch.npu.max_memory_allocated() / 1024**3, 3),
        "peak_reserved_gib": round(torch.npu.max_memory_reserved() / 1024**3, 3),
        "baseline": aggregate(rows, "baseline_score"),
        "reranked": aggregate(rows, "rerank_score"),
        "rows": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "rows"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
