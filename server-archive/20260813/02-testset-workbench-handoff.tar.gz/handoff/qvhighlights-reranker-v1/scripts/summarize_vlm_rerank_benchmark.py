"""Summarize a VLM rerank benchmark report by language and query category."""

from __future__ import annotations

import argparse
import json
import statistics
from collections import defaultdict
from pathlib import Path


def ranked(rows: list[dict], score_key: str) -> list[dict]:
    return sorted(
        rows,
        key=lambda row: (-float(row[score_key]), int(row["original_rank"])),
    )


def query_metrics(rows: list[dict], score_key: str) -> dict[str, float]:
    import math

    relevance = [int(row["relevance"]) for row in ranked(rows, score_key)]
    positives = [index + 1 for index, rel in enumerate(relevance) if rel >= 2]
    ideal = sorted(relevance, reverse=True)

    def dcg(values: list[int], limit: int) -> float:
        return sum(
            (2**rel - 1) / math.log2(index + 2)
            for index, rel in enumerate(values[:limit])
        )

    result = {
        "mrr": 1.0 / positives[0] if positives else 0.0,
        "hit_at_1": float(bool(positives and positives[0] <= 1)),
        "hit_at_3": float(bool(positives and positives[0] <= 3)),
    }
    for limit in (3, 20):
        ideal_dcg = dcg(ideal, limit)
        result[f"ndcg_at_{limit}"] = (
            dcg(relevance, limit) / ideal_dcg if ideal_dcg else 0.0
        )
    total_relevant = sum(rel >= 2 for rel in relevance)
    for limit in (5, 20, 30):
        top = relevance[:limit]
        hits = sum(rel >= 2 for rel in top)
        result[f"precision_at_{limit}"] = hits / len(top) if top else 0.0
        result[f"recall_at_{limit}"] = (
            hits / total_relevant if total_relevant else 0.0
        )
    return result


def average(metrics: list[dict[str, float]]) -> dict[str, float]:
    return {
        key: round(statistics.mean(row[key] for row in metrics), 4)
        for key in metrics[0]
    }


def grouped_metrics(rows: list[dict], score_key: str, group_key: str) -> dict:
    query_rows: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        query_rows[row["query_id"]].append(row)

    groups: dict[str, list[dict[str, float]]] = defaultdict(list)
    for items in query_rows.values():
        groups[str(items[0].get(group_key, "unknown"))].append(
            query_metrics(items, score_key)
        )
    return {
        group: {"queries": len(items), **average(items)}
        for group, items in sorted(groups.items())
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("report", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--score-key", default="rerank_score")
    args = parser.parse_args()

    report = json.loads(args.report.read_text(encoding="utf-8"))
    rows = report["rows"]
    query_rows: dict[str, list[dict]] = defaultdict(list)
    for row in rows:
        query_rows[row["query_id"]].append(row)
    per_query = [
        query_metrics(items, args.score_key) for items in query_rows.values()
    ]
    summary = {
        "model": report["model"],
        "candidates": len(rows),
        "queries": len(query_rows),
        "score_key": args.score_key,
        "overall": average(per_query),
        "by_language": grouped_metrics(rows, args.score_key, "language"),
        "by_category": grouped_metrics(rows, args.score_key, "category"),
        "runtime": {
            "load_seconds": report.get("load_seconds"),
            "latency_seconds": report.get("latency_seconds"),
            "candidates_per_second": report.get("candidates_per_second"),
            "peak_allocated_gib": report.get("peak_allocated_gib"),
            "peak_reserved_gib": report.get("peak_reserved_gib"),
        },
    }
    rendered = json.dumps(summary, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered, encoding="utf-8")
    print(rendered, end="")


if __name__ == "__main__":
    main()
