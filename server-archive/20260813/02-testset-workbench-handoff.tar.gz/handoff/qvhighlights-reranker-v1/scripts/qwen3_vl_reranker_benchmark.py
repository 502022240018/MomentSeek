"""Evaluate Qwen3-VL-Reranker on the four-frame phase-1 dataset."""

from __future__ import annotations

import argparse
import json
import statistics
import time
from pathlib import Path

import torch
import torch_npu  # noqa: F401
from PIL import Image
from transformers import AutoProcessor, Qwen3VLForConditionalGeneration

from vlm_rerank_benchmark import aggregate, load_jsonl, percentile


SPATIAL_COMPRESSION = 32


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--min-visual-tokens", type=int, default=128)
    parser.add_argument("--max-visual-tokens", type=int, default=256)
    parser.add_argument("--batch-size", type=int, default=1)
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()

    annotations = {
        item["candidate_id"]: item
        for item in load_jsonl(args.dataset / "annotations.jsonl")
    }
    candidates = []
    for query_row in load_jsonl(args.dataset / "candidates" / "candidate_sets.jsonl"):
        for candidate in query_row["candidates"]:
            candidates.append({
                "query_id": query_row["query_id"],
                "query": query_row["query"],
                "category": query_row.get("category", "unknown"),
                "language": query_row.get("language", "unknown"),
                "constraints": query_row.get("constraints", []),
                "candidate_id": candidate["candidate_id"],
                "original_rank": candidate["rank"],
                "baseline_score": candidate["baseline_score"],
                "frame_paths": candidate["model_input"]["frame_paths"],
                "relevance": annotations[candidate["candidate_id"]]["relevance"],
            })
    if args.limit:
        candidates = candidates[: args.limit]

    device = torch.device("npu:0")
    load_started = time.perf_counter()
    lm = Qwen3VLForConditionalGeneration.from_pretrained(
        args.model, local_files_only=True, dtype=torch.bfloat16,
        low_cpu_mem_usage=True, attn_implementation="eager",
    ).to(device)
    model = lm.model.eval()
    processor = AutoProcessor.from_pretrained(args.model, local_files_only=True, padding_side="left")
    processor.image_processor.size = {
        "shortest_edge": args.min_visual_tokens * SPATIAL_COMPRESSION**2,
        "longest_edge": args.max_visual_tokens * SPATIAL_COMPRESSION**2,
    }
    # The reranker checkpoint also stores explicit pixel bounds, which take
    # precedence over ``size`` in Qwen2VLImageProcessorFast.
    processor.image_processor.min_pixels = args.min_visual_tokens * SPATIAL_COMPRESSION**2
    processor.image_processor.max_pixels = args.max_visual_tokens * SPATIAL_COMPRESSION**2
    yes_id = processor.tokenizer.get_vocab()["yes"]
    no_id = processor.tokenizer.get_vocab()["no"]
    score_weight = (lm.lm_head.weight.data[yes_id] - lm.lm_head.weight.data[no_id]).to(device)
    del lm.lm_head
    torch.npu.synchronize()
    load_seconds = time.perf_counter() - load_started
    torch.npu.empty_cache()
    torch.npu.reset_peak_memory_stats()

    rows = []
    latencies = []
    instruction = "Rank video segments by how completely they satisfy every visual constraint in the user's query."
    for batch_start in range(0, len(candidates), args.batch_size):
        batch = candidates[batch_start:batch_start + args.batch_size]
        rendered_batch = []
        flat_images = []
        for candidate in batch:
            images = [Image.open(args.dataset / path).convert("RGB") for path in candidate["frame_paths"]]
            flat_images.extend(images)
            system = (
            'Judge whether the Document meets the requirements based on the Query and the Instruct provided. '
            'Note that the answer can only be "yes" or "no".'
            )
            query_text = candidate["query"] + "\nConstraints: " + "; ".join(candidate["constraints"])
            content = [{"type": "text", "text": f"<Instruct>: {instruction}\n<Query>: {query_text}\n<Document>:"}]
            content.extend({
                "type": "image",
                "image": image,
                "min_pixels": args.min_visual_tokens * SPATIAL_COMPRESSION**2,
                "max_pixels": args.max_visual_tokens * SPATIAL_COMPRESSION**2,
            } for image in images)
            messages = [{"role": "system", "content": [{"type": "text", "text": system}]},
                        {"role": "user", "content": content}]
            rendered_batch.append(processor.apply_chat_template(
                messages, tokenize=False, add_generation_prompt=True
            ))
        inputs = processor(text=rendered_batch, images=flat_images, padding=True, return_tensors="pt")
        inputs = {key: value.to(device) if isinstance(value, torch.Tensor) else value for key, value in inputs.items()}
        started = time.perf_counter()
        with torch.inference_mode():
            hidden = model(**inputs).last_hidden_state[:, -1]
            scores = torch.sigmoid(hidden @ score_weight).tolist()
        torch.npu.synchronize()
        elapsed = time.perf_counter() - started
        per_candidate = elapsed / len(batch)
        for offset, (candidate, score) in enumerate(zip(batch, scores)):
            row = {**candidate, "rerank_score": score, "latency_seconds": round(per_candidate, 4),
                   "batch_seconds": round(elapsed, 4), "input_tokens": int(inputs["input_ids"].shape[1])}
            rows.append(row)
            latencies.append(per_candidate)
            index = batch_start + offset + 1
            print(json.dumps({"progress": f"{index}/{len(candidates)}", "candidate_id": candidate["candidate_id"],
                              "score": round(score, 6), "label": candidate["relevance"],
                              "batch_seconds": round(elapsed, 3)}, ensure_ascii=False), flush=True)

    report = {
        "model": str(args.model), "dataset": str(args.dataset), "candidates": len(rows),
        "batch_size": args.batch_size,
        "instruction": instruction,
        "visual_tokens_per_image": {"min": args.min_visual_tokens, "max": args.max_visual_tokens},
        "load_seconds": round(load_seconds, 3),
        "latency_seconds": {"mean": round(statistics.mean(latencies), 3),
                            "p50": round(percentile(latencies, .5), 3),
                            "p95": round(percentile(latencies, .95), 3)},
        "candidates_per_second": round(len(rows) / sum(latencies), 4),
        "peak_allocated_gib": round(torch.npu.max_memory_allocated() / 1024**3, 3),
        "peak_reserved_gib": round(torch.npu.max_memory_reserved() / 1024**3, 3),
        "baseline": aggregate(rows, "baseline_score"),
        "reranked": aggregate(rows, "rerank_score"),
        "rows": rows,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: value for key, value in report.items() if key != "rows"}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
