"""Build a category-balanced bilingual QVHighlights set with 4-second candidates."""

from __future__ import annotations

import argparse
import json
import random
import subprocess
import time
from pathlib import Path


QUERY_SPECS = {
    "person_attribute": {
        6482: "一名戴帽子的男子在死马点欣赏日落。",
        7319: "一名身穿黑衣的黑人女子正在评价她买的一瓶黄色饮料。",
        9474: "一名戴眼镜的女子拿着麦克风大喊。",
        6241: "一名女子坐在车里，口罩戴在下巴周围。",
        10099: "一名女子戴着米色头巾。",
        9173: "一名穿黑色毛衣的男子在河边谈论恶劣天气和洪水。",
    },
    "people_interaction": {
        313: "两名男子在街头进行拳击训练。",
        8855: "三个孩子坐在椅子上，面对镜头说话。",
        1136: "两个孩子和一名男子提着行李箱穿过隧道。",
        6383: "两个朋友外出购买衣服。",
        5392: "一男一女一起穿过机场。",
        41: "两名男子在红色场地上参加职业乒乓球比赛。",
    },
    "human_object": {
        8636: "一名女子举起一个绿色瓶子。",
        2921: "一个女孩展示她的美容产品。",
        4875: "一名黑衣男子在紫色墙边拿着一束花。",
        9903: "一大群人举着旗帜和标语沿街游行，最前面是一名戴遮阳帽的女子。",
        5257: "一个小丑把气球套到打气筒上。",
        7398: "一名男子展示白色跑车的大号黑色轮毂。",
    },
    "scene_event": {
        2334: "三名女子在酒吧或餐厅里一起唱歌跳舞。",
        9825: "高管们在武装警卫的包围下匆忙走过街道。",
        2043: "人们夜间穿过街道，随后在一家商店门前交谈。",
        4349: "餐厅的食品柜台以及留在柜台上的袋子。",
        10229: "穿白色制服的水兵们在街头一起列队游行。",
        10226: "一名平头黑人男子在带黑色金属框架的红色建筑外说话。",
    },
    "cooking_procedure": {
        1319: "一个人正在准备一盘食物。",
        6252: "一名男子站在柜台后，面前有一大盘食物。",
        932: "天黑后，厨师们在烤架上为宴会烹饪食物。",
        456: "厨师把食物装进保鲜盒。",
        6083: "厨师们只在锅里烹煮洋葱。",
        2546: "一个小男孩和一个小女孩与父亲一起吃东西。",
    },
    "sports_exercise": {
        5612: "一男一女一起跳舞。",
        1870: "孩子们在停放的汽车前锻炼。",
        6166: "一名穿黑色比基尼、戴浅蓝色脚蹼的女子在海里游泳。",
        8327: "两名乒乓球运动员正在进行激烈比赛。",
        4704: "一名穿白色上衣的女子骑自行车。",
        6267: "一名衣着时尚的年轻女子在家做瑜伽拉伸。",
    },
    "rough_cut_proxy": {
        7803: "一名穿灰色上衣的男子从室外走进室内。",
        8691: "一名女子走进杂货店，随后把篮子里的商品倒出来。",
        2411: "一只小哈士奇被梳毛，随后被放到院子里玩球。",
        5667: "一名女子在机场等待接送车辆，随后上车。",
        6316: "一名女子拿着相机，随后把相机放进背包。",
        9878: "普京和特朗普走上讲台，随后开始讲话。",
    },
}

ANNOTATION_URL = "https://raw.githubusercontent.com/jayleicn/moment_detr/main/data/highlight_val_release.jsonl"
VIDEO_URL = "https://hf-mirror.com/datasets/ayushsdev/qvhighlights-videos/resolve/main/{prefix}/{vid}.mp4?download=true"


def write_jsonl(path: Path, rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("".join(json.dumps(row, ensure_ascii=False) + "\n" for row in rows), encoding="utf-8")


def download(url: str, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and path.stat().st_size:
        return
    partial = path.with_suffix(path.suffix + ".part")
    for attempt in range(5):
        result = subprocess.run(
            ["curl", "-fL", "--retry", "8", "--retry-all-errors", "--connect-timeout", "20",
             "-C", "-", "-o", str(partial), url], check=False,
        )
        if result.returncode == 0 and partial.exists() and partial.stat().st_size:
            partial.replace(path)
            return
        time.sleep(2**attempt)
    raise RuntimeError(f"Download failed: {url}")


def source_labels(row: dict) -> dict[int, int]:
    labels = {}
    for clip_id, scores in zip(row["relevant_clip_ids"], row["saliency_scores"]):
        median = sorted(scores)[len(scores) // 2]
        labels[int(clip_id)] = 1 if median <= 1 else 2 if median <= 3 else 3
    return labels


def label_4s(row: dict, start: float, end: float) -> tuple[int, list[int]]:
    labels = source_labels(row)
    overlapping = [
        clip_id for clip_id in labels
        if min(end, clip_id * 2 + 2) - max(start, clip_id * 2) > 0
    ]
    return (max((labels[clip_id] for clip_id in overlapping), default=0), sorted(overlapping))


def extract_candidate(video: Path, frame_dir: Path, stem: str, start: float) -> list[str]:
    frame_dir.mkdir(parents=True, exist_ok=True)
    destinations = [frame_dir / f"{stem}__f{index:02d}.jpg" for index in range(1, 9)]
    if not all(path.exists() for path in destinations):
        pattern = str(frame_dir / f"{stem}__f%02d.jpg")
        subprocess.run(
            ["ffmpeg", "-loglevel", "error", "-ss", str(start), "-i", str(video),
             "-t", "4", "-vf", "fps=2", "-frames:v", "8", "-q:v", "2", "-y", pattern],
            check=True,
        )
    if not all(path.exists() for path in destinations):
        raise RuntimeError(f"Expected eight frames for {stem}")
    query_dir = stem.split("__", 1)[0]
    return [f"frames/{query_dir}/{path.name}" for path in destinations]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cache", type=Path, required=True)
    parser.add_argument("--annotation", type=Path)
    parser.add_argument("--seed", type=int, default=20260722)
    args = parser.parse_args()

    annotation = args.annotation or args.cache / "highlight_val_release.jsonl"
    download(ANNOTATION_URL, annotation)
    source = {row["qid"]: row for row in map(json.loads, annotation.read_text(encoding="utf-8").splitlines())}
    qid_to_category = {qid: category for category, specs in QUERY_SPECS.items() for qid in specs}
    missing = qid_to_category.keys() - source.keys()
    if missing:
        raise RuntimeError(f"Missing qids: {sorted(missing)}")

    queries, candidate_sets, annotations = [], [], []
    for qid, category in qid_to_category.items():
        row = source[qid]
        video = args.cache / "videos" / f"{row['vid']}.mp4"
        download(VIDEO_URL.format(prefix=row["vid"][0].lower(), vid=row["vid"]), video)
        segment_ids = list(range(int(row["duration"] // 4)))
        random.Random(args.seed + qid).shuffle(segment_ids)
        shared = {}
        for segment_id in segment_ids:
            stem = f"qvh4_{qid}__s{segment_id:02d}"
            shared[segment_id] = extract_candidate(
                video, args.output / "frames" / f"qvh4_{qid}", stem, segment_id * 4.0
            )

        for language, query in (("en", row["query"]), ("zh", QUERY_SPECS[category][qid])):
            query_id = f"qvh4_{qid}_{language}"
            candidates = []
            for rank, segment_id in enumerate(segment_ids, 1):
                start, end = segment_id * 4.0, segment_id * 4.0 + 4.0
                relevance, source_clips = label_4s(row, start, end)
                candidate_id = f"{query_id}__s{segment_id:02d}"
                candidate = {
                    "candidate_id": candidate_id, "rank": rank, "video_id": row["vid"],
                    "video_name": f"{row['vid']}.mp4", "start_time": start, "end_time": end,
                    "baseline_score": round(1 - rank / (len(segment_ids) + 1), 6),
                    "frame_paths": shared[segment_id],
                    "model_input": {"query": query, "mode": "visual_only", "frame_paths": shared[segment_id]},
                }
                candidates.append(candidate)
                annotations.append({
                    "query_id": query_id, "candidate_id": candidate_id, "relevance": relevance,
                    "source_clip_ids": source_clips, "category": category,
                })
            query_row = {
                "schema_version": 1, "query_id": query_id, "query": query, "language": language,
                "paired_query_id": f"qvh4_{qid}_{'zh' if language == 'en' else 'en'}",
                "source": "QVHighlights val", "source_qid": qid, "category": category,
                "mode": "visual_only", "constraints": [], "expected_video": row["vid"],
                "candidate_seconds": 4, "frames_per_candidate": 8, "candidates": candidates,
                "source_relevant_windows": row.get("relevant_windows", []),
            }
            queries.append(query_row)
            candidate_sets.append(query_row)

    write_jsonl(args.output / "queries.jsonl", queries)
    write_jsonl(args.output / "candidates" / "candidate_sets.jsonl", candidate_sets)
    write_jsonl(args.output / "annotations.jsonl", annotations)
    candidate_counts = [len(row["candidates"]) for row in candidate_sets]
    manifest = {
        "name": "qvhighlights_bilingual_categories_4s_v1", "source_split": "val",
        "source_license": "CC BY-NC-SA 4.0", "source_queries": len(qid_to_category),
        "language_queries": len(queries), "categories": {key: len(value) for key, value in QUERY_SPECS.items()},
        "candidate_seconds": 4, "frames_per_candidate": 8,
        "candidates_per_query": {"min": min(candidate_counts), "max": max(candidate_counts)},
        "language_candidates": sum(candidate_counts),
        "seed": args.seed, "selected_qids": list(qid_to_category),
    }
    (args.output / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))


if __name__ == "__main__":
    main()
