# QVHighlights Reranker 交付说明

## 内容

```text
qvhighlights-reranker-v1/
├── README.md
├── dataset/
│   └── qvhighlights_bilingual_categories_4s_v1/
├── source/
│   └── qvhighlights_categories_4s/
│       ├── highlight_val_release.jsonl
│       └── videos/
├── scripts/
│   ├── qvhighlights_category_4s_subset.py
│   ├── qwen3_vl_reranker_benchmark.py
│   ├── vlm_rerank_benchmark.py
│   └── summarize_vlm_rerank_benchmark.py
└── reference/
    └── qwen3-vl-reranker-2b-low-b4.json
```

模型权重和运行环境不包含在交付包中。

## 适用范围

本包用于离线评测：

```text
query + constraints + 4 秒候选的 8 张有序帧
→ VLM/Reranker 相关性分数
→ MRR、Hit@1/3、nDCG@3/20
```

当前 Python 推理脚本是 Ascend 版本，直接使用：

```python
import torch_npu
torch.device("npu:0")
```

如果目标服务器是 NVIDIA/CUDA，测试集、标注、指标和输出格式仍可复用，
但需要将模型适配部分的 `torch_npu`、`npu:0`、同步和显存统计替换为 CUDA。

## 最短使用流程

在解压后的 `qvhighlights-reranker-v1` 目录执行：

```bash
mkdir -p output

# 1. 确认数据完整
test -f dataset/qvhighlights_bilingual_categories_4s_v1/manifest.json
test -f dataset/qvhighlights_bilingual_categories_4s_v1/annotations.jsonl
test -f dataset/qvhighlights_bilingual_categories_4s_v1/candidates/candidate_sets.jsonl
find dataset/qvhighlights_bilingual_categories_4s_v1/frames -type f -name '*.jpg' | wc -l

# 预期图片数量：12392
```

然后确认模型类型，选择对应的 benchmark 脚本，先跑 8 个候选冒烟，
成功后再运行全量。

## 第一步：确认模型类型

```bash
export MODEL=/path/to/local/model

du -sh "$MODEL"
grep -E '"architectures"|"model_type"' "$MODEL/config.json"
grep -m 5 -E '^#|Reranker|Instruct' "$MODEL/README.md" 2>/dev/null || true
```

选择规则：

| 本地模型 | 使用脚本 | 打分方式 |
|---|---|---|
| Qwen3-VL-2B/4B/8B-Instruct | `vlm_rerank_benchmark.py` | 生成 0--3 分 |
| Qwen3-VL-Reranker-2B/8B | `qwen3_vl_reranker_benchmark.py` | `yes/no` 连续相关性分数 |
| HTTP/vLLM/MindIE 服务 | 当前脚本不能直接使用 | 需要 API client adapter |

不要把普通 Qwen3-VL-Instruct 交给专用 Reranker 脚本。脚本即使能够加载，
其 `yes/no` 权重差也不代表经过专用精排训练的分数。

## 第二步：检查运行环境

当前参考环境：

```text
Python       3.11.6
torch        2.9.0
torch_npu    2.9.0.post1
transformers 4.57.1
Pillow       11.2.1
CANN         8.5.1
Ascend       910B4 32G
```

检查关键依赖：

```bash
python - <<'PY'
import sys
import torch
import torch_npu
import transformers
import PIL

print("python:", sys.version)
print("torch:", torch.__version__)
print("torch_npu:", torch_npu.__version__)
print("transformers:", transformers.__version__)
print("pillow:", PIL.__version__)
print("npu_count:", torch.npu.device_count())
PY
```

如果模型已经部署为长期 HTTP 服务，而不是本地 Hugging Face/ModelScope
权重目录，当前脚本不会调用该服务，需要另写 HTTP 适配器。

## 数据说明

- 来源：QVHighlights validation split
- 许可：CC BY-NC-SA 4.0
- 42 个语义 query，中文和英文共 84 个语言 query
- 7 个查询类别
- 42 个源视频片段
- 每个候选 4 秒、2 FPS、8 帧
- 3,098 个语言候选
- 0--3 级相关性标注

现成帧数据可以直接运行 benchmark。源视频和构建脚本用于重新生成数据，
例如改变候选时长、FPS 或帧数。

候选池是每条 query 对应源视频中的全部 4 秒片段，并按固定种子打乱。
它主要测试同视频内的时序定位和精排，不等同于产品中的跨视频、多通路
真实召回 Top-K。

源视频文件名包含其在原长视频中的时间范围，例如：

```text
QHFy-nWNJYk_210.0_360.0.mp4
```

表示原视频第 210--360 秒的约 150 秒片段。候选 JSON 中的
`start_time`/`end_time` 相对于这个本地片段。

## 可选：从原视频重新生成 4 秒、8 帧数据

构建脚本当前固定使用 4 秒候选、2 FPS、8 帧。运行：

```bash
python scripts/qvhighlights_category_4s_subset.py \
  --cache source/qvhighlights_categories_4s \
  --annotation source/qvhighlights_categories_4s/highlight_val_release.jsonl \
  --output output/qvhighlights_bilingual_categories_4s_v1 \
  --seed 20260722
```

重新生成需要：

```text
Python 3.11+
ffmpeg
curl
约 400 MB 可用磁盘空间
```

脚本在目标文件已经存在时复用视频和候选帧。若要改变帧数、FPS 或候选时长，
需要修改 `extract_candidate()` 以及候选切分和标签重叠计算逻辑，并输出到新的
数据集目录，避免覆盖当前版本。

## 第三步：运行冒烟

### 普通 Qwen3-VL 冒烟

```bash
python scripts/vlm_rerank_benchmark.py \
  --model /path/to/Qwen3-VL-Instruct \
  --dataset dataset/qvhighlights_bilingual_categories_4s_v1 \
  --output output/qwen3-vl-smoke.json \
  --batch-size 1 \
  --limit 8 \
  --disable-thinking
```

冒烟成功的判断：

```text
进度达到 8/8
输出 JSON 文件存在且可以解析
没有 NPU OOM
每个候选都有 rerank_score
```

### Qwen3-VL-Reranker 冒烟

```bash
python scripts/qwen3_vl_reranker_benchmark.py \
  --model /path/to/Qwen3-VL-Reranker \
  --dataset dataset/qvhighlights_bilingual_categories_4s_v1 \
  --output output/reranker-smoke.json \
  --batch-size 1 \
  --limit 8
```

冒烟成功后移除 `--limit 8`，再根据显存逐步增加 batch size。

## 第四步：运行全量

普通 Qwen3-VL：

```bash
python scripts/vlm_rerank_benchmark.py \
  --model "$MODEL" \
  --dataset dataset/qvhighlights_bilingual_categories_4s_v1 \
  --output output/qwen3-vl-full.json \
  --batch-size 1 \
  --disable-thinking
```

专用 Qwen3-VL-Reranker：

```bash
python scripts/qwen3_vl_reranker_benchmark.py \
  --model "$MODEL" \
  --dataset dataset/qvhighlights_bilingual_categories_4s_v1 \
  --output output/reranker-full.json \
  --batch-size 1
```

第一次完整运行建议从 `batch-size=1` 开始。显存稳定后再尝试：

```text
2B：batch 2 或 4
4B：batch 2 或 4
8B：batch 1，再尝试 batch 2
```

参考的 Reranker-2B 在 32G 910B4 上可使用 batch 4。不同模型、帧数、
visual tokens 和推理后端的显存不能直接类推。

## 第五步：生成分类和语言汇总

```bash
python scripts/summarize_vlm_rerank_benchmark.py \
  output/reranker-full.json \
  --output output/reranker-full.summary.json
```

汇总包含：

```text
总体 MRR、Hit@1/3、nDCG@3/20
中英文拆分
七个查询类别拆分
P@5/20/30
R@5/20/30
延迟与峰值显存
```

主结果 JSON 中：

```text
baseline：候选原顺序指标
reranked：模型重排后的指标
rows：每个候选的分数、标签、原始rank和延迟
```

## 现有 Reranker-2B 参考结果

当前 Ascend 910B4、BF16、batch 4、每帧 128--256 visual tokens：

```text
MRR:       0.9286
Hit@1:     0.8810
Hit@3:     0.9881
nDCG@3:    0.7661
nDCG@20:   0.8802
Latency:   0.233 秒/候选
Peak HBM:  5.508 GiB allocated
```

速度和显存只能在相同硬件、软件后端和输入配置下直接比较。

参考结果文件：

```text
reference/qwen3-vl-reranker-2b-low-b4.json
```

## 常见问题

### `ModuleNotFoundError: torch_npu`

当前不是可用的 Ascend PyTorch 环境。需要使用与目标 CANN/驱动匹配的
`torch` 和 `torch_npu`，或者把脚本适配为 CUDA。

### `NPU out of memory`

依次尝试：

```text
1. 将 batch size 降到 1
2. 将 max visual tokens 从 256 降低
3. 减少每个候选的帧数
4. 确认同一张 NPU 没有其他模型进程
```

改变 visual tokens 或帧数后，质量和速度结果不能再与参考结果直接比较。

### `KeyError: yes` 或模型结构字段不存在

通常是把普通 Qwen3-VL-Instruct 交给了专用 Reranker 脚本。改用：

```text
scripts/vlm_rerank_benchmark.py
```

### 找不到图片

不要单独移动 `candidate_sets.jsonl`。其中保存的是相对于数据集根目录的路径：

```text
frames/qvh4_xxxx/xxx.jpg
```

`--dataset` 必须指向同时包含 `annotations.jsonl`、`candidates/` 和
`frames/` 的完整数据集目录。

### 模型尝试联网下载

两个 benchmark 均使用 `local_files_only=True`。请确认本地模型目录包含：

```text
config.json
model.safetensors 或完整分片
tokenizer.json / tokenizer配置
processor配置
chat_template
```

### `torchvision/image.so` 警告

如果 Pillow 可以正常读取 JPEG 且 benchmark 已开始输出候选进度，这个警告
通常不影响当前基于 Pillow 的图片输入。若模型依赖 `torchvision.io` 解码，
则需要修复 torchvision 与 PyTorch 的版本匹配。
