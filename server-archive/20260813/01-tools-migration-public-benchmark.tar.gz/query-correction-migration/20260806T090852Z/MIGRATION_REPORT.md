# 文本框订正结构化迁移报告

- 执行时间：2026-08-06T09:08:52.046553+00:00
- 审计文本/备注记录：23
- 应用时间段订正：19
- 修改审核文件：2
- 原始标注 JSON 修改：0
- 备份目录：`/home/momentseek-29154/annotation-review/backups/legacy-text-migration-20260806T090852Z`

## 已结构化记录

- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q005`：[[17.0, 18.0], [33.5, 35.0], [39.2, 41.2]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q018`：[[155.0, 172.5]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q021`：[[210.2, 216.2]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q022`：[[216.5, 222.5]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q026`：[[342.4, 357.0]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q037`：[[619.8, 624.0]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q039`：[[677.4, 682.8]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q041`：[[691.0, 694.0]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q042`：[[711.0, 720.0]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q043`：[[720.0, 735.8]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q045`：[[750.0, 767.0]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q046`：[[767.2, 772.5], [776.8, 785.0]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q047`：[[792.8, 795.0]]（source_annotation_retained_over_legacy_start_minute_typo）
  - 注意：Legacy text says 11:12.8-13:15.0, but the source annotation is 13:12.8-13:15.0; retained the coherent 2.2-second source interval.
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q052`：[[973.5, 985.8]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q054`：[[1061.2, 1069.0], [1073.0, 1076.8]]（source_annotation_already_contains_text_correction）
- `chinese_restaurant_nanyang_ep5_direct` / `中餐厅·南洋拾光季_独家直拍第5期_q058`：[[1154.8, 1180.2]]（source_annotation_already_contains_text_correction）
- `flower_youth_silk_road_ep7` / `flower_youth_silk_road_ep7_v7_q002`：[[1108.0, 1112.0], [4035.0, 4040.0], [4640.0, 4645.0], [4651.0, 4654.0], [4898.48, 4902.0], [4925.0, 4928.0], [4994.0, 4996.76]]（parsed_from_legacy_text_and_manually_verified）
- `flower_youth_silk_road_ep7` / `flower_youth_silk_road_ep7_v7_q029`：[[933.0, 940.0], [1369.0, 1373.0], [1373.0, 1385.0], [1375.0, 1388.0]]（parsed_from_legacy_text_and_manually_verified）
- `flower_youth_silk_road_ep7` / `flower_youth_silk_road_ep7_v7_q088`：[[2680.0, 2850.0]]（parsed_from_legacy_text_and_manually_verified）
