# 公开集 Query 与视频资产盘点

生成时间：2026-08-06T06:53:20.131306+00:00

## 结论摘要

- Query：114 条，唯一 Query ID：114。
- 选中视频：113 个；已匹配：109 个；缺失：4 个。
- 视频目录：109 个文件，总大小 0.99 GiB；未被当前 Query 选中的额外视频 0 个。
- 可用视频总时长 3.67 小时；含音轨 72 个，无音轨 37 个。
- 正例片段：143 个，总标注时长 2919.6 秒。
- `video_status=download_required` 但视频已存在的 Query：110 条。
- 声明时长与文件时长相差超过 0.5 秒：34 条 Query。
- 其中需优先核验的时长大偏差（绝对值 > 1.5 秒）：5 条；TVR 约 0.6 秒系统性尾差：27 条。
- 越界或非法正例片段：0 个；无法解析的视频：0 个。

## 风险分级与建议

1. **P0：补齐 4 个缺失的 ActivityNet 视频。** 当前 114 条 Query 无法形成完整闭集评测。
2. **P0：确认 TVR 的使用目标。** 37 个 TVR 文件全部无音轨；若要评测 ASR、人物对话或音频检索通路，需要重新取得带音轨版本，或明确把 TVR 限定为视觉检索集。
3. **P1：复核 5 条 ActivityNet 大时长偏差。** 文件比声明时长短 1.943–59.690 秒；正例片段目前没有越界，但视频上下文可能不完整。
4. **P1：生成状态覆盖表。** 原 JSON 的 114 条记录都还是 `download_required`，其中 110 条实际已经下载；建议生成派生状态清单，不直接改源标注。
5. **P2：TVR 的约 0.6 秒尾差可按封装/帧率系统误差处理。** 当前没有正例越界，不建议仅为此重切视频。
6. **P2：正式汇总指标时按能力分层。** 一级能力样本数从 5 到 20 不等，且能力与来源数据集强相关，直接算单一总均值会被 QVHighlights 和前三类能力主导。

## 数据集分布

| 数据集 | Query 数 |
| --- | --- |
| ActivityNet Captions | 9 |
| ActivityNet-Entities | 5 |
| QVHighlights | 62 |
| TVR | 38 |

## 一级能力分布

| 能力 ID | 能力名称 | Query 数 |
| --- | --- | --- |
| 1_visual_scene_search | 场景与主体检索 | 20 |
| 2_fine_grained_search | 细粒度目标检索 | 20 |
| 3_action_event_search | 动作与事件检索 | 20 |
| 4_person_character_search | 人物与角色检索 | 10 |
| 5_text_evidence_search | 文本内容检索 | 10 |
| 6_shot_cinematic_search | 镜头语言检索 | 14 |
| 7_hybrid_search | 复合语义检索 | 15 |
| 8_advanced_search | 困难查询 | 5 |

## 二级能力分布

| 子能力 ID | 子能力名称 | Query 数 |
| --- | --- | --- |
| 1.1_scene_environment | 场景环境理解 | 5 |
| 1.2_main_subject | 主体目标识别 | 5 |
| 1.3_visual_attribute | 视觉属性理解 | 5 |
| 1.4_atmosphere | 氛围环境理解 | 5 |
| 2.1_subject_multi_attribute | 人物/物体属性组合 | 5 |
| 2.2_prop_local_object | 道具与局部目标 | 5 |
| 2.3_spatial_relation | 空间关系理解 | 5 |
| 2.4_quantity_combination | 数量与组合目标 | 5 |
| 3.1_person_action | 人物动作理解 | 5 |
| 3.2_person_interaction | 人物交互理解 | 5 |
| 3.3_person_object_interaction | 人与物交互理解 | 5 |
| 3.4_event_process | 事件过程理解 | 5 |
| 4.3_person_expression | 人物表情检索 | 5 |
| 4.5_person_dialogue | 人物对话检索 | 5 |
| 5.4_text_topic_semantic | 文本语义理解 | 5 |
| 5.5_brand_logo | 品牌 Logo 检索 | 5 |
| 6.2_composition_viewpoint | 构图与视角理解 | 5 |
| 6.3_camera_movement | 运镜方式理解 | 4 |
| 6.4_visual_style | 视觉风格理解 | 5 |
| 7.1_subject_attribute_action | 主体+属性+动作组合 | 5 |
| 7.2_person_plot_scene | 人物+剧情+场景组合 | 5 |
| 7.3_visual_text_joint | 视觉+文本联合检索 | 5 |
| 8.2_abstract_semantics | 抽象语义理解 | 5 |

## 质量检查

- 重复 Query ID：0
- 完全相同 Query 文本组：0
- 重复源 Query 键：0
- 缺失视频：4
- 额外视频：0
- 样本哈希疑似重复视频组：0

### 缺失视频

| Query ID | 数据集 | Video ID | 预期路径 |
| --- | --- | --- | --- |
| public-v1-2-2-02 | ActivityNet-Entities | v_rQZIJBinOsw | activitynet/v_rQZIJBinOsw.mp4 |
| public-v1-2-2-03 | ActivityNet-Entities | v_pMDFkrK0KRc | activitynet/v_pMDFkrK0KRc.mp4 |
| public-v1-3-1-03 | ActivityNet Captions | v_EvJqfGXb5Fo | activitynet/v_EvJqfGXb5Fo.mp4 |
| public-v1-3-2-01 | ActivityNet Captions | v_yE5whKJ-DE4 | activitynet/v_yE5whKJ-DE4.mp4 |

### 时长差异超过 0.5 秒

| Query ID | Video ID | 声明时长 | 文件时长 | 差值 |
| --- | --- | --- | --- | --- |
| public-v1-1-4-05 | bTqMo5klaCE_660.0_810.0 | 150.0 | 148.774 | -1.226 |
| public-v1-2-2-04 | v_juiMCvZUYwk | 144.01 | 103.374 | -40.636 |
| public-v1-2-2-05 | v_K6Tm5xHkJ5c | 114.64 | 112.697 | -1.943 |
| public-v1-2-3-05 | castle_s06e13_seg02_clip_26 | 135.02 | 135.667 | 0.647 |
| public-v1-2-4-05 | s02e11_seg02_clip_09 | 76.03999999999999 | 76.667 | 0.627 |
| public-v1-3-1-01 | v_GGSY1Qvo990 | 18.16 | 12.33 | -5.83 |
| public-v1-3-1-02 | v_8fZbv6OUEm8 | 64.11 | 59.513 | -4.597 |
| public-v1-3-2-02 | v_6Yn2U58qxPs | 214.95 | 155.26 | -59.69 |
| public-v1-3-3-05 | friends_s10e11_seg02_clip_04 | 58.03 | 58.667 | 0.637 |
| public-v1-4-3-01 | s02e14_seg02_clip_02 | 64.02 | 64.667 | 0.647 |
| public-v1-4-3-04 | house_s04e16_seg02_clip_08 | 104.02000000000001 | 104.667 | 0.647 |
| public-v1-4-3-05 | friends_s02e16_seg01_clip_00 | 66.04 | 66.667 | 0.627 |
| public-v1-4-5-02 | friends_s07e09_seg02_clip_02 | 59.03 | 59.667 | 0.637 |
| public-v1-4-5-03 | friends_s08e08_seg01_clip_00 | 61.03 | 61.667 | 0.637 |
| public-v1-4-5-04 | friends_s10e16_seg02_clip_18 | 61.03 | 61.667 | 0.637 |
| public-v1-4-5-05 | house_s06e12_seg02_clip_10 | 86.02 | 86.667 | 0.647 |
| public-v1-5-4-01 | castle_s07e01_seg02_clip_18 | 88.02 | 88.667 | 0.647 |
| public-v1-5-4-02 | castle_s08e20_seg02_clip_22 | 89.08 | 89.667 | 0.587 |
| public-v1-5-4-03 | s07e18_seg02_clip_00 | 61.04 | 61.667 | 0.627 |
| public-v1-5-4-04 | s01e16_seg02_clip_01 | 57.03 | 57.667 | 0.637 |
| public-v1-5-4-05 | friends_s08e15_seg02_clip_18 | 63.03 | 63.667 | 0.637 |
| public-v1-6-3-01 | castle_s08e02_seg02_clip_12 | 92.03 | 92.667 | 0.637 |
| public-v1-6-3-02 | castle_s06e23_seg02_clip_15 | 95.03 | 95.667 | 0.637 |
| public-v1-6-3-03 | castle_s06e23_seg02_clip_15 | 95.03 | 95.667 | 0.637 |
| public-v1-6-4-03 | 6JnES9tDKy8_210.0_360.0 | 134.0 | 133.028 | -0.972 |
| public-v1-7-1-05 | house_s02e01_seg02_clip_14 | 98.03 | 98.667 | 0.637 |
| public-v1-7-2-01 | castle_s08e17_seg02_clip_22 | 92.03 | 92.667 | 0.637 |
| public-v1-7-2-02 | house_s06e11_seg02_clip_09 | 96.03 | 96.667 | 0.637 |
| public-v1-7-2-03 | friends_s07e04_seg02_clip_13 | 64.03 | 64.667 | 0.637 |
| public-v1-7-2-04 | house_s02e11_seg02_clip_24 | 86.15 | 86.667 | 0.517 |
| public-v1-7-2-05 | castle_s08e01_seg02_clip_25 | 96.03 | 96.667 | 0.637 |
| public-v1-7-3-04 | met_s06e19_seg02_clip_12 | 60.03 | 60.667 | 0.637 |
| public-v1-7-3-05 | house_s05e09_seg02_clip_21 | 94.03 | 94.667 | 0.637 |
| public-v1-8-2-05 | castle_s08e11_seg02_clip_24 | 92.03 | 92.667 | 0.637 |

## 文件说明

- `public_benchmark_inventory.json`：完整机器可读盘点与检查结果。
- `public_benchmark_queries.csv`：逐 Query 映射、时长和正例统计。
- `public_benchmark_videos.csv`：逐视频编码、分辨率、时长、大小和样本哈希。
