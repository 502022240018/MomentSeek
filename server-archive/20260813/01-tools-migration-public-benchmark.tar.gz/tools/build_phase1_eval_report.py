#!/usr/bin/env python3
"""Build phase-1 evaluation reports from frozen catalogs and saved responses.

The primary temporal rule is deliberately simple: same source video and a
positive-duration overlap. IoU is not calculated or exposed by this report.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import html
import json
import math
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


FIXED_KS = (1, 3, 5, 10, 20, 50)
CLUSTER_GAP_SECONDS = 2.0


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def response_filename(semantic_query_id: str) -> str:
    return hashlib.sha1(semantic_query_id.encode("utf-8")).hexdigest()[:20] + ".json"


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def percentile(values: list[float], p: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    return ordered[max(0, math.ceil(len(ordered) * p) - 1)]


def answer_bucket(count: int) -> str:
    if count == 1:
        return "1"
    if count == 2:
        return "2"
    if count <= 4:
        return "3-4"
    if count <= 9:
        return "5-9"
    return "10+"


def positive_overlap(left: tuple[float, float], right: tuple[float, float]) -> bool:
    return min(left[1], right[1]) > max(left[0], right[0])


def build_truth(group: dict[str, Any]) -> dict[str, list[tuple[float, float]]]:
    truth_sets: dict[str, set[tuple[float, float]]] = defaultdict(set)
    for record in group.get("records") or []:
        video_id = str(record["video_id"])
        for segment in record.get("segments") or []:
            truth_sets[video_id].add(
                (float(segment["start_sec"]), float(segment["end_sec"]))
            )
    return {video_id: sorted(spans) for video_id, spans in truth_sets.items()}


def maximum_matches(
    ranked: list[dict[str, Any]],
    truth: dict[str, list[tuple[float, float]]],
    limit: int,
) -> tuple[int, set[int], set[int]]:
    """Maximum-cardinality one-to-one matching for positive temporal overlap."""
    ground_truth = [
        (video_id, span)
        for video_id, spans in truth.items()
        for span in spans
    ]
    candidates = ranked[:limit]
    adjacency: list[list[int]] = []
    for result in candidates:
        span = (float(result["start_sec"]), float(result["end_sec"]))
        edges = [
            index
            for index, (video_id, gt_span) in enumerate(ground_truth)
            if video_id == result["source_video_id"] and positive_overlap(span, gt_span)
        ]
        adjacency.append(edges)

    matched_result_by_truth: dict[int, int] = {}

    def augment(result_index: int, seen: set[int]) -> bool:
        for truth_index in adjacency[result_index]:
            if truth_index in seen:
                continue
            seen.add(truth_index)
            previous = matched_result_by_truth.get(truth_index)
            if previous is None or augment(previous, seen):
                matched_result_by_truth[truth_index] = result_index
                return True
        return False

    for result_index in range(len(candidates)):
        augment(result_index, set())
    return (
        len(matched_result_by_truth),
        set(matched_result_by_truth),
        set(matched_result_by_truth.values()),
    )


def temporal_cluster_count(ranked: list[dict[str, Any]], limit: int) -> int:
    """Count unique temporal locations after merging nearby results per video."""
    by_video: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for result in ranked[:limit]:
        by_video[str(result["source_video_id"])].append(
            (float(result["start_sec"]), float(result["end_sec"]))
        )
    clusters = 0
    for spans in by_video.values():
        current_end: float | None = None
        for start, end in sorted(spans):
            if current_end is None or start > current_end + CLUSTER_GAP_SECONDS:
                clusters += 1
                current_end = end
            else:
                current_end = max(current_end, end)
    return clusters


def score_at_limit(
    ranked: list[dict[str, Any]],
    truth: dict[str, list[tuple[float, float]]],
    limit: int,
) -> dict[str, Any]:
    total = sum(len(spans) for spans in truth.values())
    returned = min(limit, len(ranked))
    matched, matched_truth, matched_results = maximum_matches(ranked, truth, limit)
    clusters = temporal_cluster_count(ranked, limit)
    return {
        "limit": limit,
        "returned": returned,
        "matched": matched,
        "ground_truth": total,
        "recall": matched / total if total else 0.0,
        "success": matched > 0,
        "complete": matched == total if total else False,
        "partial": 0 < matched < total,
        "zero": matched == 0,
        "matched_truth_indexes": sorted(matched_truth),
        "matched_result_indexes": sorted(matched_results),
        "temporal_cluster_count": clusters,
        "redundant_result_count": max(0, returned - clusters),
        "redundancy_rate": (returned - clusters) / returned if returned else 0.0,
    }


def ranked_from_results(
    results: list[dict[str, Any]], platform_to_source: dict[str, str]
) -> list[dict[str, Any]]:
    ranked = []
    for rank, result in enumerate(results, start=1):
        ranked.append(
            {
                "rank": rank,
                "platform_video_id": str(result.get("video_id") or ""),
                "source_video_id": platform_to_source.get(str(result.get("video_id") or ""), ""),
                "start_sec": float(result.get("start_time") or 0),
                "end_sec": float(result.get("end_time") or 0),
                "score": result.get("score"),
                "modalities": result.get("modalities") or [],
            }
        )
    return ranked


def ranked_from_reranker_candidates(
    candidates: list[dict[str, Any]], platform_to_source: dict[str, str]
) -> list[dict[str, Any]]:
    ranked = []
    for candidate in sorted(candidates, key=lambda row: int(row.get("original_rank") or 999999)):
        ranked.append(
            {
                "rank": len(ranked) + 1,
                "platform_video_id": str(candidate.get("video_id") or ""),
                "source_video_id": platform_to_source.get(str(candidate.get("video_id") or ""), ""),
                "start_sec": float(candidate.get("original_start_time") or candidate.get("start_time") or 0),
                "end_sec": float(candidate.get("original_end_time") or candidate.get("end_time") or 0),
                "score": candidate.get("retrieval_score"),
                "modalities": [],
            }
        )
    return ranked


def first_hit_rank(ranked: list[dict[str, Any]], truth: dict[str, list[tuple[float, float]]]) -> int | None:
    for rank in range(1, len(ranked) + 1):
        if maximum_matches(ranked, truth, rank)[0] > 0:
            return rank
    return None


def reranker_diagnostic(
    execution: dict[str, Any],
    final_ranked: list[dict[str, Any]],
    truth: dict[str, list[tuple[float, float]]],
    platform_to_source: dict[str, str],
) -> dict[str, Any] | None:
    reranker = execution.get("reranker") or {}
    if reranker.get("status") != "ok" or not reranker.get("candidates"):
        return None
    before = ranked_from_reranker_candidates(reranker["candidates"], platform_to_source)
    comparison_limit = min(len(before), 15)
    after = final_ranked[:comparison_limit]
    metrics = {}
    for limit in (1, 5, 10, comparison_limit):
        if limit <= 0:
            continue
        metrics[f"@{limit}"] = {
            "before": score_at_limit(before, truth, limit),
            "after": score_at_limit(after, truth, limit),
        }
    return {
        "candidate_count": len(before),
        "comparison_limit": comparison_limit,
        "first_hit_rank_before": first_hit_rank(before, truth),
        "first_hit_rank_after": first_hit_rank(after, truth),
        "metrics": metrics,
        "elapsed_seconds": reranker.get("elapsed_seconds"),
    }


def score_query(
    group: dict[str, Any],
    response: dict[str, Any],
    platform_to_source: dict[str, str],
) -> dict[str, Any]:
    truth = build_truth(group)
    total = sum(len(spans) for spans in truth.values())
    ranked = ranked_from_results(response.get("results") or [], platform_to_source)
    fixed = {f"@{limit}": score_at_limit(ranked, truth, limit) for limit in FIXED_KS}
    n_limit = min(50, total)
    two_n_limit = min(50, max(1, 2 * total))
    execution = response.get("execution") or {}
    plan = execution.get("plan") or (execution.get("planner") or {}).get("plan") or {}
    channels = list(plan.get("modalities") or response.get("modalities") or [])
    row = {
        "semantic_query_id": str(group["semantic_query_id"]),
        "query": group.get("query"),
        "category": group.get("category"),
        "subcategory": group.get("subcategory"),
        "source_kinds": group.get("source_kinds") or [],
        "ground_truth_video_count": len(truth),
        "ground_truth_segment_count": total,
        "answer_bucket": answer_bucket(total),
        "multi_answer": total > 1,
        "first_hit_rank": first_hit_rank(ranked, truth),
        "latency_seconds": float(response.get("elapsed_seconds") or execution.get("elapsed_seconds") or 0),
        "planner_intent": str(plan.get("query_intent") or "unknown"),
        "planned_channels": channels,
        "planned_channel_key": ",".join(channels) or "none",
        "reranker_status": str((execution.get("reranker") or {}).get("status") or "unknown"),
        "fixed": fixed,
        "adaptive": {
            "@N": score_at_limit(ranked, truth, n_limit),
            "@2N": score_at_limit(ranked, truth, two_n_limit),
        },
        "reranker_diagnostic": reranker_diagnostic(
            execution, ranked, truth, platform_to_source
        ),
        "ranked": ranked,
    }
    return row


def status_distribution(entries: list[dict[str, Any]]) -> dict[str, int]:
    return {
        "complete": sum(1 for entry in entries if entry["complete"]),
        "partial": sum(1 for entry in entries if entry["partial"]),
        "zero": sum(1 for entry in entries if entry["zero"]),
    }


def aggregate_limit(entries: list[dict[str, Any]]) -> dict[str, Any]:
    if not entries:
        return {
            "query_count": 0,
            "macro_recall": None,
            "micro_recall": None,
            "matched": 0,
            "ground_truth": 0,
            "success_rate": None,
            "complete_rate": None,
            "partial_rate": None,
            "zero_rate": None,
            "mean_redundancy_rate": None,
            "micro_redundancy_rate": None,
        }
    matched = sum(entry["matched"] for entry in entries)
    truth = sum(entry["ground_truth"] for entry in entries)
    redundant = sum(entry["redundant_result_count"] for entry in entries)
    returned = sum(entry["returned"] for entry in entries)
    return {
        "query_count": len(entries),
        "macro_recall": round(statistics.mean(entry["recall"] for entry in entries), 4),
        "micro_recall": round(matched / truth, 4) if truth else None,
        "matched": matched,
        "ground_truth": truth,
        "success_rate": round(sum(entry["success"] for entry in entries) / len(entries), 4),
        "complete_rate": round(sum(entry["complete"] for entry in entries) / len(entries), 4),
        "partial_rate": round(sum(entry["partial"] for entry in entries) / len(entries), 4),
        "zero_rate": round(sum(entry["zero"] for entry in entries) / len(entries), 4),
        "mean_redundancy_rate": round(
            statistics.mean(entry["redundancy_rate"] for entry in entries), 4
        ),
        "micro_redundancy_rate": round(redundant / returned, 4) if returned else None,
        "redundant_results": redundant,
        "returned_results": returned,
    }


def stage_latency(rows: list[dict[str, Any]], responses: dict[str, dict[str, Any]]) -> dict[str, Any]:
    values: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        response = responses[row["semantic_query_id"]]
        execution = response.get("execution") or {}
        for key, value in (
            ("planner", (execution.get("planner") or {}).get("elapsed_seconds")),
            ("retrieval", (execution.get("retrieval") or {}).get("elapsed_seconds")),
            ("reranker", (execution.get("reranker") or {}).get("elapsed_seconds")),
            ("total", response.get("elapsed_seconds") or execution.get("elapsed_seconds")),
        ):
            if isinstance(value, (int, float)):
                values[key].append(float(value))
    return {
        key: {
            "count": len(items),
            "mean": round(statistics.mean(items), 3),
            "median": round(statistics.median(items), 3),
            "p95": round(percentile(items, 0.95) or 0, 3),
            "max": round(max(items), 3),
        }
        for key, items in values.items()
        if items
    }


def aggregate_reranker(rows: list[dict[str, Any]]) -> dict[str, Any]:
    diagnostics = [row["reranker_diagnostic"] for row in rows if row.get("reranker_diagnostic")]
    result: dict[str, Any] = {
        "status_counts": dict(Counter(row["reranker_status"] for row in rows)),
        "diagnosed_query_count": len(diagnostics),
    }
    for limit in (1, 5, 10, 15):
        pairs = [d["metrics"].get(f"@{limit}") for d in diagnostics]
        pairs = [pair for pair in pairs if pair]
        if not pairs:
            continue
        deltas = [pair["after"]["matched"] - pair["before"]["matched"] for pair in pairs]
        result[f"@{limit}"] = {
            "query_count": len(pairs),
            "improved_queries": sum(delta > 0 for delta in deltas),
            "degraded_queries": sum(delta < 0 for delta in deltas),
            "unchanged_queries": sum(delta == 0 for delta in deltas),
            "net_matched_segment_delta": sum(deltas),
            "before_success_rate": round(
                sum(pair["before"]["success"] for pair in pairs) / len(pairs), 4
            ),
            "after_success_rate": round(
                sum(pair["after"]["success"] for pair in pairs) / len(pairs), 4
            ),
            "before_macro_recall": round(
                statistics.mean(pair["before"]["recall"] for pair in pairs), 4
            ),
            "after_macro_recall": round(
                statistics.mean(pair["after"]["recall"] for pair in pairs), 4
            ),
        }
    return result


def aggregate_rows(
    rows: list[dict[str, Any]], responses: dict[str, dict[str, Any]] | None = None
) -> dict[str, Any]:
    result: dict[str, Any] = {"query_count": len(rows)}
    latencies = [row["latency_seconds"] for row in rows]
    result["latency_seconds"] = {
        "mean": round(statistics.mean(latencies), 3) if latencies else None,
        "median": round(statistics.median(latencies), 3) if latencies else None,
        "p95": round(percentile(latencies, 0.95) or 0, 3) if latencies else None,
        "max": round(max(latencies), 3) if latencies else None,
    }
    result["fixed"] = {
        f"@{limit}": aggregate_limit([row["fixed"][f"@{limit}"] for row in rows])
        for limit in FIXED_KS
    }
    result["single_answer"] = {
        f"@{limit}": aggregate_limit(
            [row["fixed"][f"@{limit}"] for row in rows if not row["multi_answer"]]
        )
        for limit in FIXED_KS
    }
    multi = [row for row in rows if row["multi_answer"]]
    result["multi_answer"] = {
        "query_count": len(multi),
        "fixed": {
            f"@{limit}": aggregate_limit([row["fixed"][f"@{limit}"] for row in multi])
            for limit in FIXED_KS
        },
        "adaptive": {
            label: aggregate_limit([row["adaptive"][label] for row in multi])
            for label in ("@N", "@2N")
        },
    }
    result["planner"] = {
        "intent_counts": dict(Counter(row["planner_intent"] for row in rows).most_common()),
        "channel_plan_counts": dict(
            Counter(row["planned_channel_key"] for row in rows).most_common()
        ),
    }
    result["reranker"] = aggregate_reranker(rows)
    if responses is not None:
        result["stage_latency_seconds"] = stage_latency(rows, responses)
    return result


def slice_rows(rows: list[dict[str, Any]], key: str) -> dict[str, list[dict[str, Any]]]:
    sliced: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        if key == "source_kind":
            values = row.get("source_kinds") or ["unknown"]
            for value in values:
                sliced[str(value)].append(row)
        else:
            sliced[str(row.get(key) or "unknown")].append(row)
    return dict(sorted(sliced.items()))


@dataclass
class RunData:
    key: str
    label: str
    run_dir: Path
    rows: list[dict[str, Any]]
    responses: dict[str, dict[str, Any]]
    summary: dict[str, Any]


def load_run(key: str, label: str, run_dir: Path) -> RunData:
    catalog = read_json(run_dir / "frozen_catalog.json")
    state = read_json(run_dir / "run_state.json")
    platform_to_source = {
        str(row["platform_video_id"]): source_id
        for source_id, row in state["videos"].items()
    }
    rows = []
    responses: dict[str, dict[str, Any]] = {}
    for group in catalog.get("groups") or []:
        semantic_id = str(group["semantic_query_id"])
        response_path = run_dir / "query_responses" / response_filename(semantic_id)
        response = read_json(response_path)
        responses[semantic_id] = response
        rows.append(score_query(group, response, platform_to_source))
    overall = aggregate_rows(rows, responses)
    summary = {
        "key": key,
        "label": label,
        "run_dir": str(run_dir),
        "folder": state.get("folder") or {},
        "catalog_actual": {
            "query_count": len(catalog.get("groups") or []),
            "record_count": sum(len(group.get("records") or []) for group in catalog.get("groups") or []),
            "segment_count": sum(row["ground_truth_segment_count"] for row in rows),
            "video_count": len(state.get("videos") or {}),
        },
        "overall": overall,
        "by_category": {
            name: aggregate_rows(value)
            for name, value in slice_rows(rows, "category").items()
        },
        "by_subcategory": {
            name: aggregate_rows(value)
            for name, value in slice_rows(rows, "subcategory").items()
        },
        "by_answer_bucket": {
            name: aggregate_rows(value)
            for name, value in slice_rows(rows, "answer_bucket").items()
        },
        "by_source_kind": {
            name: aggregate_rows(value)
            for name, value in slice_rows(rows, "source_kind").items()
        },
        "by_planned_channel": {
            name: aggregate_rows(value)
            for name, value in slice_rows(rows, "planned_channel_key").items()
        },
    }
    return RunData(key, label, run_dir, rows, responses, summary)


def paired_differences(runs: list[RunData]) -> dict[str, Any]:
    if len(runs) != 2:
        return {}
    left, right = runs
    right_rows = {row["semantic_query_id"]: row for row in right.rows}
    examples = []
    for row in left.rows:
        other = right_rows[row["semantic_query_id"]]
        delta5 = other["fixed"]["@5"]["matched"] - row["fixed"]["@5"]["matched"]
        delta10 = other["fixed"]["@10"]["matched"] - row["fixed"]["@10"]["matched"]
        examples.append(
            {
                "semantic_query_id": row["semantic_query_id"],
                "query": row["query"],
                "category": row["category"],
                "ground_truth_segment_count": row["ground_truth_segment_count"],
                f"{left.key}_matched_at_5": row["fixed"]["@5"]["matched"],
                f"{right.key}_matched_at_5": other["fixed"]["@5"]["matched"],
                f"{right.key}_minus_{left.key}_at_5": delta5,
                f"{right.key}_minus_{left.key}_at_10": delta10,
            }
        )
    delta_key = f"{right.key}_minus_{left.key}_at_5"
    return {
        "left": left.key,
        "right": right.key,
        "right_better_at_5": sorted(examples, key=lambda row: row[delta_key], reverse=True)[:30],
        "left_better_at_5": sorted(examples, key=lambda row: row[delta_key])[:30],
    }


def pct(value: float | None) -> str:
    return "—" if value is None else f"{value:.1%}"


def num(value: float | None) -> str:
    return "—" if value is None else f"{value:.3f}"


def render_comparison_html(payload: dict[str, Any], runs: list[RunData]) -> str:
    cards = []
    for run in runs:
        overall = run.summary["overall"]
        cards.append(
            f"<article class='run-card'><h2>{html.escape(run.label)}</h2>"
            f"<div class='metrics'><div><small>Success@1</small><b>{pct(overall['fixed']['@1']['success_rate'])}</b></div>"
            f"<div><small>Success@5</small><b>{pct(overall['fixed']['@5']['success_rate'])}</b></div>"
            f"<div><small>多答案 Recall@2N</small><b>{pct(overall['multi_answer']['adaptive']['@2N']['macro_recall'])}</b></div>"
            f"<div><small>多答案 Complete@2N</small><b>{pct(overall['multi_answer']['adaptive']['@2N']['complete_rate'])}</b></div>"
            f"<div><small>重复浪费@5</small><b>{pct(overall['fixed']['@5']['micro_redundancy_rate'])}</b></div>"
            f"<div><small>P95 延迟</small><b>{num(overall['latency_seconds']['p95'])}s</b></div></div></article>"
        )

    summary_rows = []
    metric_specs = [
        ("Success@1", lambda o: o["fixed"]["@1"]["success_rate"], pct),
        ("Success@5", lambda o: o["fixed"]["@5"]["success_rate"], pct),
        ("单答案 Hit@5", lambda o: o["single_answer"]["@5"]["success_rate"], pct),
        ("全集 Macro Recall@5", lambda o: o["fixed"]["@5"]["macro_recall"], pct),
        ("多答案 Macro Recall@5", lambda o: o["multi_answer"]["fixed"]["@5"]["macro_recall"], pct),
        ("多答案 Macro Recall@N", lambda o: o["multi_answer"]["adaptive"]["@N"]["macro_recall"], pct),
        ("多答案 Macro Recall@2N", lambda o: o["multi_answer"]["adaptive"]["@2N"]["macro_recall"], pct),
        ("多答案 Complete@2N", lambda o: o["multi_answer"]["adaptive"]["@2N"]["complete_rate"], pct),
        ("多答案 Zero@5", lambda o: o["multi_answer"]["fixed"]["@5"]["zero_rate"], pct),
        ("重复浪费率@5", lambda o: o["fixed"]["@5"]["micro_redundancy_rate"], pct),
        ("延迟中位数(s)", lambda o: o["latency_seconds"]["median"], num),
        ("延迟P95(s)", lambda o: o["latency_seconds"]["p95"], num),
    ]
    for label, getter, formatter in metric_specs:
        values = "".join(
            f"<td>{formatter(getter(run.summary['overall']))}</td>" for run in runs
        )
        summary_rows.append(f"<tr><th>{html.escape(label)}</th>{values}</tr>")

    categories = sorted({name for run in runs for name in run.summary["by_category"]})
    category_rows = []
    for category in categories:
        cells = []
        for run in runs:
            value = run.summary["by_category"].get(category)
            if not value:
                cells.append("<td>—</td>")
                continue
            cells.append(
                "<td>"
                f"S@5 {pct(value['fixed']['@5']['success_rate'])}<br>"
                f"M-R@5 {pct(value['multi_answer']['fixed']['@5']['macro_recall'])}<br>"
                f"重复 {pct(value['fixed']['@5']['micro_redundancy_rate'])}<br>"
                f"n={value['query_count']}"
                "</td>"
            )
        category_rows.append(f"<tr><th>{html.escape(category)}</th>{''.join(cells)}</tr>")

    buckets = ("1", "2", "3-4", "5-9", "10+")
    bucket_rows = []
    for bucket in buckets:
        cells = []
        for run in runs:
            value = run.summary["by_answer_bucket"].get(bucket)
            if not value:
                cells.append("<td>—</td>")
                continue
            cells.append(
                "<td>"
                f"Recall@5 {pct(value['fixed']['@5']['macro_recall'])}<br>"
                f"Complete@5 {pct(value['fixed']['@5']['complete_rate'])}<br>"
                f"Zero@5 {pct(value['fixed']['@5']['zero_rate'])}<br>"
                f"n={value['query_count']}"
                "</td>"
            )
        bucket_rows.append(f"<tr><th>{bucket}</th>{''.join(cells)}</tr>")

    architecture = []
    for run in runs:
        overall = run.summary["overall"]
        stage = overall.get("stage_latency_seconds") or {}
        rr = overall["reranker"]
        rr5 = rr.get("@5") or {}
        architecture.append(
            "<tr>"
            f"<th>{html.escape(run.label)}</th>"
            f"<td><pre>{html.escape(json.dumps(overall['planner']['channel_plan_counts'], ensure_ascii=False, indent=2))}</pre></td>"
            f"<td>{num((stage.get('planner') or {}).get('median'))}</td>"
            f"<td>{num((stage.get('retrieval') or {}).get('median'))}</td>"
            f"<td>{num((stage.get('reranker') or {}).get('median'))}</td>"
            f"<td>{rr.get('diagnosed_query_count', 0)}</td>"
            f"<td>{rr5.get('improved_queries', 0)} / {rr5.get('degraded_queries', 0)} / {rr5.get('unchanged_queries', 0)}</td>"
            f"<td>{rr5.get('net_matched_segment_delta', 0):+d}</td>"
            "</tr>"
        )

    worst_rows = []
    for run in runs:
        worst = sorted(
            [row for row in run.rows if row["multi_answer"]],
            key=lambda row: (
                -row["adaptive"]["@2N"]["zero"],
                row["adaptive"]["@2N"]["recall"],
                -row["ground_truth_segment_count"],
            ),
        )[:20]
        for row in worst:
            worst_rows.append(
                "<tr>"
                f"<td>{html.escape(run.label)}</td>"
                f"<td>{html.escape(str(row['category']))}</td>"
                f"<td>{html.escape(str(row['query']))}</td>"
                f"<td>{row['fixed']['@5']['matched']}/{row['ground_truth_segment_count']}</td>"
                f"<td>{row['adaptive']['@2N']['matched']}/{row['ground_truth_segment_count']}</td>"
                f"<td>{pct(row['fixed']['@5']['redundancy_rate'])}</td>"
                "</tr>"
            )

    headers = "".join(f"<th>{html.escape(run.label)}</th>" for run in runs)
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>341条测试集第一阶段指标</title>
<style>
body{{margin:0;background:#f3f6fb;color:#182033;font-family:system-ui,-apple-system,"Segoe UI",sans-serif}}main{{max-width:1500px;margin:auto;padding:28px}}h1{{margin-bottom:6px}}.muted{{color:#667085}}.run-grid{{display:grid;grid-template-columns:repeat({max(1,len(runs))},1fr);gap:16px;margin:22px 0}}.run-card,section{{background:#fff;border:1px solid #e0e6ef;border-radius:14px;padding:18px;box-shadow:0 2px 8px #1d293908}}.metrics{{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}}.metrics div{{background:#f7f9fc;border-radius:10px;padding:12px}}small{{display:block;color:#667085}}b{{font-size:24px}}section{{margin:18px 0;overflow:auto}}table{{border-collapse:collapse;width:100%}}th,td{{border-bottom:1px solid #e9edf3;padding:10px;text-align:left;vertical-align:top}}thead th{{background:#f7f9fc;position:sticky;top:0}}pre{{white-space:pre-wrap;margin:0;font-size:12px}}code{{background:#eef2f7;padding:2px 5px;border-radius:5px}}.note{{border-left:4px solid #3b82f6;padding-left:12px}}@media(max-width:900px){{.run-grid{{grid-template-columns:1fr}}.metrics{{grid-template-columns:1fr 1fr}}}}
</style></head><body><main>
<h1>341条视频检索测试集 · 第一阶段指标报告</h1>
<p class="muted">生成于 {html.escape(payload['generated_at'])}。命中规则：同一视频且时间段存在正长度重叠；不使用 IoU；多答案采用一对一匹配。</p>
<div class="run-grid">{''.join(cards)}</div>
<section><h2>核心指标对比</h2><table><thead><tr><th>指标</th>{headers}</tr></thead><tbody>{''.join(summary_rows)}</tbody></table></section>
<section><h2>按 Query 类型</h2><p class="muted">S@5=至少命中一个片段；M-R@5=该分类多答案 Query 的 Macro Recall@5。</p><table><thead><tr><th>分类</th>{headers}</tr></thead><tbody>{''.join(category_rows)}</tbody></table></section>
<section><h2>按标准片段数量</h2><table><thead><tr><th>片段数</th>{headers}</tr></thead><tbody>{''.join(bucket_rows)}</tbody></table></section>
<section><h2>平台架构诊断</h2><p class="note">Planner 路由正确率和 Fusion 前后损失无法从当前响应准确还原：测试集尚无“必要通路”标签，响应也未保存 Fusion 前逐通路候选。这里仅报告已保存的通路计划、阶段延迟及87条启用精排 Query 的候选前后变化。</p><table><thead><tr><th>方案</th><th>通路计划分布</th><th>Planner中位(s)</th><th>检索中位(s)</th><th>精排中位(s)</th><th>可诊断精排Query</th><th>改善/退化/不变@5</th><th>净片段变化@5</th></tr></thead><tbody>{''.join(architecture)}</tbody></table></section>
<section><h2>多答案优先复盘案例</h2><table><thead><tr><th>方案</th><th>分类</th><th>Query</th><th>命中@5</th><th>命中@2N</th><th>重复率@5</th></tr></thead><tbody>{''.join(worst_rows)}</tbody></table></section>
<section><h2>口径说明</h2><ul><li>固定预算反映用户只浏览 Top K 的体验。</li><li>Recall@N 和 @2N 按每条 Query 的标准片段数量调整结果预算，避免答案多的题被固定 Top 5 天然限制。</li><li>时间簇重复率将同一视频中重叠或相隔不超过 {CLUSTER_GAP_SECONDS:g} 秒的返回结果视为同一位置。</li><li>当前没有候选相关性负标注，因此 Precision@5、nDCG@5 和边界可用率留到第二阶段。</li></ul></section>
</main></body></html>"""


def write_query_csv(path: Path, runs: list[RunData]) -> None:
    fields = [
        "run",
        "semantic_query_id",
        "query",
        "category",
        "subcategory",
        "answer_bucket",
        "ground_truth_segment_count",
        "first_hit_rank",
        "matched_at_5",
        "recall_at_5",
        "matched_at_10",
        "recall_at_10",
        "matched_at_n",
        "recall_at_n",
        "matched_at_2n",
        "recall_at_2n",
        "complete_at_2n",
        "zero_at_5",
        "redundancy_at_5",
        "planned_channels",
        "reranker_status",
        "latency_seconds",
    ]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for run in runs:
            for row in run.rows:
                writer.writerow(
                    {
                        "run": run.label,
                        "semantic_query_id": row["semantic_query_id"],
                        "query": row["query"],
                        "category": row["category"],
                        "subcategory": row["subcategory"],
                        "answer_bucket": row["answer_bucket"],
                        "ground_truth_segment_count": row["ground_truth_segment_count"],
                        "first_hit_rank": row["first_hit_rank"],
                        "matched_at_5": row["fixed"]["@5"]["matched"],
                        "recall_at_5": row["fixed"]["@5"]["recall"],
                        "matched_at_10": row["fixed"]["@10"]["matched"],
                        "recall_at_10": row["fixed"]["@10"]["recall"],
                        "matched_at_n": row["adaptive"]["@N"]["matched"],
                        "recall_at_n": row["adaptive"]["@N"]["recall"],
                        "matched_at_2n": row["adaptive"]["@2N"]["matched"],
                        "recall_at_2n": row["adaptive"]["@2N"]["recall"],
                        "complete_at_2n": row["adaptive"]["@2N"]["complete"],
                        "zero_at_5": row["fixed"]["@5"]["zero"],
                        "redundancy_at_5": row["fixed"]["@5"]["redundancy_rate"],
                        "planned_channels": row["planned_channel_key"],
                        "reranker_status": row["reranker_status"],
                        "latency_seconds": row["latency_seconds"],
                    }
                )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--run",
        action="append",
        nargs=3,
        metavar=("KEY", "LABEL", "RUN_DIR"),
        required=True,
        help="Repeat for each run: stable key, display label, run directory",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    runs = [load_run(key, label, Path(path)) for key, label, path in args.run]
    args.output_dir.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 1,
        "generated_at": utcnow(),
        "matching_policy": {
            "same_source_video": True,
            "positive_temporal_overlap": True,
            "iou_used": False,
            "one_to_one_matching": True,
            "temporal_cluster_gap_seconds": CLUSTER_GAP_SECONDS,
        },
        "runs": {run.key: run.summary for run in runs},
        "paired_differences": paired_differences(runs),
        "known_gaps": [
            "Precision@n, nDCG@n and boundary usability require pooled relevance labels.",
            "Planner routing accuracy requires expected-channel labels per query.",
            "Fusion loss cannot be reconstructed because pre-fusion per-channel candidates were not saved.",
        ],
    }
    write_json(args.output_dir / "PHASE1_SUMMARY.json", payload)
    for run in runs:
        write_json(args.output_dir / f"QUERY_RESULTS_{run.key}.json", run.rows)
    write_query_csv(args.output_dir / "QUERY_METRICS.csv", runs)
    (args.output_dir / "REPORT.html").write_text(
        render_comparison_html(payload, runs), encoding="utf-8"
    )
    print(json.dumps({
        "output_dir": str(args.output_dir),
        "runs": {
            run.key: {
                "query_count": len(run.rows),
                "success_at_5": run.summary["overall"]["fixed"]["@5"]["success_rate"],
                "multi_recall_at_2n": run.summary["overall"]["multi_answer"]["adaptive"]["@2N"]["macro_recall"],
                "redundancy_at_5": run.summary["overall"]["fixed"]["@5"]["micro_redundancy_rate"],
            }
            for run in runs
        },
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
