#!/usr/bin/env python3
"""Create H.264 720p TVR proxy videos with hard subtitles for OCR tests."""

from __future__ import annotations

import argparse
import json
import os
import re
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


TIMELINE_RE = re.compile(
    r"^(?P<start>\d{2}:\d{2}:\d{2}[,.]\d{3})\s*-->\s*(?P<end>\d{2}:\d{2}:\d{2}[,.]\d{3})(?P<tail>.*)$"
)

STYLE_VERSION = 2
FONT_SIZE = 15
MARGIN_V = 20


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(temporary, path)


def time_to_seconds(value: str) -> float:
    hour, minute, rest = value.replace(".", ",").split(":")
    second, millis = rest.split(",")
    return int(hour) * 3600 + int(minute) * 60 + int(second) + int(millis) / 1000


def seconds_to_time(seconds: float) -> str:
    milliseconds = max(0, int(round(seconds * 1000)))
    hour, remainder = divmod(milliseconds, 3_600_000)
    minute, remainder = divmod(remainder, 60_000)
    second, millis = divmod(remainder, 1000)
    return f"{hour:02d}:{minute:02d}:{second:02d},{millis:03d}"


def probe(path: Path) -> dict[str, Any]:
    completed = subprocess.run(
        [
            "ffprobe",
            "-v",
            "error",
            "-show_entries",
            "format=duration,size:stream=codec_type,codec_name,width,height",
            "-of",
            "json",
            str(path),
        ],
        capture_output=True,
        text=True,
        check=True,
        timeout=60,
    )
    data = json.loads(completed.stdout)
    streams = data.get("streams") or []
    video = next((row for row in streams if row.get("codec_type") == "video"), {})
    audio = next((row for row in streams if row.get("codec_type") == "audio"), {})
    fmt = data.get("format") or {}
    return {
        "duration_sec": round(float(fmt.get("duration") or 0), 3),
        "size_bytes": int(fmt.get("size") or path.stat().st_size),
        "video_codec": video.get("codec_name") or "",
        "width": video.get("width"),
        "height": video.get("height"),
        "audio_codec": audio.get("codec_name") or None,
    }


def sanitize_srt(source: Path, destination: Path, duration: float) -> dict[str, int]:
    text = source.read_text(encoding="utf-8-sig", errors="replace").replace("\r\n", "\n")
    blocks = re.split(r"\n\s*\n", text.strip()) if text.strip() else []
    output_blocks = []
    input_cues = 0
    dropped = 0
    truncated = 0
    for block in blocks:
        lines = block.splitlines()
        timeline_index = next((index for index, line in enumerate(lines) if TIMELINE_RE.match(line.strip())), None)
        if timeline_index is None:
            continue
        match = TIMELINE_RE.match(lines[timeline_index].strip())
        if match is None:
            continue
        input_cues += 1
        start = time_to_seconds(match.group("start"))
        end = time_to_seconds(match.group("end"))
        if start >= duration or end <= 0 or end <= start:
            dropped += 1
            continue
        adjusted_end = min(end, duration)
        if adjusted_end < end:
            truncated += 1
        body = [line.rstrip() for line in lines[timeline_index + 1 :] if line.strip()]
        if not body:
            dropped += 1
            continue
        output_blocks.append(
            "\n".join(
                [
                    str(len(output_blocks) + 1),
                    f"{seconds_to_time(max(0, start))} --> {seconds_to_time(adjusted_end)}{match.group('tail')}",
                    *body,
                ]
            )
        )
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text("\n\n".join(output_blocks) + "\n", encoding="utf-8")
    return {
        "input_cues": input_cues,
        "output_cues": len(output_blocks),
        "dropped_out_of_range_cues": dropped,
        "truncated_cues": truncated,
    }


def escape_filter_path(path: Path) -> str:
    return str(path).replace("\\", "\\\\").replace(":", "\\:").replace("'", "\\'")


def convert_one(video: Path, subtitle: Path, output_root: Path, force: bool = False) -> dict[str, Any]:
    source_probe = probe(video)
    output_subtitle = output_root / "subtitles" / f"{video.stem}.sanitized.srt"
    cue_stats = sanitize_srt(subtitle, output_subtitle, float(source_probe["duration_sec"]))
    output_video = output_root / "videos" / f"{video.stem}.subtitle-ocr.h264-720p.mp4"
    log_path = output_root / "logs" / f"{video.stem}.ffmpeg.log"
    output_video.parent.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = output_video.with_suffix(".pending.mp4")
    ready = (
        not force
        and output_video.exists()
        and output_video.stat().st_mtime >= max(video.stat().st_mtime, subtitle.stat().st_mtime)
    )
    status = "reused"
    if not ready:
        subtitle_filter = escape_filter_path(output_subtitle)
        video_filter = (
            "scale=1280:720:force_original_aspect_ratio=decrease,"
            "pad=1280:720:(ow-iw)/2:(oh-ih)/2:black,"
            f"subtitles=filename='{subtitle_filter}':charenc=UTF-8:"
            f"force_style='FontName=DejaVu Sans,FontSize={FONT_SIZE},"
            "PrimaryColour=&H00FFFFFF,OutlineColour=&H00000000,"
            f"BackColour=&H60000000,BorderStyle=3,Outline=1,Shadow=0,MarginV={MARGIN_V},Alignment=2'"
        )
        command = [
            "ffmpeg",
            "-y",
            "-hide_banner",
            "-i",
            str(video),
            "-vf",
            video_filter,
            "-an",
            "-c:v",
            "libx264",
            "-preset",
            "veryfast",
            "-crf",
            "20",
            "-pix_fmt",
            "yuv420p",
            "-movflags",
            "+faststart",
            str(temporary),
        ]
        with log_path.open("w", encoding="utf-8") as log:
            completed = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
        if completed.returncode != 0:
            temporary.unlink(missing_ok=True)
            raise RuntimeError(f"ffmpeg failed for {video.name}; see {log_path}")
        output_probe = probe(temporary)
        if output_probe["video_codec"] != "h264" or output_probe["width"] != 1280 or output_probe["height"] != 720:
            temporary.unlink(missing_ok=True)
            raise ValueError(f"Unexpected output format for {video.name}: {output_probe}")
        os.replace(temporary, output_video)
        status = "created"
    output_probe = probe(output_video)
    return {
        "source_relative_path": f"tvr/{video.name}",
        "source_video_path": str(video),
        "source_subtitle_path": str(subtitle),
        "sanitized_subtitle_path": str(output_subtitle),
        "output_video_path": str(output_video),
        "status": status,
        "cue_stats": cue_stats,
        "source_probe": source_probe,
        "output_probe": output_probe,
        "duration_difference_sec": round(output_probe["duration_sec"] - source_probe["duration_sec"], 3),
        "subtitle_ocr_available": True,
        "asr_eligible": False,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--videos", required=True, type=Path)
    parser.add_argument("--subtitles", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--jobs", type=int, default=2)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    videos = sorted(args.videos.glob("*.mp4"))
    subtitles = {path.stem: path for path in args.subtitles.glob("*.srt")}
    missing_subtitles = [video.name for video in videos if video.stem not in subtitles]
    extra_subtitles = sorted(path.name for stem, path in subtitles.items() if not (args.videos / f"{stem}.mp4").exists())
    if missing_subtitles or extra_subtitles:
        raise ValueError(
            f"TVR subtitle mapping is not one-to-one; missing={missing_subtitles}, extra={extra_subtitles}"
        )

    manifest_path = args.output / "tvr_subtitle_ocr_manifest.json"
    existing_style_version = None
    if manifest_path.exists():
        try:
            existing_style_version = json.loads(manifest_path.read_text(encoding="utf-8")).get(
                "style_version"
            )
        except (OSError, json.JSONDecodeError):
            existing_style_version = None
    force = args.force or existing_style_version != STYLE_VERSION

    results = []
    errors = []
    with ThreadPoolExecutor(max_workers=max(1, args.jobs)) as pool:
        futures = {
            pool.submit(convert_one, video, subtitles[video.stem], args.output, force): video
            for video in videos
        }
        for future in as_completed(futures):
            video = futures[future]
            try:
                row = future.result()
                results.append(row)
                print(
                    f"[{len(results)}/{len(videos)}] {row['status']} {video.name} "
                    f"cues={row['cue_stats']['output_cues']}",
                    flush=True,
                )
            except Exception as exc:  # noqa: BLE001
                errors.append({"video": video.name, "error": str(exc)})
                print(f"ERROR {video.name}: {exc}", flush=True)
    results.sort(key=lambda row: row["source_relative_path"])
    manifest = {
        "schema_version": 1,
        "style_version": STYLE_VERSION,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "purpose": "hard-subtitle OCR proxy; not ASR ground truth",
        "style": {
            "resolution": "1280x720",
            "font": "DejaVu Sans",
            "font_size": FONT_SIZE,
            "margin_v": MARGIN_V,
            "alignment": "bottom_center",
            "contrast": "white text on translucent black box",
        },
        "video_count": len(results),
        "total_input_cues": sum(row["cue_stats"]["input_cues"] for row in results),
        "total_output_cues": sum(row["cue_stats"]["output_cues"] for row in results),
        "total_dropped_out_of_range_cues": sum(
            row["cue_stats"]["dropped_out_of_range_cues"] for row in results
        ),
        "total_truncated_cues": sum(row["cue_stats"]["truncated_cues"] for row in results),
        "errors": errors,
        "videos": results,
    }
    write_json(manifest_path, manifest)
    print(json.dumps({key: value for key, value in manifest.items() if key != "videos"}, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
