#!/usr/bin/env python3
"""Build an isolated review-app dataset from available public benchmark videos."""

from __future__ import annotations

import argparse
import csv
import copy
import hashlib
import json
import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def format_time(seconds: float) -> str:
    total_ms = int(round(float(seconds) * 1000))
    hours, remainder = divmod(total_ms, 3_600_000)
    minutes, remainder = divmod(remainder, 60_000)
    secs, millis = divmod(remainder, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"


def classification_id(subcapability_id: str) -> str:
    match = re.fullmatch(r"(\d+)\.(\d+)(?:_.*)?", subcapability_id)
    if not match:
        return ""
    return f"C{match.group(1)}_S{match.group(2)}"


def dataset_id(relative_path: str) -> str:
    folder = relative_path.split("/", 1)[0]
    digest = hashlib.sha1(relative_path.encode("utf-8")).hexdigest()[:12]
    return f"public_v1_{folder}_{digest}"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--queries", required=True, type=Path)
    parser.add_argument("--inventory", required=True, type=Path)
    parser.add_argument("--videos", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--subtitle-ocr-manifest", type=Path)
    parser.add_argument("--exclude-dataset", action="append", default=[])
    args = parser.parse_args()

    raw_queries = read_json(args.queries)
    inventory = read_json(args.inventory)
    inventory_queries = {row["query_id"]: row for row in inventory["queries"]}
    inventory_videos = {row["relative_path"]: row for row in inventory["videos"]}
    subtitle_ocr_by_video: dict[str, dict[str, Any]] = {}
    if args.subtitle_ocr_manifest:
        subtitle_manifest = read_json(args.subtitle_ocr_manifest)
        if subtitle_manifest.get("errors"):
            raise ValueError("Subtitle OCR manifest contains conversion errors")
        subtitle_ocr_by_video = {
            row["source_relative_path"]: row
            for row in subtitle_manifest.get("videos") or []
            if row.get("subtitle_ocr_available") and Path(row["output_video_path"]).exists()
        }
    priority_mismatch_ids = {
        row["query_id"] for row in inventory["checks"]["priority_duration_mismatches_over_1_5s"]
    }
    mismatch_by_query = {
        row["query_id"]: row
        for row in inventory["checks"]["declared_duration_mismatches_over_0_5s"]
    }

    available: list[dict[str, Any]] = []
    excluded: list[dict[str, Any]] = []
    excluded_datasets: list[dict[str, Any]] = []
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for source in raw_queries:
        inventory_row = inventory_queries[source["query_id"]]
        if source.get("dataset") in set(args.exclude_dataset):
            excluded_datasets.append(
                {
                    **source,
                    "excluded_reason": "dataset_temporarily_excluded",
                    "expected_relative_path": inventory_row["expected_relative_path"],
                }
            )
            continue
        if not inventory_row["video_exists"]:
            excluded.append(
                {
                    **source,
                    "excluded_reason": "missing_video",
                    "expected_relative_path": inventory_row["expected_relative_path"],
                }
            )
            continue
        relative_path = inventory_row["expected_relative_path"]
        video = inventory_videos[relative_path]
        subtitle_ocr = subtitle_ocr_by_video.get(relative_path)
        derived = copy.deepcopy(source)
        original_duration = float(source["video_duration_sec"])
        actual_duration = float(video["duration_sec"])
        derived["video_status"] = "available"
        derived["video_path"] = str(args.videos / relative_path)
        derived["video_relative_path"] = relative_path
        derived["video_declared_duration_sec_original"] = original_duration
        derived["video_duration_sec"] = actual_duration
        derived["video_duration_time"] = format_time(actual_duration)
        derived["duration_difference_sec"] = round(actual_duration - original_duration, 3)
        derived["duration_policy"] = (
            "UI and timeline use ffprobe container duration; official positive segment boundaries are unchanged"
        )
        derived["audio_available"] = bool(video.get("audio_codec"))
        derived["audio_codec"] = video.get("audio_codec") or None
        derived["asr_eligible"] = bool(video.get("audio_codec"))
        derived["subtitle_ocr_available"] = bool(subtitle_ocr)
        derived["subtitle_ocr_video_path"] = subtitle_ocr.get("output_video_path") if subtitle_ocr else None
        if derived["asr_eligible"]:
            derived["evaluation_scope"] = ["visual", "audio_asr"]
        elif subtitle_ocr:
            derived["evaluation_scope"] = ["visual", "subtitle_ocr"]
        else:
            derived["evaluation_scope"] = ["visual_only"]
        available.append(derived)
        grouped[relative_path].append(derived)

    generated_at = datetime.now(timezone.utc).isoformat()
    config_rows: list[dict[str, Any]] = []
    dataset_index: list[dict[str, Any]] = []
    expected_annotation_files: set[Path] = set()
    for relative_path, queries in sorted(grouped.items()):
        video = inventory_videos[relative_path]
        video_path = args.videos / relative_path
        ds_id = dataset_id(relative_path)
        source_dataset = queries[0]["dataset"]
        audio_available = bool(video.get("audio_codec"))
        subtitle_ocr = subtitle_ocr_by_video.get(relative_path)
        display_name = f"【公开集·{source_dataset}】{video_path.name}"
        if subtitle_ocr:
            display_name = f"【公开集·{source_dataset}·字幕OCR版·无音轨】{video_path.name}"
        elif not audio_available:
            display_name = f"【公开集·{source_dataset}·无音轨】{video_path.name}"
        annotations = []
        for query in sorted(queries, key=lambda row: row["query_id"]):
            mismatch = mismatch_by_query.get(query["query_id"])
            reasons = []
            if not query["asr_eligible"]:
                reasons.append("源视频无音轨，仅用于非 ASR 的视觉检索测试")
            if query.get("subtitle_ocr_available"):
                reasons.append("平台播放硬字幕代理，可用于字幕 OCR 替代实验，但不等同于真实 ASR")
            if mismatch:
                reasons.append(
                    f"声明时长 {query['video_declared_duration_sec_original']:.3f}s，"
                    f"文件实际时长 {query['video_duration_sec']:.3f}s；平台采用实际时长，正例边界保持不变"
                )
            if query["query_id"] in priority_mismatch_ids:
                reasons.append("时长差异超过 1.5 秒，建议确认视频版本是否完整")
            segments = []
            for index, source_segment in enumerate(query.get("positives") or [], 1):
                start = round(float(source_segment["start_sec"]), 3)
                end = round(float(source_segment["end_sec"]), 3)
                segments.append(
                    {
                        **source_segment,
                        "segment_id": source_segment.get("segment_id") or f"{query['query_id']}_p{index:02d}",
                        "start_sec": start,
                        "end_sec": end,
                        "duration_sec": round(end - start, 3),
                        "start_time": format_time(start),
                        "end_time": format_time(end),
                        "duration_time": format_time(end - start),
                        "time_range": f"{format_time(start)} – {format_time(end)}",
                        "source": "official_public_benchmark_positive",
                    }
                )
            capability_number = str(query["capability_id"]).split("_", 1)[0]
            annotations.append(
                {
                    "query_id": query["query_id"],
                    "canonical_query_id": f"{query['dataset']}:{query['source_split']}:{query['source_query_id']}",
                    "query_origin": query["annotation_origin"],
                    "query": query["query"],
                    "classification_id": classification_id(query["subcapability_id"]),
                    "category": f"{capability_number}. {query['capability_name_zh']}",
                    "subcategory": f"{query['subcapability_id']} {query['subcapability_name_zh']}",
                    "label_strength": "official_public_benchmark",
                    "segments": segments,
                    "confidence": 1.0,
                    "needs_human_review": query["query_id"] in priority_mismatch_ids,
                    "review_reason": "；".join(reasons),
                    "public_benchmark": {
                        "dataset": query["dataset"],
                        "source_split": query["source_split"],
                        "source_query_id": query["source_query_id"],
                        "capability_id": query["capability_id"],
                        "subcapability_id": query["subcapability_id"],
                        "audio_available": query["audio_available"],
                        "asr_eligible": query["asr_eligible"],
                        "subtitle_ocr_available": query.get("subtitle_ocr_available", False),
                        "evaluation_scope": query["evaluation_scope"],
                        "declared_duration_sec": query["video_declared_duration_sec_original"],
                        "actual_duration_sec": query["video_duration_sec"],
                        "duration_difference_sec": query["duration_difference_sec"],
                    },
                }
            )

        annotation_path = args.output / "datasets" / f"{ds_id}.json"
        expected_annotation_files.add(annotation_path.resolve())
        annotation = {
            "schema_version": 1,
            "annotation_version": "selected_queries_v1_available_actual_duration",
            "video_id": queries[0]["video_id"],
            "video_name": video_path.name,
            "video_duration_sec": float(video["duration_sec"]),
            "video_duration_time": format_time(float(video["duration_sec"])),
            "time_basis": "seconds relative to downloaded video; millisecond display precision",
            "workflow": {
                "collection_id": "public_benchmark_selected_queries_v1",
                "isolated_from_business_annotations": True,
                "source_dataset": source_dataset,
                "video_relative_path": relative_path,
                "audio_available": audio_available,
                "asr_eligible": audio_available,
                "subtitle_ocr_available": bool(subtitle_ocr),
                "subtitle_ocr_video_path": subtitle_ocr.get("output_video_path") if subtitle_ocr else None,
                "duration_policy": "use ffprobe actual duration; preserve official positive boundaries",
            },
            "summary": {
                "query_count": len(annotations),
                "segment_count": sum(len(row["segments"]) for row in annotations),
                "needs_human_review": sum(bool(row["needs_human_review"]) for row in annotations),
            },
            "quality_check": {
                "video_probe_ok": bool(video.get("probe_ok")),
                "video_codec": video.get("video_codec"),
                "audio_codec": video.get("audio_codec") or None,
                "all_segments_within_actual_duration": all(
                    segment["end_sec"] <= float(video["duration_sec"]) + 0.25
                    for row in annotations
                    for segment in row["segments"]
                ),
            },
            "annotations": annotations,
        }
        write_json(annotation_path, annotation)
        config_rows.append(
            {
                "id": ds_id,
                "asset_id": f"vid_{ds_id}",
                "title": display_name,
                "display_name": display_name,
                "annotation_path": str(annotation_path),
                "video_dir": str(video_path.parent),
                "video_path": str(video_path),
                "review_path": str(args.output / "reviews" / ds_id / "review_annotations.json"),
                "proxy_video": subtitle_ocr.get("output_video_path") if subtitle_ocr else "",
                "created_at": generated_at,
                "collection_id": "public_benchmark_selected_queries_v1",
            }
        )
        dataset_index.append(
            {
                "dataset_id": ds_id,
                "display_name": display_name,
                "source_dataset": source_dataset,
                "video_id": queries[0]["video_id"],
                "relative_path": relative_path,
                "query_ids": [row["query_id"] for row in queries],
                "query_count": len(queries),
                "segment_count": sum(len(row.get("positives") or []) for row in queries),
                "audio_available": audio_available,
                "asr_eligible": audio_available,
                "subtitle_ocr_available": bool(subtitle_ocr),
                "subtitle_ocr_video_path": subtitle_ocr.get("output_video_path") if subtitle_ocr else None,
            }
        )

    excluded_dataset_archive = args.output / "excluded-dataset-files"
    for stale_path in (args.output / "datasets").glob("*.json"):
        if stale_path.resolve() in expected_annotation_files:
            continue
        excluded_dataset_archive.mkdir(parents=True, exist_ok=True)
        stale_path.replace(excluded_dataset_archive / stale_path.name)

    write_json(args.output / "config" / "datasets.json", {"schema_version": 1, "datasets": config_rows})
    write_json(args.output / "derived" / "selected_queries.v1.available.json", available)
    write_json(args.output / "derived" / "selected_queries.v1.excluded_missing_video.json", excluded)
    write_json(args.output / "derived" / "selected_queries.v1.excluded_dataset.json", excluded_datasets)
    write_json(args.output / "derived" / "dataset_index.json", dataset_index)

    capability_distribution = Counter(
        (row["capability_id"], row["capability_name_zh"]) for row in available
    )
    subcapability_distribution = Counter(
        (row["subcapability_id"], row["subcapability_name_zh"]) for row in available
    )
    dataset_distribution = Counter(row["dataset"] for row in available)
    summary = {
        "generated_at": generated_at,
        "source_query_count": len(raw_queries),
        "available_query_count": len(available),
        "excluded_missing_video_query_count": len(excluded),
        "excluded_dataset_query_count": len(excluded_datasets),
        "excluded_datasets": sorted(set(args.exclude_dataset)),
        "available_video_count": len(grouped),
        "positive_segment_count": sum(len(row.get("positives") or []) for row in available),
        "asr_eligible_query_count": sum(bool(row["asr_eligible"]) for row in available),
        "visual_only_query_count": sum(not row["asr_eligible"] for row in available),
        "subtitle_ocr_query_count": sum(bool(row.get("subtitle_ocr_available")) for row in available),
        "subtitle_ocr_video_count": sum(bool(row.get("subtitle_ocr_available")) for row in dataset_index),
        "priority_duration_review_query_count": sum(
            row["query_id"] in priority_mismatch_ids for row in available
        ),
        "dataset_distribution": dict(sorted(dataset_distribution.items())),
        "capability_distribution": [
            {"capability_id": key[0], "capability_name_zh": key[1], "query_count": count}
            for key, count in sorted(capability_distribution.items())
        ],
        "subcapability_distribution": [
            {"subcapability_id": key[0], "subcapability_name_zh": key[1], "query_count": count}
            for key, count in sorted(subcapability_distribution.items())
        ],
    }
    write_json(args.output / "derived" / "build_summary.json", summary)
    segment_rows = []
    for query in available:
        for segment in query.get("positives") or []:
            segment_rows.append(
                {
                    "query_id": query["query_id"],
                    "query": query["query"],
                    "dataset": query["dataset"],
                    "capability_id": query["capability_id"],
                    "capability_name_zh": query["capability_name_zh"],
                    "subcapability_id": query["subcapability_id"],
                    "subcapability_name_zh": query["subcapability_name_zh"],
                    "video_id": query["video_id"],
                    "video_relative_path": query["video_relative_path"],
                    "segment_id": segment["segment_id"],
                    "start_sec": segment["start_sec"],
                    "end_sec": segment["end_sec"],
                    "time_range": f"{format_time(segment['start_sec'])} – {format_time(segment['end_sec'])}",
                    "audio_available": query["audio_available"],
                    "asr_eligible": query["asr_eligible"],
                    "subtitle_ocr_available": query.get("subtitle_ocr_available", False),
                    "declared_duration_sec": query["video_declared_duration_sec_original"],
                    "actual_duration_sec": query["video_duration_sec"],
                    "duration_difference_sec": query["duration_difference_sec"],
                }
            )
    catalog_csv = args.output / "derived" / "query_segment_catalog.csv"
    with catalog_csv.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(segment_rows[0]) if segment_rows else [])
        writer.writeheader()
        writer.writerows(segment_rows)

    md_lines = [
        "# 公开集可用 Query 与片段目录",
        "",
        f"- 可用 Query：{len(available)}",
        f"- 视频：{len(grouped)}",
        f"- 正例片段：{len(segment_rows)}",
        f"- 可进入 ASR 通路：{summary['asr_eligible_query_count']} 条",
        f"- 禁止进入 ASR 通路：{summary['visual_only_query_count']} 条，其中字幕 OCR 代理可用：{summary['subtitle_ocr_query_count']} 条",
        "- 时间策略：平台时间轴使用 ffprobe 实际时长；官方正例起止时间保持不变。",
        "",
        "## 一级能力分布",
        "",
        "| 能力 | 名称 | Query 数 |",
        "| --- | --- | ---: |",
    ]
    for row in summary["capability_distribution"]:
        md_lines.append(
            f"| {row['capability_id']} | {row['capability_name_zh']} | {row['query_count']} |"
        )
    md_lines.extend(
        [
            "",
            "## Query—视频—片段映射",
            "",
            "完整的139行映射见 `query_segment_catalog.csv`；下面按Query汇总。",
            "",
            "| Query ID | 能力 | Query | 视频 | 片段 | ASR |",
            "| --- | --- | --- | --- | --- | --- |",
        ]
    )
    for query in available:
        ranges = "；".join(
            f"{format_time(segment['start_sec'])}–{format_time(segment['end_sec'])}"
            for segment in query.get("positives") or []
        )
        escaped_query = str(query["query"]).replace("|", "\\|").replace("\n", " ")
        md_lines.append(
            f"| {query['query_id']} | {query['subcapability_id']} {query['subcapability_name_zh']} | "
            f"{escaped_query} | `{query['video_relative_path']}` | {ranges} | "
            f"{'可用' if query['asr_eligible'] else '不可用'} |"
        )
    (args.output / "derived" / "PUBLIC_BENCHMARK_CATALOG.md").write_text(
        "\n".join(md_lines) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
