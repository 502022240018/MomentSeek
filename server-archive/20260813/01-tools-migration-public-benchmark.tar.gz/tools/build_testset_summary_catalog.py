#!/usr/bin/env python3
"""Build the 8786 unified catalog from reviewed 8766 data and public 8767 data."""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import re
import unicodedata
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def load_app(path: Path, module_name: str) -> Any:
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    temporary.replace(path)


def format_time(seconds: float) -> str:
    total_ms = int(round(float(seconds) * 1000))
    hour, remainder = divmod(total_ms, 3_600_000)
    minute, remainder = divmod(remainder, 60_000)
    second, millis = divmod(remainder, 1000)
    return f"{hour:02d}:{minute:02d}:{second:02d}.{millis:03d}"


def normalize_query(text: str) -> str:
    value = unicodedata.normalize("NFKC", text).strip().casefold()
    return re.sub(r"\s+", " ", value)


def natural_class_key(classification_id: str) -> tuple[int, int, str]:
    match = re.fullmatch(r"C(\d+)_S(\d+)", classification_id or "")
    if not match:
        return (999, 999, classification_id or "")
    return (int(match.group(1)), int(match.group(2)), classification_id)


def normalize_segments(segments: list[dict[str, Any]], record_id: str) -> list[dict[str, Any]]:
    normalized = []
    for index, segment in enumerate(segments or [], 1):
        start = round(float(segment["start_sec"]), 3)
        end = round(float(segment["end_sec"]), 3)
        if start < 0 or end <= start:
            continue
        normalized.append(
            {
                **segment,
                "segment_id": str(segment.get("segment_id") or f"{record_id}_s{index:02d}"),
                "start_sec": start,
                "end_sec": end,
                "duration_sec": round(end - start, 3),
                "start_time": format_time(start),
                "end_time": format_time(end),
                "time_range": f"{format_time(start)} – {format_time(end)}",
            }
        )
    return sorted(normalized, key=lambda row: (row["start_sec"], row["end_sec"]))


def record_id(source_kind: str, dataset_id: str, query_id: str) -> str:
    raw = f"{source_kind}|{dataset_id}|{query_id}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:20]


def classification_lookup(app: Any) -> dict[str, dict[str, str]]:
    return {row["id"]: row for row in app.load_classifications()}


def build_human_records(app: Any) -> tuple[list[dict[str, Any]], dict[str, int]]:
    records = []
    counters = Counter()
    class_lookup = classification_lookup(app)
    for dataset in app.ensure_config():
        data = app.compact_annotation(dataset)
        review = app.load_review(dataset)
        review_items = review.get("items") or {}
        annotation_source = app.read_json(Path(str(dataset["annotation_path"])))
        media_path = app.find_video(annotation_source, dataset)
        annotations = {str(item.get("query_id")): item for item in data.get("annotations") or []}
        for query_id, decision in review_items.items():
            status = str(decision.get("status") or "pending")
            if status not in {"approved", "fix"}:
                continue
            item = annotations.get(str(query_id))
            if not item:
                counters["missing_current_annotation"] += 1
                continue
            effective_query = str(decision.get("suggested_query") or "").strip() or str(item.get("query") or "").strip()
            selected_id = str(decision.get("selected_classification_id") or item.get("classification_id") or "")
            selected_class = class_lookup.get(selected_id, {})
            category = str(decision.get("selected_category") or selected_class.get("category") or item.get("category") or "未分类")
            subcategory = str(decision.get("selected_subcategory") or selected_class.get("subcategory") or item.get("subcategory") or "未分类")
            override = bool(
                decision.get("segments_override") is True
                or decision.get("corrected_segments_mode") == "replace"
                or decision.get("corrected_segments")
            )
            effective_segments = list(decision.get("corrected_segments") or []) if override else list(item.get("segments") or [])
            rid = record_id("human_reviewed", str(dataset["id"]), str(query_id))
            records.append(
                {
                    "record_id": rid,
                    "source_kind": "human_reviewed",
                    "source_label": "8766人工已完成",
                    "review_status": status,
                    "review_status_label": "已通过" if status == "approved" else "已修正",
                    "dataset_id": str(dataset["id"]),
                    "dataset_title": str(dataset.get("display_name") or dataset.get("title") or dataset["id"]),
                    "query_id": str(query_id),
                    "canonical_query_id": item.get("canonical_query_id"),
                    "source_query": str(item.get("query") or ""),
                    "query": effective_query,
                    "query_was_rewritten": effective_query != str(item.get("query") or "").strip(),
                    "classification_id": selected_id,
                    "source_classification_id": str(item.get("classification_id") or ""),
                    "category": category,
                    "subcategory": subcategory,
                    "category_was_changed": selected_id != str(item.get("classification_id") or ""),
                    "segments_were_replaced": override,
                    "segments": normalize_segments(effective_segments, rid),
                    "video_id": data.get("video", {}).get("id"),
                    "video_name": data.get("video", {}).get("name") or data.get("dataset", {}).get("title"),
                    "video_duration_sec": data.get("video", {}).get("duration_sec"),
                    "video_duration_time": data.get("video", {}).get("duration_time"),
                    "media_path": str(media_path) if media_path else "",
                    "media_exists": bool(media_path and media_path.exists()),
                    "notes": decision.get("notes") or "",
                    "reason_codes": decision.get("reason_codes") or [],
                    "review_updated_at": decision.get("updated_at"),
                    "manual_added": bool(item.get("manual_added")),
                }
            )
            counters[status] += 1
            counters["query_rewritten"] += effective_query != str(item.get("query") or "").strip()
            counters["segments_replaced"] += override
            counters["category_changed"] += selected_id != str(item.get("classification_id") or "")
    return records, dict(counters)


def build_public_records(app: Any) -> list[dict[str, Any]]:
    records = []
    class_lookup = classification_lookup(app)
    for dataset in app.ensure_config():
        data = app.compact_annotation(dataset)
        annotation_source = app.read_json(Path(str(dataset["annotation_path"])))
        media_path = app.find_video(annotation_source, dataset)
        for item in data.get("annotations") or []:
            query_id = str(item.get("query_id") or "")
            rid = record_id("public_benchmark", str(dataset["id"]), query_id)
            public_meta = item.get("public_benchmark") or {}
            selected_id = str(item.get("classification_id") or "")
            selected_class = class_lookup.get(selected_id, {})
            records.append(
                {
                    "record_id": rid,
                    "source_kind": "public_benchmark",
                    "source_label": "8767公开测试集",
                    "review_status": "official",
                    "review_status_label": "公开集标注",
                    "dataset_id": str(dataset["id"]),
                    "dataset_title": str(dataset.get("display_name") or dataset.get("title") or dataset["id"]),
                    "query_id": query_id,
                    "canonical_query_id": item.get("canonical_query_id"),
                    "source_query": str(item.get("query") or ""),
                    "query": str(item.get("query") or "").strip(),
                    "query_was_rewritten": False,
                    "classification_id": selected_id,
                    "source_classification_id": selected_id,
                    "category": str(selected_class.get("category") or item.get("category") or "未分类"),
                    "subcategory": str(selected_class.get("subcategory") or item.get("subcategory") or "未分类"),
                    "category_was_changed": False,
                    "segments_were_replaced": False,
                    "segments": normalize_segments(list(item.get("segments") or []), rid),
                    "video_id": data.get("video", {}).get("id"),
                    "video_name": data.get("video", {}).get("name") or data.get("dataset", {}).get("title"),
                    "video_duration_sec": data.get("video", {}).get("duration_sec"),
                    "video_duration_time": data.get("video", {}).get("duration_time"),
                    "media_path": str(media_path) if media_path else "",
                    "media_exists": bool(media_path and media_path.exists()),
                    "public_dataset": public_meta.get("dataset"),
                    "audio_available": public_meta.get("audio_available"),
                    "asr_eligible": public_meta.get("asr_eligible"),
                    "subtitle_ocr_available": public_meta.get("subtitle_ocr_available", False),
                    "evaluation_scope": public_meta.get("evaluation_scope") or [],
                    "notes": item.get("review_reason") or "",
                }
            )
    return records


def make_distribution(records: list[dict[str, Any]], field: str) -> list[dict[str, Any]]:
    buckets: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        buckets[str(record.get(field) or "未分类")].append(record)
    rows = []
    for label, bucket in buckets.items():
        semantics = {
            (record["classification_id"], normalize_query(record["query"])) for record in bucket
        }
        rows.append(
            {
                "label": label,
                "unique_query_count": len(semantics),
                "record_count": len(bucket),
                "segment_count": sum(len(record["segments"]) for record in bucket),
                "video_count": len({record["media_path"] for record in bucket if record["media_path"]}),
            }
        )
    return sorted(rows, key=lambda row: (-row["record_count"], row["label"]))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--review-app", required=True, type=Path)
    parser.add_argument("--public-app", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    review_app = load_app(args.review_app, "momentseek_review_8766")
    public_app = load_app(args.public_app, "momentseek_public_8767")
    human_records, human_counters = build_human_records(review_app)
    public_records = build_public_records(public_app)
    records = human_records + public_records

    groups_by_key: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        groups_by_key[(record["classification_id"], normalize_query(record["query"]))].append(record)
    groups = []
    for (classification_id, normalized), bucket in groups_by_key.items():
        exemplar = bucket[0]
        semantic_id = hashlib.sha1(f"{classification_id}|{normalized}".encode("utf-8")).hexdigest()[:16]
        groups.append(
            {
                "semantic_query_id": semantic_id,
                "query": exemplar["query"],
                "normalized_query": normalized,
                "classification_id": classification_id,
                "category": exemplar["category"],
                "subcategory": exemplar["subcategory"],
                "record_count": len(bucket),
                "segment_count": sum(len(record["segments"]) for record in bucket),
                "video_count": len({record["media_path"] for record in bucket if record["media_path"]}),
                "source_kinds": sorted({record["source_kind"] for record in bucket}),
                "records": sorted(bucket, key=lambda row: (row["source_kind"], row["dataset_title"], row["query_id"])),
            }
        )
    groups.sort(key=lambda row: (natural_class_key(row["classification_id"]), row["query"].casefold()))

    segment_count = sum(len(record["segments"]) for record in records)
    unique_videos = {record["media_path"] for record in records if record["media_path"]}
    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "semantic_query_count": len(groups),
        "query_video_record_count": len(records),
        "segment_count": segment_count,
        "video_count": len(unique_videos),
        "human_reviewed_record_count": len(human_records),
        "public_benchmark_record_count": len(public_records),
        "approved_record_count": sum(record["review_status"] == "approved" for record in human_records),
        "fixed_record_count": sum(record["review_status"] == "fix" for record in human_records),
        "no_segment_record_count": sum(not record["segments"] for record in records),
        "media_missing_record_count": sum(not record["media_exists"] for record in records),
        "human_corrections": human_counters,
        "public_exclusions": {
            "activitynet_captions": True,
            "missing_video_queries": True,
        },
    }
    catalog = {
        "schema_version": 1,
        "title": "MomentSeek 测试集总览",
        "counting_policy": {
            "semantic_query": "exact NFKC/casefold/whitespace-normalized effective query text within final classification",
            "query_video_record": "one effective query attached to one source video dataset",
            "human_source": "8766 status approved or fix; query/category/segments use saved corrected values",
            "public_source": "current 8767 available catalog; ActivityNet Captions excluded",
        },
        "summary": summary,
        "category_distribution": make_distribution(records, "category"),
        "subcategory_distribution": make_distribution(records, "subcategory"),
        "groups": groups,
    }
    write_json(args.output / "catalog" / "testset_summary_catalog.json", catalog)

    record_rows = []
    segment_rows = []
    for group in groups:
        for record in group["records"]:
            record_rows.append(
                {
                    "semantic_query_id": group["semantic_query_id"],
                    "query": record["query"],
                    "classification_id": record["classification_id"],
                    "category": record["category"],
                    "subcategory": record["subcategory"],
                    "source_kind": record["source_kind"],
                    "review_status": record["review_status"],
                    "dataset_id": record["dataset_id"],
                    "dataset_title": record["dataset_title"],
                    "query_id": record["query_id"],
                    "video_name": record["video_name"],
                    "segment_count": len(record["segments"]),
                    "query_was_rewritten": record["query_was_rewritten"],
                    "category_was_changed": record["category_was_changed"],
                    "segments_were_replaced": record["segments_were_replaced"],
                }
            )
            for segment in record["segments"]:
                segment_rows.append(
                    {
                        **record_rows[-1],
                        "segment_id": segment["segment_id"],
                        "start_sec": segment["start_sec"],
                        "end_sec": segment["end_sec"],
                        "time_range": segment["time_range"],
                    }
                )
    for name, rows in (("query_records.csv", record_rows), ("query_segments.csv", segment_rows)):
        with (args.output / "catalog" / name).open("w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else [])
            writer.writeheader()
            writer.writerows(rows)

    md = [
        "# MomentSeek 测试集总览",
        "",
        f"- 唯一有效 Query：{summary['semantic_query_count']}",
        f"- Query-视频记录：{summary['query_video_record_count']}",
        f"- 片段：{summary['segment_count']}",
        f"- 视频：{summary['video_count']}",
        f"- 8766 人工完成：{summary['human_reviewed_record_count']}（通过 {summary['approved_record_count']}，修正 {summary['fixed_record_count']}）",
        f"- 8767 公开集：{summary['public_benchmark_record_count']}（不含 ActivityNet Captions）",
        "",
        "## 一级分类",
        "",
        "| 类型 | 唯一Query | Query-视频记录 | 片段 | 视频 |",
        "| --- | ---: | ---: | ---: | ---: |",
    ]
    for row in catalog["category_distribution"]:
        md.append(
            f"| {row['label']} | {row['unique_query_count']} | {row['record_count']} | {row['segment_count']} | {row['video_count']} |"
        )
    (args.output / "catalog" / "TESTSET_SUMMARY.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    print(json.dumps({"summary": summary, "category_distribution": catalog["category_distribution"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
