#!/usr/bin/env python3
"""Upload, index, and evaluate the frozen 8786 test set on MomentSeek production.

The run is resumable. Every upload, index job, and query response is persisted
under an isolated evaluation directory. ActivityNet records are excluded by
policy even if an older aggregate catalog accidentally still contains them.
"""

from __future__ import annotations

import argparse
import hashlib
import html
import json
import math
import os
import statistics
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import requests


EXCLUDED_PUBLIC_DATASETS = {"ActivityNet-Entities", "ActivityNet Captions"}
TERMINAL_JOB_STATES = {"completed", "failed", "cancelled"}


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat()


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def api_json(
    session: requests.Session,
    method: str,
    url: str,
    *,
    timeout: tuple[float, float] = (10, 300),
    **kwargs: Any,
) -> Any:
    response = session.request(method, url, timeout=timeout, **kwargs)
    response.raise_for_status()
    return response.json() if response.content else None


def record_is_in_scope(record: dict[str, Any]) -> bool:
    return str(record.get("public_dataset") or "") not in EXCLUDED_PUBLIC_DATASETS


def freeze_catalog(source: dict[str, Any]) -> dict[str, Any]:
    frozen = dict(source)
    groups = []
    for group in source.get("groups") or []:
        records = [dict(row) for row in group.get("records") or [] if record_is_in_scope(row)]
        if not records:
            continue
        copy = dict(group)
        copy["records"] = records
        copy["record_count"] = len(records)
        copy["segment_count"] = sum(len(row.get("segments") or []) for row in records)
        copy["video_count"] = len({str(row.get("video_id")) for row in records})
        copy["source_kinds"] = sorted({str(row.get("source_kind")) for row in records})
        groups.append(copy)
    records = [row for group in groups for row in group["records"]]
    videos = {str(row["video_id"]): row for row in records}
    summary = dict(source.get("summary") or {})
    summary.update(
        {
            "generated_at": utcnow(),
            "frozen_from_generated_at": (source.get("summary") or {}).get("generated_at"),
            "semantic_query_count": len(groups),
            "query_video_record_count": len(records),
            "segment_count": sum(len(row.get("segments") or []) for row in records),
            "video_count": len(videos),
            "excluded_public_datasets": sorted(EXCLUDED_PUBLIC_DATASETS),
        }
    )
    frozen["summary"] = summary
    frozen["groups"] = groups
    return frozen


def build_manifest(catalog: dict[str, Any]) -> list[dict[str, Any]]:
    videos: dict[str, dict[str, Any]] = {}
    for group in catalog.get("groups") or []:
        for record in group.get("records") or []:
            key = str(record["video_id"])
            videos.setdefault(
                key,
                {
                    "source_video_id": key,
                    "name": str(record["video_name"]),
                    "media_path": str(record["media_path"]),
                    "duration_sec": float(record.get("video_duration_sec") or 0),
                    "audio_available": bool(record.get("audio_available", True)),
                    "subtitle_ocr_available": bool(record.get("subtitle_ocr_available", False)),
                    "source_kinds": [],
                },
            )
            kind = str(record.get("source_kind") or "")
            if kind and kind not in videos[key]["source_kinds"]:
                videos[key]["source_kinds"].append(kind)
    manifest = sorted(videos.values(), key=lambda row: (row["name"], row["source_video_id"]))
    for row in manifest:
        path = Path(row["media_path"])
        if not path.is_file():
            raise FileNotFoundError(path)
        row["size_bytes"] = path.stat().st_size
        row["sha256_head_tail"] = head_tail_sha256(path)
    return manifest


def head_tail_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    size = path.stat().st_size
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        digest.update(handle.read(min(chunk_size, size)))
        if size > chunk_size:
            handle.seek(max(0, size - chunk_size))
            digest.update(handle.read(chunk_size))
    digest.update(str(size).encode())
    return digest.hexdigest()


def folder_for_run(session: requests.Session, base_url: str, name: str) -> dict[str, Any]:
    folders = api_json(session, "GET", f"{base_url}/api/folders")
    matches = [row for row in folders if row.get("name") == name]
    if len(matches) > 1:
        raise RuntimeError(f"more than one folder named {name!r}")
    if matches:
        return matches[0]
    return api_json(
        session,
        "POST",
        f"{base_url}/api/folders",
        json={"name": name},
    )


def initial_state(folder: dict[str, Any], catalog: dict[str, Any]) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "created_at": utcnow(),
        "updated_at": utcnow(),
        "phase": "upload",
        "folder": folder,
        "catalog_summary": catalog.get("summary") or {},
        "videos": {},
        "queries": {},
    }


def upload_videos(
    session: requests.Session,
    base_url: str,
    manifest: list[dict[str, Any]],
    state: dict[str, Any],
    state_path: Path,
) -> None:
    folder_id = str(state["folder"]["id"])
    total = len(manifest)
    for index, row in enumerate(manifest, start=1):
        source_id = row["source_video_id"]
        saved = state["videos"].get(source_id) or {}
        if saved.get("platform_video_id"):
            continue
        path = Path(row["media_path"])
        print(f"[{utcnow()}] upload {index}/{total}: {row['name']}", flush=True)
        with path.open("rb") as handle:
            response = api_json(
                session,
                "POST",
                f"{base_url}/api/videos",
                files={"video": (row["name"], handle, "video/mp4")},
                data={"folder_ids": json.dumps([folder_id], ensure_ascii=False)},
                timeout=(15, 7200),
            )
        actual_duration = float(response.get("duration") or 0)
        expected_duration = float(row.get("duration_sec") or 0)
        if expected_duration and abs(actual_duration - expected_duration) > 1.0:
            raise RuntimeError(
                f"duration mismatch for {row['name']}: expected {expected_duration}, got {actual_duration}"
            )
        state["videos"][source_id] = {
            **row,
            "platform_video_id": str(response["id"]),
            "uploaded_at": utcnow(),
            "platform_duration_sec": actual_duration,
            "index_job_id": None,
            "index_status": "not_submitted",
        }
        state["updated_at"] = utcnow()
        write_json(state_path, state)
    state["phase"] = "index_submit"
    state["updated_at"] = utcnow()
    write_json(state_path, state)


def index_request(row: dict[str, Any]) -> dict[str, Any]:
    modalities = ["visual", "face", "ocr"]
    if row.get("audio_available"):
        modalities.insert(2, "asr")
    return {
        "modalities": modalities,
        "visual_model": "siglip2-so400m-384",
        "visual_sample_fps": 4.0,
        "visual_segment_seconds": 5.0,
        "visual_segment_strategy": "fixed",
        "face_sample_fps": 1.0,
        "ocr_sample_fps": 1.0,
        "asr_language": "auto",
        "asr_speaker_enabled": bool(row.get("audio_available")),
    }


def submit_indexes(
    session: requests.Session,
    base_url: str,
    manifest: list[dict[str, Any]],
    state: dict[str, Any],
    state_path: Path,
) -> None:
    for index, row in enumerate(manifest, start=1):
        source_id = row["source_video_id"]
        saved = state["videos"][source_id]
        if saved.get("index_job_id"):
            continue
        request = index_request(saved)
        print(f"[{utcnow()}] index submit {index}/{len(manifest)}: {row['name']}", flush=True)
        job = api_json(
            session,
            "POST",
            f"{base_url}/api/videos/{saved['platform_video_id']}/index",
            json=request,
        )
        saved["index_request"] = request
        saved["index_job_id"] = str(job["id"])
        saved["index_status"] = str(job.get("status") or "queued")
        saved["index_submitted_at"] = utcnow()
        state["updated_at"] = utcnow()
        write_json(state_path, state)
    state["phase"] = "index_wait"
    state["updated_at"] = utcnow()
    write_json(state_path, state)


def wait_for_indexes(
    session: requests.Session,
    base_url: str,
    state: dict[str, Any],
    state_path: Path,
    poll_seconds: int,
) -> None:
    while True:
        counts: Counter[str] = Counter()
        failed = []
        changed = False
        for source_id, saved in state["videos"].items():
            if saved.get("index_reused"):
                counts["completed"] += 1
                continue
            job = api_json(session, "GET", f"{base_url}/api/jobs/{saved['index_job_id']}")
            status = str(job.get("status") or "unknown")
            counts[status] += 1
            if saved.get("index_status") != status or saved.get("index_stage") != job.get("stage"):
                saved["index_status"] = status
                saved["index_stage"] = job.get("stage")
                saved["index_progress"] = job.get("progress")
                saved["index_error"] = job.get("error")
                if status in TERMINAL_JOB_STATES:
                    saved["index_metrics"] = job.get("metrics") or {}
                    saved["index_finished_at"] = job.get("updated_at")
                changed = True
            if status in {"failed", "cancelled"}:
                failed.append({"source_video_id": source_id, "job": job})
        if changed:
            state["updated_at"] = utcnow()
            write_json(state_path, state)
        print(f"[{utcnow()}] index status: {dict(counts)}", flush=True)
        if failed:
            write_json(state_path.parent / "index_failures.json", failed)
            state["phase"] = "index_failed"
            state["updated_at"] = utcnow()
            write_json(state_path, state)
            raise RuntimeError(f"{len(failed)} index jobs failed or were cancelled")
        if counts and sum(counts[state] for state in TERMINAL_JOB_STATES) == len(state["videos"]):
            break
        time.sleep(poll_seconds)
    state["phase"] = "evaluate"
    state["updated_at"] = utcnow()
    write_json(state_path, state)


def safe_result_name(semantic_query_id: str) -> str:
    return hashlib.sha1(semantic_query_id.encode("utf-8")).hexdigest()[:20] + ".json"


def run_queries(
    session: requests.Session,
    base_url: str,
    catalog: dict[str, Any],
    state: dict[str, Any],
    state_path: Path,
    query_dir: Path,
) -> None:
    query_dir.mkdir(parents=True, exist_ok=True)
    folder_id = str(state["folder"]["id"])
    groups = list(catalog.get("groups") or [])
    for index, group in enumerate(groups, start=1):
        semantic_id = str(group["semantic_query_id"])
        output_path = query_dir / safe_result_name(semantic_id)
        if output_path.is_file():
            state["queries"][semantic_id] = {
                "status": "completed",
                "result_path": str(output_path),
            }
            continue
        print(f"[{utcnow()}] query {index}/{len(groups)}: {group['query']}", flush=True)
        payload = {
            "query_text": str(group["query"]),
            "modalities": "visual,face,asr,ocr",
            "folder_ids": json.dumps([folder_id]),
            "limit": "50",
            "orchestration_profile": "qwen35-skill-v1",
            "planner_mode": "auto",
            "reranker_mode": "auto",
        }
        error = None
        for attempt in range(1, 3):
            started = time.perf_counter()
            try:
                response = api_json(
                    session,
                    "POST",
                    f"{base_url}/api/search",
                    data=payload,
                    timeout=(15, 360),
                )
                response["benchmark"] = {
                    "semantic_query_id": semantic_id,
                    "query_index": index,
                    "request_started_at": utcnow(),
                    "client_elapsed_seconds": round(time.perf_counter() - started, 3),
                }
                write_json(output_path, response)
                state["queries"][semantic_id] = {
                    "status": "completed",
                    "result_path": str(output_path),
                    "elapsed_seconds": response.get("elapsed_seconds"),
                    "result_count": response.get("count"),
                }
                error = None
                break
            except Exception as exc:  # preserve failure and continue after one retry
                error = f"{type(exc).__name__}: {exc}"
                time.sleep(5 * attempt)
        if error:
            failure_path = query_dir / (output_path.stem + ".error.json")
            write_json(
                failure_path,
                {
                    "semantic_query_id": semantic_id,
                    "query": group["query"],
                    "error": error,
                    "failed_at": utcnow(),
                },
            )
            state["queries"][semantic_id] = {
                "status": "failed",
                "error": error,
                "result_path": str(failure_path),
            }
        state["updated_at"] = utcnow()
        write_json(state_path, state)
    state["phase"] = "report"
    state["updated_at"] = utcnow()
    write_json(state_path, state)


def iou(left: tuple[float, float], right: tuple[float, float]) -> float:
    overlap = max(0.0, min(left[1], right[1]) - max(left[0], right[0]))
    union = max(left[1], right[1]) - min(left[0], right[0])
    return overlap / union if union > 0 else 0.0


def group_score(
    group: dict[str, Any],
    response: dict[str, Any],
    platform_to_source: dict[str, str],
) -> dict[str, Any]:
    truth: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for record in group.get("records") or []:
        for segment in record.get("segments") or []:
            truth[str(record["video_id"])].append(
                (float(segment["start_sec"]), float(segment["end_sec"]))
            )
    ranked = []
    for rank, result in enumerate(response.get("results") or [], start=1):
        source_video_id = platform_to_source.get(str(result.get("video_id")), "")
        span = (float(result.get("start_time") or 0), float(result.get("end_time") or 0))
        overlaps = [iou(span, gt) for gt in truth.get(source_video_id, [])]
        ranked.append(
            {
                "rank": rank,
                "platform_video_id": result.get("video_id"),
                "source_video_id": source_video_id,
                "start_sec": span[0],
                "end_sec": span[1],
                "score": result.get("score"),
                "modalities": result.get("modalities") or [],
                "video_relevant": source_video_id in truth,
                "best_iou": max(overlaps, default=0.0),
            }
        )
    first_video = next((row["rank"] for row in ranked if row["video_relevant"]), None)
    first_iou_01 = next((row["rank"] for row in ranked if row["best_iou"] >= 0.1), None)
    first_iou_03 = next((row["rank"] for row in ranked if row["best_iou"] >= 0.3), None)
    return {
        "semantic_query_id": group["semantic_query_id"],
        "query": group["query"],
        "category": group.get("category"),
        "subcategory": group.get("subcategory"),
        "source_kinds": group.get("source_kinds") or [],
        "ground_truth_video_count": len(truth),
        "ground_truth_segment_count": sum(len(rows) for rows in truth.values()),
        "first_video_rank": first_video,
        "first_iou_01_rank": first_iou_01,
        "first_iou_03_rank": first_iou_03,
        "latency_seconds": float(response.get("elapsed_seconds") or 0),
        "execution": response.get("execution") or {},
        "ranked": ranked,
    }


def aggregate(rows: list[dict[str, Any]]) -> dict[str, Any]:
    ks = [1, 3, 5, 10, 20, 50]
    valid = [row for row in rows if not row.get("error")]
    latencies = [row["latency_seconds"] for row in valid]
    result: dict[str, Any] = {
        "query_count": len(rows),
        "successful_query_count": len(valid),
        "failed_query_count": len(rows) - len(valid),
        "latency_seconds": {
            "mean": round(statistics.mean(latencies), 3) if latencies else None,
            "median": round(statistics.median(latencies), 3) if latencies else None,
            "p95": round(sorted(latencies)[max(0, math.ceil(len(latencies) * 0.95) - 1)], 3)
            if latencies
            else None,
            "max": round(max(latencies), 3) if latencies else None,
        },
    }
    for label, field in [
        ("video_recall", "first_video_rank"),
        ("temporal_iou_0.1_recall", "first_iou_01_rank"),
        ("temporal_iou_0.3_recall", "first_iou_03_rank"),
    ]:
        result[label] = {
            f"@{k}": round(
                sum(1 for row in valid if row.get(field) is not None and row[field] <= k) / max(1, len(valid)),
                4,
            )
            for k in ks
        }
        ranks = [row[field] for row in valid if row.get(field)]
        result[label]["mrr"] = round(sum(1 / rank for rank in ranks) / max(1, len(valid)), 4)
    result["orchestration"] = orchestration_aggregate(valid)
    return result


def orchestration_aggregate(rows: list[dict[str, Any]]) -> dict[str, Any]:
    intents: Counter[str] = Counter()
    channel_plans: Counter[str] = Counter()
    reranker: Counter[str] = Counter()
    timings: dict[str, list[float]] = defaultdict(list)
    for row in rows:
        execution = row.get("execution") or {}
        plan = execution.get("plan") or (execution.get("planner") or {}).get("plan") or {}
        intents[str(plan.get("query_intent") or "unknown")] += 1
        channels = ",".join(plan.get("modalities") or []) or "none"
        channel_plans[channels] += 1
        reranker[str((execution.get("reranker") or {}).get("status") or "unknown")] += 1
        for label, value in [
            ("planner", (execution.get("planner") or {}).get("elapsed_seconds")),
            ("retrieval", (execution.get("retrieval") or {}).get("elapsed_seconds")),
            ("reranker", (execution.get("reranker") or {}).get("elapsed_seconds")),
            ("total", execution.get("elapsed_seconds")),
        ]:
            if isinstance(value, (int, float)):
                timings[label].append(float(value))
    return {
        "query_intents": dict(intents.most_common()),
        "channel_plans": dict(channel_plans.most_common()),
        "reranker_statuses": dict(reranker.most_common()),
        "mean_stage_seconds": {
            key: round(statistics.mean(values), 3) for key, values in timings.items() if values
        },
    }


def index_quality(state: dict[str, Any]) -> dict[str, Any]:
    stage_elapsed: dict[str, list[float]] = defaultdict(list)
    warnings = []
    stage_totals: Counter[str] = Counter()
    for source_id, row in state["videos"].items():
        if row.get("index_reused"):
            continue
        stages = ((row.get("index_metrics") or {}).get("stages") or {})
        for stage, metrics in stages.items():
            stage_totals[stage] += 1
            elapsed = metrics.get("elapsed_seconds")
            if isinstance(elapsed, (int, float)):
                stage_elapsed[stage].append(float(elapsed))
            if stage == "ocr" and int(metrics.get("ocr_failed_frames") or 0):
                warnings.append(
                    {
                        "source_video_id": source_id,
                        "video_name": row["name"],
                        "kind": "ocr_failed_frames",
                        "count": int(metrics.get("ocr_failed_frames") or 0),
                        "frames": int(metrics.get("frames") or 0),
                    }
                )
            if stage in {"ocr", "asr"} and metrics.get("semantic_status") not in {None, "complete"}:
                warnings.append(
                    {
                        "source_video_id": source_id,
                        "video_name": row["name"],
                        "kind": f"{stage}_semantic_{metrics.get('semantic_status')}",
                    }
                )
    return {
        "video_count": len(state["videos"]),
        "reused_existing_indexes": sum(1 for row in state["videos"].values() if row.get("index_reused")),
        "freshly_indexed": sum(1 for row in state["videos"].values() if not row.get("index_reused")),
        "stage_completed_video_counts": dict(stage_totals),
        "stage_elapsed_seconds": {
            stage: {
                "sum": round(sum(values), 3),
                "mean": round(statistics.mean(values), 3),
                "max": round(max(values), 3),
            }
            for stage, values in stage_elapsed.items()
            if values
        },
        "warnings": warnings,
    }


def render_html(summary: dict[str, Any], rows: list[dict[str, Any]]) -> str:
    overall = summary["overall"]
    categories = []
    for name, metrics in summary["by_category"].items():
        categories.append(
            "<tr>"
            f"<td>{html.escape(name)}</td><td>{metrics['query_count']}</td>"
            f"<td>{metrics['video_recall']['@10']:.1%}</td>"
            f"<td>{metrics['temporal_iou_0.1_recall']['@10']:.1%}</td>"
            f"<td>{metrics['temporal_iou_0.3_recall']['@10']:.1%}</td>"
            f"<td>{metrics['latency_seconds']['median']}</td></tr>"
        )
    worst = sorted(
        [row for row in rows if not row.get("error")],
        key=lambda row: (row.get("first_iou_01_rank") is not None, row.get("first_iou_01_rank") or 999),
    )[:50]
    query_rows = []
    for row in worst:
        query_rows.append(
            "<tr>"
            f"<td>{html.escape(str(row.get('category') or ''))}</td>"
            f"<td>{html.escape(str(row.get('query') or ''))}</td>"
            f"<td>{row.get('first_video_rank') or '未命中'}</td>"
            f"<td>{row.get('first_iou_01_rank') or '未命中'}</td>"
            f"<td>{row.get('latency_seconds', 0):.3f}</td></tr>"
        )
    return f"""<!doctype html><html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>MomentSeek 正式平台测评</title>
<style>body{{font-family:system-ui;margin:0;background:#f4f7fb;color:#172033}}main{{max-width:1320px;margin:auto;padding:28px}}h1{{margin:0 0 8px}}.muted{{color:#667085}}.cards{{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin:24px 0}}.card,section{{background:white;border:1px solid #e4e9f1;border-radius:14px;padding:18px}}.card b{{display:block;font-size:28px;margin-top:8px}}section{{margin:16px 0;overflow:auto}}table{{width:100%;border-collapse:collapse}}th,td{{padding:10px;border-bottom:1px solid #edf0f5;text-align:left}}th{{background:#f8fafc;position:sticky;top:0}}code{{background:#eef2f7;padding:2px 5px;border-radius:5px}}@media(max-width:800px){{.cards{{grid-template-columns:1fr 1fr}}}}</style></head><body><main>
<h1>MomentSeek 正式平台当前测试集测评</h1><p class="muted">{html.escape(summary['generated_at'])} · 文件夹 {html.escape(summary['run_folder']['name'])}</p>
<div class="cards"><div class="card">Query<b>{overall['query_count']}</b></div><div class="card">视频 Recall@10<b>{overall['video_recall']['@10']:.1%}</b></div><div class="card">时间 IoU≥0.1 Recall@10<b>{overall['temporal_iou_0.1_recall']['@10']:.1%}</b></div><div class="card">中位延迟<b>{overall['latency_seconds']['median']}s</b></div></div>
<section><h2>按能力分类</h2><table><thead><tr><th>分类</th><th>Query</th><th>视频 R@10</th><th>IoU≥0.1 R@10</th><th>IoU≥0.3 R@10</th><th>中位延迟(s)</th></tr></thead><tbody>{''.join(categories)}</tbody></table></section>
<section><h2>优先复盘的未命中/低排名 Query</h2><table><thead><tr><th>分类</th><th>Query</th><th>视频首命中</th><th>时间首命中</th><th>延迟(s)</th></tr></thead><tbody>{''.join(query_rows)}</tbody></table></section>
</main></body></html>"""


def build_report(
    catalog: dict[str, Any],
    state: dict[str, Any],
    query_dir: Path,
    report_dir: Path,
) -> dict[str, Any]:
    platform_to_source = {
        str(row["platform_video_id"]): source_id for source_id, row in state["videos"].items()
    }
    rows = []
    for group in catalog.get("groups") or []:
        semantic_id = str(group["semantic_query_id"])
        result_path = query_dir / safe_result_name(semantic_id)
        if result_path.is_file():
            rows.append(group_score(group, read_json(result_path), platform_to_source))
        else:
            rows.append(
                {
                    "semantic_query_id": semantic_id,
                    "query": group.get("query"),
                    "category": group.get("category"),
                    "subcategory": group.get("subcategory"),
                    "error": (state["queries"].get(semantic_id) or {}).get("error", "missing response"),
                }
            )
    by_category: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_category[str(row.get("category") or "未分类")].append(row)
    summary = {
        "schema_version": 1,
        "generated_at": utcnow(),
        "run_folder": state["folder"],
        "catalog_summary": catalog.get("summary") or {},
        "platform": {
            "base_url": "http://127.0.0.1:8000",
            "orchestration_profile": "qwen35-skill-v1",
            "planner_mode": "auto",
            "reranker_mode": "auto",
            "modalities": ["visual", "face", "asr", "ocr"],
            "limit": 50,
        },
        "index_quality": index_quality(state),
        "overall": aggregate(rows),
        "by_category": {key: aggregate(value) for key, value in sorted(by_category.items())},
    }
    report_dir.mkdir(parents=True, exist_ok=True)
    write_json(report_dir / "summary.json", summary)
    write_json(report_dir / "query_results.json", rows)
    (report_dir / "REPORT.html").write_text(render_html(summary, rows), encoding="utf-8")
    md = [
        "# MomentSeek 正式平台当前测试集测评",
        "",
        f"- 生成时间：{summary['generated_at']}",
        f"- 测评文件夹：{state['folder']['name']} (`{state['folder']['id']}`)",
        f"- 视频：{len(state['videos'])}",
        f"- Query：{summary['overall']['query_count']}",
        f"- 成功请求：{summary['overall']['successful_query_count']}",
        f"- 失败请求：{summary['overall']['failed_query_count']}",
        "",
        "## 总体指标",
        "",
        "```json",
        json.dumps(summary["overall"], ensure_ascii=False, indent=2),
        "```",
        "",
        "## 分类指标",
        "",
    ]
    for category, value in summary["by_category"].items():
        md.extend([f"### {category}", "", "```json", json.dumps(value, ensure_ascii=False, indent=2), "```", ""])
    (report_dir / "REPORT.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    return summary


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--catalog",
        type=Path,
        default=Path("/home/momentseek-29154/testset-summary/catalog/testset_summary_catalog.json"),
    )
    parser.add_argument(
        "--run-dir",
        type=Path,
        default=Path("/home/momentseek-29154/evaluations/current-testset-20260806-v1"),
    )
    parser.add_argument("--folder-name", default="当前测试集端到端测评_20260806_v1")
    parser.add_argument("--base-url", default="http://127.0.0.1:8000")
    parser.add_argument("--poll-seconds", type=int, default=30)
    args = parser.parse_args()

    args.run_dir.mkdir(parents=True, exist_ok=True)
    frozen_path = args.run_dir / "frozen_catalog.json"
    manifest_path = args.run_dir / "video_manifest.json"
    state_path = args.run_dir / "run_state.json"
    source_catalog = read_json(args.catalog)
    if frozen_path.is_file():
        catalog = read_json(frozen_path)
    else:
        catalog = freeze_catalog(source_catalog)
        write_json(frozen_path, catalog)
    if manifest_path.is_file():
        manifest = read_json(manifest_path)
    else:
        manifest = build_manifest(catalog)
        write_json(manifest_path, manifest)

    with requests.Session() as session:
        folder = folder_for_run(session, args.base_url, args.folder_name)
        state = read_json(state_path) if state_path.is_file() else initial_state(folder, catalog)
        write_json(state_path, state)
        if state["phase"] == "upload":
            upload_videos(session, args.base_url, manifest, state, state_path)
        if state["phase"] == "index_submit":
            submit_indexes(session, args.base_url, manifest, state, state_path)
        if state["phase"] == "index_wait":
            wait_for_indexes(session, args.base_url, state, state_path, args.poll_seconds)
        if state["phase"] == "evaluate":
            run_queries(
                session,
                args.base_url,
                catalog,
                state,
                state_path,
                args.run_dir / "query_responses",
            )
        if state["phase"] == "report":
            summary = build_report(
                catalog,
                state,
                args.run_dir / "query_responses",
                args.run_dir / "report",
            )
            state["phase"] = "complete"
            state["completed_at"] = utcnow()
            state["updated_at"] = utcnow()
            state["summary"] = summary
            write_json(state_path, state)
        print(json.dumps({"phase": state["phase"], "run_dir": str(args.run_dir)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
