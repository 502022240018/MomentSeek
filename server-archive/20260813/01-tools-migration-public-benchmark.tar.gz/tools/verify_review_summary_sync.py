#!/usr/bin/env python3
"""Verify that completed 8766 reviews are represented exactly in 8786."""

from __future__ import annotations

import argparse
import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def pairs(segments: list[dict[str, Any]]) -> list[tuple[float, float]]:
    return sorted(
        (round(float(row["start_sec"]), 3), round(float(row["end_sec"]), 3))
        for row in segments
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path("/home/momentseek-29154/annotation-review/config/datasets.json"),
    )
    parser.add_argument(
        "--catalog",
        type=Path,
        default=Path("/home/momentseek-29154/testset-summary/data/catalog.json"),
    )
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    config = read_json(args.config)
    datasets = config.get("datasets") if isinstance(config, dict) else config
    catalog = read_json(args.catalog)
    actual = {
        (str(record["dataset_id"]), str(record["query_id"])): record
        for group in catalog.get("groups") or []
        for record in group.get("records") or []
        if record.get("source_kind") == "human_reviewed"
    }

    expected: dict[tuple[str, str], dict[str, Any]] = {}
    status_counts = {"approved": 0, "fix": 0, "reject": 0, "pending": 0}
    text_rows = 0
    text_materialized = 0
    notes_only = 0
    issues: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    for dataset in datasets or []:
        annotation_path = Path(str(dataset.get("annotation_path") or ""))
        review_path = Path(str(dataset.get("review_path") or ""))
        if not annotation_path.is_file() or not review_path.is_file():
            continue
        annotations = read_json(annotation_path)
        review = read_json(review_path)
        source = {
            str(row.get("query_id")): row
            for row in annotations.get("annotations") or []
            if row.get("query_id")
        }
        source.update(review.get("added_queries") or {})

        for query_id, item in (review.get("items") or {}).items():
            status = str(item.get("status") or "pending")
            status_counts[status] = status_counts.get(status, 0) + 1
            legacy_text = str(item.get("missing_segments") or "").strip()
            notes = str(item.get("notes") or "").strip()
            override = bool(
                item.get("segments_override") is True
                or item.get("corrected_segments_mode") == "replace"
                or item.get("corrected_segments")
            )
            if legacy_text:
                text_rows += 1
                if override and item.get("legacy_text_migration"):
                    text_materialized += 1
                else:
                    issues.append(
                        {
                            "dataset_id": dataset.get("id"),
                            "query_id": query_id,
                            "kind": "legacy_text_not_materialized",
                        }
                    )
            elif notes:
                notes_only += 1

            if status not in {"approved", "fix"}:
                continue
            source_item = source.get(str(query_id))
            if not source_item:
                issues.append(
                    {
                        "dataset_id": dataset.get("id"),
                        "query_id": query_id,
                        "kind": "missing_source_item",
                    }
                )
                continue
            selected_classification = str(item.get("selected_classification_id") or "").strip()
            expected[(str(dataset.get("id")), str(query_id))] = {
                "status": status,
                "query": str(item.get("suggested_query") or "").strip()
                or str(source_item.get("query") or ""),
                "classification_id": selected_classification
                or str(source_item.get("classification_id") or ""),
                "segments": pairs(
                    list(item.get("corrected_segments") or [])
                    if override
                    else list(source_item.get("segments") or [])
                ),
            }

    for key, wanted in expected.items():
        record = actual.get(key)
        if not record:
            issues.append({"dataset_id": key[0], "query_id": key[1], "kind": "missing_in_8786"})
            continue
        comparisons = {
            "status": record.get("review_status"),
            "query": record.get("query"),
            "classification_id": record.get("classification_id"),
            "segments": pairs(list(record.get("segments") or [])),
        }
        for field, got in comparisons.items():
            if got != wanted[field]:
                issues.append(
                    {
                        "dataset_id": key[0],
                        "query_id": key[1],
                        "kind": f"{field}_mismatch",
                        "expected": wanted[field],
                        "actual": got,
                    }
                )

    for key in actual:
        if key not in expected:
            issues.append({"dataset_id": key[0], "query_id": key[1], "kind": "unexpected_in_8786"})

    # Overlaps are retained deliberately because they were explicitly entered by the reviewer.
    for key, row in expected.items():
        intervals = row["segments"]
        overlaps = [
            [list(intervals[index - 1]), list(intervals[index])]
            for index in range(1, len(intervals))
            if intervals[index][0] < intervals[index - 1][1]
        ]
        if overlaps:
            warnings.append(
                {
                    "dataset_id": key[0],
                    "query_id": key[1],
                    "kind": "overlapping_intervals_preserved",
                    "overlaps": overlaps,
                }
            )

    report = {
        "schema_version": 1,
        "verified_at": datetime.now(timezone.utc).isoformat(),
        "catalog_generated_at": catalog.get("summary", {}).get("generated_at"),
        "passed": not issues,
        "counts": {
            "review_statuses": status_counts,
            "completed_expected": len(expected),
            "completed_in_8786": len(actual),
            "legacy_text_rows": text_rows,
            "legacy_text_materialized": text_materialized,
            "notes_only_rows": notes_only,
            "issues": len(issues),
            "warnings": len(warnings),
        },
        "catalog_summary": catalog.get("summary") or {},
        "issues": issues,
        "warnings": warnings,
    }
    write_json(args.output, report)
    md_path = args.output.with_suffix(".md")
    lines = [
        "# 8766 → 8786 同步核验",
        "",
        f"- 结果：{'通过' if report['passed'] else '失败'}",
        f"- 8766 已完成：{len(expected)}",
        f"- 8786 人工记录：{len(actual)}",
        f"- 文本框时间订正：{text_materialized}/{text_rows} 已结构化",
        f"- 不一致：{len(issues)}",
        f"- 提示：{len(warnings)}",
        "",
    ]
    if warnings:
        lines.extend(["## 提示", ""])
        for warning in warnings:
            lines.append(
                f"- `{warning['dataset_id']}` / `{warning['query_id']}`："
                f"保留人工输入的重叠区间 {warning['overlaps']}"
            )
    md_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
