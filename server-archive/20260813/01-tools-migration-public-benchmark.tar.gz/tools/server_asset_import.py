#!/usr/bin/env python3
"""Import stable, server-resident media files into a MomentSeek asset folder.

The source file is retained.  When source and runtime share a filesystem, this
uses a hard link so registering a large asset takes no extra disk space.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path


MEDIA_SUFFIXES = {".mp4", ".mov", ".m4v", ".mkv", ".avi", ".webm"}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-dir", type=Path, required=True)
    parser.add_argument("--runtime-upload-dir", type=Path, required=True)
    parser.add_argument("--folder-id", required=True)
    parser.add_argument("--container", default="momentseek-29154-platform")
    parser.add_argument("--state-file", type=Path, required=True)
    parser.add_argument("--min-age-seconds", type=int, default=600)
    return parser.parse_args()


def load_state(path: Path) -> dict[str, dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return {}


def save_state(path: Path, state: dict[str, dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    temporary.replace(path)


def fingerprint(path: Path) -> str:
    stat = path.stat()
    return f"{stat.st_dev}:{stat.st_ino}:{stat.st_size}:{stat.st_mtime_ns}"


def register(container: str, video_id: str, name: str, destination: Path, folder_id: str) -> None:
    code = """
import asyncio
import sys
from pathlib import Path
from app.api.video_routes import _finalize_uploaded_video

video_id, name, path, folder_id = sys.argv[1:]
existing = __import__('app.platform.context', fromlist=['catalog']).catalog.get_video(video_id)
if existing is None:
    asyncio.run(_finalize_uploaded_video(video_id, name, Path(path), [folder_id]))
"""
    subprocess.run(
        ["docker", "exec", container, "python", "-c", code, video_id, name, str(destination), folder_id],
        check=True,
    )


def main() -> int:
    args = parse_args()
    source_dir = args.source_dir.resolve()
    destination_dir = args.runtime_upload_dir.resolve()
    if not source_dir.is_dir():
        raise SystemExit(f"source directory does not exist: {source_dir}")
    destination_dir.mkdir(parents=True, exist_ok=True)
    if source_dir.stat().st_dev != destination_dir.stat().st_dev:
        raise SystemExit("source and runtime must share a filesystem for safe hard-link import")

    state = load_state(args.state_file)
    now = time.time()
    for source in sorted(source_dir.iterdir(), key=lambda path: path.name.casefold()):
        if not source.is_file() or source.suffix.lower() not in MEDIA_SUFFIXES:
            continue
        if now - source.stat().st_mtime < args.min_age_seconds:
            continue
        key = str(source)
        source_fingerprint = fingerprint(source)
        entry = state.get(key)
        if entry and entry.get("fingerprint") == source_fingerprint and entry.get("completed"):
            continue

        video_id = entry.get("video_id") if entry and entry.get("fingerprint") == source_fingerprint else uuid.uuid4().hex
        destination = destination_dir / f"{video_id}{source.suffix.lower()}"
        if not destination.exists():
            os.link(source, destination)
        state[key] = {
            "fingerprint": source_fingerprint,
            "video_id": video_id,
            "destination": str(destination),
            "completed": False,
        }
        save_state(args.state_file, state)
        try:
            register(args.container, video_id, source.name, Path("/app/runtime/uploads") / destination.name, args.folder_id)
        except subprocess.CalledProcessError as exc:
            print(f"import failed: {source}: {exc}", file=sys.stderr)
            continue
        state[key]["completed"] = True
        state[key]["completed_at"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        save_state(args.state_file, state)
        print(f"imported {source.name} -> {video_id}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
