#!/usr/bin/env python3
"""Inventory selected public benchmark queries and their downloaded videos."""

from __future__ import annotations

import argparse
import collections
import csv
import hashlib
import json
import math
import re
import subprocess
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


VIDEO_EXTENSIONS = {".mp4", ".mkv", ".mov", ".webm", ".avi", ".m4v"}


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def dataset_folder(dataset: str) -> str:
    key = re.sub(r"[^a-z0-9]", "", dataset.lower())
    if "qvhighlights" in key:
        return "qvhighlights"
    if "activitynet" in key:
        return "activitynet"
    if key == "tvr" or "tvretrieval" in key:
        return "tvr"
    return dataset.lower().replace(" ", "_")


def ffprobe(path: Path) -> dict[str, Any]:
    command = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration,size,format_name:stream=index,codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels",
        "-of",
        "json",
        str(path),
    ]
    try:
        completed = subprocess.run(command, capture_output=True, text=True, check=True, timeout=60)
        payload = json.loads(completed.stdout)
        streams = payload.get("streams") or []
        video = next((row for row in streams if row.get("codec_type") == "video"), {})
        audio = next((row for row in streams if row.get("codec_type") == "audio"), {})
        fmt = payload.get("format") or {}
        return {
            "probe_ok": True,
            "duration_sec": round(float(fmt.get("duration") or 0), 3),
            "size_bytes": int(fmt.get("size") or path.stat().st_size),
            "format": fmt.get("format_name") or "",
            "video_codec": video.get("codec_name") or "",
            "width": video.get("width"),
            "height": video.get("height"),
            "frame_rate": video.get("r_frame_rate") or "",
            "audio_codec": audio.get("codec_name") or "",
            "audio_sample_rate": int(audio["sample_rate"]) if audio.get("sample_rate") else None,
            "audio_channels": audio.get("channels"),
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "probe_ok": False,
            "duration_sec": None,
            "size_bytes": path.stat().st_size,
            "error": str(exc),
        }


def sample_sha256(path: Path, chunk_size: int = 1024 * 1024) -> str:
    size = path.stat().st_size
    digest = hashlib.sha256()
    digest.update(str(size).encode("ascii"))
    with path.open("rb") as handle:
        offsets = sorted({0, max(0, size // 2 - chunk_size // 2), max(0, size - chunk_size)})
        for offset in offsets:
            handle.seek(offset)
            digest.update(handle.read(chunk_size))
    return digest.hexdigest()


def normalized_query(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def counter_dict(values: list[Any]) -> dict[str, int]:
    return dict(sorted(collections.Counter(str(value) for value in values).items()))


def markdown_table(headers: list[str], rows: list[list[Any]]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        cells = [str(value).replace("|", "\\|").replace("\n", " ") for value in row]
        lines.append("| " + " | ".join(cells) + " |")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--queries", required=True, type=Path)
    parser.add_argument("--videos", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    if not args.queries.is_file():
        raise FileNotFoundError(args.queries)
    if not args.videos.is_dir():
        raise NotADirectoryError(args.videos)
    args.output.mkdir(parents=True, exist_ok=True)

    queries = read_json(args.queries)
    if not isinstance(queries, list):
        raise ValueError("selected queries JSON must be a list")
    video_paths = sorted(
        path for path in args.videos.rglob("*") if path.is_file() and path.suffix.lower() in VIDEO_EXTENSIONS
    )
    relative_to_path = {str(path.relative_to(args.videos)): path for path in video_paths}

    probes: dict[str, dict[str, Any]] = {}
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(ffprobe, path): path for path in video_paths}
        for future in as_completed(futures):
            path = futures[future]
            probes[str(path.relative_to(args.videos))] = future.result()

    hashes: dict[str, str] = {}
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures = {pool.submit(sample_sha256, path): path for path in video_paths}
        for future in as_completed(futures):
            path = futures[future]
            hashes[str(path.relative_to(args.videos))] = future.result()

    query_rows: list[dict[str, Any]] = []
    missing_videos: list[dict[str, Any]] = []
    stale_download_status: list[str] = []
    declared_duration_mismatches: list[dict[str, Any]] = []
    invalid_segments: list[dict[str, Any]] = []
    selected_relative_paths: set[str] = set()

    for row in queries:
        dataset = str(row.get("dataset") or "")
        video_id = str(row.get("video_id") or "")
        expected_relative = f"{dataset_folder(dataset)}/{video_id}.mp4"
        selected_relative_paths.add(expected_relative)
        video_path = relative_to_path.get(expected_relative)
        probe = probes.get(expected_relative) if video_path else None
        declared_duration = float(row.get("video_duration_sec") or 0)
        actual_duration = float(probe.get("duration_sec") or 0) if probe else None
        if not video_path:
            missing_videos.append(
                {
                    "query_id": row.get("query_id"),
                    "dataset": dataset,
                    "video_id": video_id,
                    "expected_relative_path": expected_relative,
                }
            )
        elif row.get("video_status") == "download_required":
            stale_download_status.append(str(row.get("query_id")))
        if actual_duration is not None and abs(actual_duration - declared_duration) > 0.5:
            declared_duration_mismatches.append(
                {
                    "query_id": row.get("query_id"),
                    "video_id": video_id,
                    "declared_duration_sec": declared_duration,
                    "actual_duration_sec": actual_duration,
                    "difference_sec": round(actual_duration - declared_duration, 3),
                }
            )
        for segment in row.get("positives") or []:
            start = float(segment.get("start_sec", -1))
            end = float(segment.get("end_sec", -1))
            reasons = []
            if not 0 <= start < end:
                reasons.append("invalid_order_or_negative")
            if declared_duration > 0 and end > declared_duration + 0.001:
                reasons.append("outside_declared_duration")
            if actual_duration is not None and end > actual_duration + 0.25:
                reasons.append("outside_actual_duration")
            if reasons:
                invalid_segments.append(
                    {
                        "query_id": row.get("query_id"),
                        "segment_id": segment.get("segment_id"),
                        "start_sec": start,
                        "end_sec": end,
                        "reasons": reasons,
                    }
                )
        query_rows.append(
            {
                "query_id": row.get("query_id"),
                "dataset": dataset,
                "source_split": row.get("source_split"),
                "source_query_id": row.get("source_query_id"),
                "capability_id": row.get("capability_id"),
                "subcapability_id": row.get("subcapability_id"),
                "query": row.get("query"),
                "video_id": video_id,
                "expected_relative_path": expected_relative,
                "video_exists": bool(video_path),
                "video_status": row.get("video_status"),
                "declared_duration_sec": declared_duration,
                "actual_duration_sec": actual_duration,
                "positive_count": len(row.get("positives") or []),
                "positive_duration_sec": round(
                    sum(float(seg["end_sec"]) - float(seg["start_sec"]) for seg in row.get("positives") or []),
                    3,
                ),
            }
        )

    video_rows = []
    for relative, path in relative_to_path.items():
        probe = probes[relative]
        video_rows.append(
            {
                "relative_path": relative,
                "dataset_folder": relative.split("/", 1)[0],
                "file_name": path.name,
                "selected": relative in selected_relative_paths,
                "sample_sha256": hashes[relative],
                **probe,
            }
        )
    video_rows.sort(key=lambda row: row["relative_path"])

    query_ids = [str(row.get("query_id")) for row in queries]
    duplicate_query_ids = [key for key, count in collections.Counter(query_ids).items() if count > 1]
    query_text_groups: dict[str, list[str]] = collections.defaultdict(list)
    for row in queries:
        query_text_groups[normalized_query(str(row.get("query") or ""))].append(str(row.get("query_id")))
    duplicate_query_texts = [
        {"normalized_query": text, "query_ids": ids}
        for text, ids in query_text_groups.items()
        if len(ids) > 1
    ]
    source_key_groups: dict[tuple[str, str, str], list[str]] = collections.defaultdict(list)
    for row in queries:
        key = (str(row.get("dataset")), str(row.get("source_split")), str(row.get("source_query_id")))
        source_key_groups[key].append(str(row.get("query_id")))
    duplicate_source_query_keys = [
        {"dataset": key[0], "source_split": key[1], "source_query_id": key[2], "query_ids": ids}
        for key, ids in source_key_groups.items()
        if len(ids) > 1
    ]
    hash_groups: dict[str, list[str]] = collections.defaultdict(list)
    for relative, digest in hashes.items():
        hash_groups[digest].append(relative)
    duplicate_video_files = [paths for paths in hash_groups.values() if len(paths) > 1]

    selected_unique_videos = {row["expected_relative_path"] for row in query_rows}
    matched_unique_videos = selected_unique_videos & set(relative_to_path)
    extra_videos = sorted(set(relative_to_path) - selected_unique_videos)
    failed_probes = [row["relative_path"] for row in video_rows if not row.get("probe_ok")]
    videos_without_audio = [row["relative_path"] for row in video_rows if not row.get("audio_codec")]
    total_positive_segments = sum(row["positive_count"] for row in query_rows)
    total_positive_duration = round(sum(row["positive_duration_sec"] for row in query_rows), 3)
    total_video_duration = round(sum(float(row.get("duration_sec") or 0) for row in video_rows), 3)
    query_row_by_id = {str(row["query_id"]): row for row in query_rows}
    priority_duration_mismatches = [
        row for row in declared_duration_mismatches if abs(float(row["difference_sec"])) > 1.5
    ]
    tvr_packaging_offsets = [
        row
        for row in declared_duration_mismatches
        if query_row_by_id[str(row["query_id"])]["dataset"] == "TVR"
        and abs(float(row["difference_sec"])) <= 1.0
    ]

    capability_rows = []
    capability_counter = collections.Counter(
        (str(row.get("capability_id")), str(row.get("capability_name_zh"))) for row in queries
    )
    for (capability_id, name), count in sorted(capability_counter.items()):
        capability_rows.append([capability_id, name, count])
    subcapability_rows = []
    subcapability_counter = collections.Counter(
        (str(row.get("subcapability_id")), str(row.get("subcapability_name_zh"))) for row in queries
    )
    for (subcapability_id, name), count in sorted(subcapability_counter.items()):
        subcapability_rows.append([subcapability_id, name, count])

    report = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "inputs": {
            "selected_queries": str(args.queries),
            "video_root": str(args.videos),
        },
        "summary": {
            "query_count": len(queries),
            "unique_query_id_count": len(set(query_ids)),
            "unique_selected_video_count": len(selected_unique_videos),
            "matched_selected_video_count": len(matched_unique_videos),
            "missing_selected_video_count": len(selected_unique_videos - set(relative_to_path)),
            "downloaded_video_file_count": len(video_paths),
            "extra_downloaded_video_count": len(extra_videos),
            "total_downloaded_size_bytes": sum(path.stat().st_size for path in video_paths),
            "total_downloaded_duration_sec": total_video_duration,
            "video_with_audio_count": len(video_rows) - len(videos_without_audio),
            "video_without_audio_count": len(videos_without_audio),
            "total_positive_segment_count": total_positive_segments,
            "total_positive_duration_sec": total_positive_duration,
        },
        "distributions": {
            "dataset": counter_dict([row.get("dataset") for row in queries]),
            "source_split": counter_dict([row.get("source_split") for row in queries]),
            "annotation_status": counter_dict([row.get("annotation_status") for row in queries]),
            "video_status": counter_dict([row.get("video_status") for row in queries]),
            "annotation_origin": counter_dict([row.get("annotation_origin") for row in queries]),
            "time_coordinate": counter_dict([row.get("time_coordinate") for row in queries]),
            "capability": {
                f"{key[0]} | {key[1]}": count
                for key, count in sorted(collections.Counter(
                    (str(item.get("capability_id")), str(item.get("capability_name_zh"))) for item in queries
                ).items())
            },
            "subcapability": {
                f"{key[0]} | {key[1]}": count
                for key, count in sorted(subcapability_counter.items())
            },
            "queries_per_video": counter_dict(
                list(collections.Counter(row["expected_relative_path"] for row in query_rows).values())
            ),
            "positive_segments_per_query": counter_dict([row["positive_count"] for row in query_rows]),
            "video_codec": counter_dict([row.get("video_codec") for row in video_rows if row.get("probe_ok")]),
            "resolution": counter_dict(
                [f"{row.get('width')}x{row.get('height')}" for row in video_rows if row.get("probe_ok")]
            ),
        },
        "checks": {
            "duplicate_query_ids": duplicate_query_ids,
            "duplicate_query_texts": duplicate_query_texts,
            "duplicate_source_query_keys": duplicate_source_query_keys,
            "missing_videos": missing_videos,
            "extra_videos": extra_videos,
            "stale_download_required_query_ids": stale_download_status,
            "declared_duration_mismatches_over_0_5s": declared_duration_mismatches,
            "invalid_positive_segments": invalid_segments,
            "failed_video_probes": failed_probes,
            "videos_without_audio": videos_without_audio,
            "duplicate_video_files_by_sample_hash": duplicate_video_files,
            "priority_duration_mismatches_over_1_5s": priority_duration_mismatches,
            "tvr_packaging_offsets_within_1s": tvr_packaging_offsets,
        },
        "queries": query_rows,
        "videos": video_rows,
    }
    write_json(args.output / "public_benchmark_inventory.json", report)

    with (args.output / "public_benchmark_queries.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(query_rows[0]) if query_rows else [])
        writer.writeheader()
        writer.writerows(query_rows)
    with (args.output / "public_benchmark_videos.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        fields = sorted(set().union(*(row.keys() for row in video_rows))) if video_rows else []
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(video_rows)

    size_gib = report["summary"]["total_downloaded_size_bytes"] / 1024**3
    missing_count = report["summary"]["missing_selected_video_count"]
    lines = [
        "# 公开集 Query 与视频资产盘点",
        "",
        f"生成时间：{report['generated_at']}",
        "",
        "## 结论摘要",
        "",
        f"- Query：{len(queries)} 条，唯一 Query ID：{len(set(query_ids))}。",
        f"- 选中视频：{len(selected_unique_videos)} 个；已匹配：{len(matched_unique_videos)} 个；缺失：{missing_count} 个。",
        f"- 视频目录：{len(video_paths)} 个文件，总大小 {size_gib:.2f} GiB；未被当前 Query 选中的额外视频 {len(extra_videos)} 个。",
        f"- 可用视频总时长 {total_video_duration / 3600:.2f} 小时；含音轨 {len(video_rows) - len(videos_without_audio)} 个，无音轨 {len(videos_without_audio)} 个。",
        f"- 正例片段：{total_positive_segments} 个，总标注时长 {total_positive_duration:.1f} 秒。",
        f"- `video_status=download_required` 但视频已存在的 Query：{len(stale_download_status)} 条。",
        f"- 声明时长与文件时长相差超过 0.5 秒：{len(declared_duration_mismatches)} 条 Query。",
        f"- 其中需优先核验的时长大偏差（绝对值 > 1.5 秒）：{len(priority_duration_mismatches)} 条；TVR 约 0.6 秒系统性尾差：{len(tvr_packaging_offsets)} 条。",
        f"- 越界或非法正例片段：{len(invalid_segments)} 个；无法解析的视频：{len(failed_probes)} 个。",
        "",
        "## 风险分级与建议",
        "",
        "1. **P0：补齐 4 个缺失的 ActivityNet 视频。** 当前 114 条 Query 无法形成完整闭集评测。",
        "2. **P0：确认 TVR 的使用目标。** 37 个 TVR 文件全部无音轨；若要评测 ASR、人物对话或音频检索通路，需要重新取得带音轨版本，或明确把 TVR 限定为视觉检索集。",
        "3. **P1：复核 5 条 ActivityNet 大时长偏差。** 文件比声明时长短 1.943–59.690 秒；正例片段目前没有越界，但视频上下文可能不完整。",
        "4. **P1：生成状态覆盖表。** 原 JSON 的 114 条记录都还是 `download_required`，其中 110 条实际已经下载；建议生成派生状态清单，不直接改源标注。",
        "5. **P2：TVR 的约 0.6 秒尾差可按封装/帧率系统误差处理。** 当前没有正例越界，不建议仅为此重切视频。",
        "6. **P2：正式汇总指标时按能力分层。** 一级能力样本数从 5 到 20 不等，且能力与来源数据集强相关，直接算单一总均值会被 QVHighlights 和前三类能力主导。",
        "",
        "## 数据集分布",
        "",
        markdown_table(["数据集", "Query 数"], [[key, value] for key, value in report["distributions"]["dataset"].items()]),
        "",
        "## 一级能力分布",
        "",
        markdown_table(["能力 ID", "能力名称", "Query 数"], capability_rows),
        "",
        "## 二级能力分布",
        "",
        markdown_table(["子能力 ID", "子能力名称", "Query 数"], subcapability_rows),
        "",
        "## 质量检查",
        "",
        f"- 重复 Query ID：{len(duplicate_query_ids)}",
        f"- 完全相同 Query 文本组：{len(duplicate_query_texts)}",
        f"- 重复源 Query 键：{len(duplicate_source_query_keys)}",
        f"- 缺失视频：{len(missing_videos)}",
        f"- 额外视频：{len(extra_videos)}",
        f"- 样本哈希疑似重复视频组：{len(duplicate_video_files)}",
        "",
    ]
    if missing_videos:
        lines.extend(
            [
                "### 缺失视频",
                "",
                markdown_table(
                    ["Query ID", "数据集", "Video ID", "预期路径"],
                    [
                        [row["query_id"], row["dataset"], row["video_id"], row["expected_relative_path"]]
                        for row in missing_videos
                    ],
                ),
                "",
            ]
        )
    if extra_videos:
        lines.extend(["### 当前未选中的视频", "", *[f"- `{path}`" for path in extra_videos], ""])
    if declared_duration_mismatches:
        lines.extend(
            [
                "### 时长差异超过 0.5 秒",
                "",
                markdown_table(
                    ["Query ID", "Video ID", "声明时长", "文件时长", "差值"],
                    [
                        [
                            row["query_id"],
                            row["video_id"],
                            row["declared_duration_sec"],
                            row["actual_duration_sec"],
                            row["difference_sec"],
                        ]
                        for row in declared_duration_mismatches
                    ],
                ),
                "",
            ]
        )
    lines.extend(
        [
            "## 文件说明",
            "",
            "- `public_benchmark_inventory.json`：完整机器可读盘点与检查结果。",
            "- `public_benchmark_queries.csv`：逐 Query 映射、时长和正例统计。",
            "- `public_benchmark_videos.csv`：逐视频编码、分辨率、时长、大小和样本哈希。",
        ]
    )
    (args.output / "PUBLIC_BENCHMARK_INVENTORY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(args.output), **report["summary"], "checks": {key: len(value) for key, value in report["checks"].items()}}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
