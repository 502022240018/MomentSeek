#!/usr/bin/env python3
"""Materialize legacy free-text segment corrections into review JSON.

The script is intentionally conservative:

* it only touches review files under the configured review root;
* source annotation JSON files are read-only;
* every changed review file is backed up before replacement;
* dry-run is the default and ``--apply`` is required for writes;
* the exact legacy text is preserved as migration evidence.
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


DEFAULT_CONFIG = Path("/home/momentseek-29154/annotation-review/config/datasets.json")
DEFAULT_BACKUP_ROOT = Path("/home/momentseek-29154/annotation-review/backups")
DEFAULT_REPORT_ROOT = Path("/home/momentseek-29154/query-correction-migration")

FLOWER_EXPLICIT_SEGMENTS: dict[str, list[tuple[float, float]]] = {
    "flower_youth_silk_road_ep7_v7_q002": [
        (4898.480, 4902.000),
        (4994.000, 4996.760),
        (4925.000, 4928.000),
        (4651.000, 4654.000),
        (4035.000, 4040.000),
        (1108.000, 1112.000),
        (4640.000, 4645.000),
    ],
    "flower_youth_silk_road_ep7_v7_q029": [
        (1375.000, 1388.000),
        (1369.000, 1373.000),
        (933.000, 940.000),
        (1373.000, 1385.000),
    ],
    "flower_youth_silk_road_ep7_v7_q088": [(2680.000, 2850.000)],
}


def read_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def atomic_write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    os.replace(tmp, path)


def datasets_from_config(path: Path) -> list[dict[str, Any]]:
    payload = read_json(path)
    if isinstance(payload, dict):
        payload = payload.get("datasets") or []
    if not isinstance(payload, list):
        raise ValueError("datasets config must contain a list")
    return [row for row in payload if isinstance(row, dict)]


def compact_segments(query_id: str, segments: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for index, segment in enumerate(segments, start=1):
        start = round(float(segment["start_sec"]), 3)
        end = round(float(segment["end_sec"]), 3)
        if start < 0 or end <= start:
            raise ValueError(f"invalid segment for {query_id}: {start}-{end}")
        result.append(
            {
                "segment_id": str(segment.get("segment_id") or f"{query_id}_human_s{index:02d}"),
                "start_sec": start,
                "end_sec": end,
                "duration_sec": round(end - start, 3),
            }
        )
    return sorted(result, key=lambda row: (row["start_sec"], row["end_sec"]))


def explicit_segments(query_id: str) -> list[dict[str, Any]]:
    return compact_segments(
        query_id,
        [
            {
                "segment_id": f"{query_id}_human_s{index:02d}",
                "start_sec": start,
                "end_sec": end,
            }
            for index, (start, end) in enumerate(FLOWER_EXPLICIT_SEGMENTS[query_id], start=1)
        ],
    )


def segment_pairs(segments: list[dict[str, Any]]) -> list[list[float]]:
    return [
        [round(float(row["start_sec"]), 3), round(float(row["end_sec"]), 3)]
        for row in segments
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--backup-root", type=Path, default=DEFAULT_BACKUP_ROOT)
    parser.add_argument("--report-root", type=Path, default=DEFAULT_REPORT_ROOT)
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    now = datetime.now(timezone.utc)
    stamp = now.strftime("%Y%m%dT%H%M%SZ")
    run_dir = args.report_root / stamp
    backup_dir = args.backup_root / f"legacy-text-migration-{stamp}"
    rows: list[dict[str, Any]] = []
    review_updates: dict[Path, dict[str, Any]] = {}
    actionable_count = 0

    for dataset in datasets_from_config(args.config):
        dataset_id = str(dataset.get("id") or "")
        annotation_path = Path(str(dataset.get("annotation_path") or ""))
        review_path = Path(str(dataset.get("review_path") or ""))
        if not annotation_path.is_file() or not review_path.is_file():
            continue

        annotation = read_json(annotation_path)
        annotations = {
            str(item.get("query_id")): item
            for item in annotation.get("annotations") or []
            if item.get("query_id")
        }
        review = read_json(review_path)
        changed = copy.deepcopy(review)

        for query_id, item_review in (review.get("items") or {}).items():
            legacy_text = str(item_review.get("missing_segments") or "").strip()
            notes = str(item_review.get("notes") or "").strip()
            if not legacy_text and not notes:
                continue

            source_item = annotations.get(str(query_id)) or (review.get("added_queries") or {}).get(str(query_id))
            row: dict[str, Any] = {
                "dataset_id": dataset_id,
                "query_id": query_id,
                "status": item_review.get("status"),
                "source_query": (source_item or {}).get("query"),
                "missing_segments": legacy_text,
                "notes": notes,
                "action": "evidence_only",
            }

            new_segments: list[dict[str, Any]] | None = None
            strategy = ""
            warning = ""
            if legacy_text:
                if dataset_id == "chinese_restaurant_nanyang_ep5_direct":
                    if not source_item:
                        raise KeyError(f"source item not found: {dataset_id}/{query_id}")
                    new_segments = compact_segments(query_id, list(source_item.get("segments") or []))
                    strategy = "source_annotation_already_contains_text_correction"
                    if query_id.endswith("_q047"):
                        warning = (
                            "Legacy text says 11:12.8-13:15.0, but the source annotation is "
                            "13:12.8-13:15.0; retained the coherent 2.2-second source interval."
                        )
                        strategy = "source_annotation_retained_over_legacy_start_minute_typo"
                elif dataset_id == "flower_youth_silk_road_ep7" and query_id in FLOWER_EXPLICIT_SEGMENTS:
                    new_segments = explicit_segments(query_id)
                    strategy = "parsed_from_legacy_text_and_manually_verified"

            if new_segments is not None:
                if not new_segments:
                    raise ValueError(f"no corrected segments for {dataset_id}/{query_id}")
                actionable_count += 1
                target = changed["items"][query_id]
                previous = compact_segments(query_id, list(target.get("corrected_segments") or []))
                target["segments_override"] = True
                target["corrected_segments_mode"] = "replace"
                target["corrected_segments"] = new_segments
                target["updated_at"] = now.isoformat()
                target["legacy_text_migration"] = {
                    "applied_at": now.isoformat(),
                    "migration_version": 1,
                    "legacy_missing_segments": legacy_text,
                    "strategy": strategy,
                    "warning": warning,
                    "previous_corrected_segments": previous,
                    "weak_match_noted": "弱" in legacy_text,
                }
                row.update(
                    {
                        "action": "materialize_segments",
                        "strategy": strategy,
                        "warning": warning,
                        "before": segment_pairs(previous),
                        "after": segment_pairs(new_segments),
                    }
                )
            rows.append(row)

        if changed != review:
            changed["updated_at"] = now.isoformat()
            review_updates[review_path] = changed

    if actionable_count != 19:
        raise RuntimeError(f"safety check failed: expected 19 actionable text corrections, got {actionable_count}")

    report = {
        "schema_version": 1,
        "generated_at": now.isoformat(),
        "mode": "apply" if args.apply else "dry-run",
        "config": str(args.config),
        "review_files_changed": len(review_updates),
        "actionable_text_corrections": actionable_count,
        "text_or_note_records_audited": len(rows),
        "source_annotation_files_modified": 0,
        "backup_dir": str(backup_dir) if args.apply else "",
        "records": rows,
    }

    if args.apply:
        run_dir.mkdir(parents=True, exist_ok=False)
        backup_dir.mkdir(parents=True, exist_ok=False)
        for review_path, payload in review_updates.items():
            relative = review_path.relative_to("/home/momentseek-29154/annotation-review/reviews")
            backup_path = backup_dir / relative
            backup_path.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(review_path, backup_path)
            atomic_write_json(review_path, payload)
        atomic_write_json(run_dir / "migration_report.json", report)
        markdown = [
            "# 文本框订正结构化迁移报告",
            "",
            f"- 执行时间：{now.isoformat()}",
            f"- 审计文本/备注记录：{len(rows)}",
            f"- 应用时间段订正：{actionable_count}",
            f"- 修改审核文件：{len(review_updates)}",
            "- 原始标注 JSON 修改：0",
            f"- 备份目录：`{backup_dir}`",
            "",
            "## 已结构化记录",
            "",
        ]
        for row in rows:
            if row["action"] != "materialize_segments":
                continue
            markdown.append(
                f"- `{row['dataset_id']}` / `{row['query_id']}`："
                f"{row['after']}（{row['strategy']}）"
            )
            if row.get("warning"):
                markdown.append(f"  - 注意：{row['warning']}")
        atomic_write_json(run_dir / "migration_report.machine.json", report)
        (run_dir / "MIGRATION_REPORT.md").write_text("\n".join(markdown) + "\n", encoding="utf-8")

    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
