#!/usr/bin/env python3
import json
from pathlib import Path

ROOT = Path("/home/momentseek-29154/evaluations")
RUNS = {
    "Planner+精排": ROOT / "current-testset-20260806-v1",
    "Visual-only": ROOT / "current-testset-20260806-visual-only",
}

for name, root in RUNS.items():
    new = json.loads((root / "report_with_coverage/summary.json").read_text(encoding="utf-8"))
    old = json.loads((root / "report/summary.json").read_text(encoding="utf-8"))
    assert new["overall"]["video_recall"] == old["overall"]["video_recall"]
    assert new["overall"]["temporal_iou_0.1_recall"] == old["overall"]["temporal_iou_0.1_recall"]
    multi = new["overall"]["multi_answer_coverage"]
    all_rows = new["overall"]["coverage"]
    payload = {
        "name": name,
        "multi_answer_query_count": multi["query_count"],
        "multi_answer": {
            metric: {key: values[key] for key in ("@5", "@10", "@20", "@50")}
            for metric, values in multi.items()
            if metric != "query_count"
        },
        "all_queries": {
            metric: {key: values[key] for key in ("@5", "@10")}
            for metric, values in all_rows.items()
            if metric != "query_count"
        },
    }
    print(json.dumps(payload, ensure_ascii=False))

    rows = json.loads((root / "report_with_coverage/query_results.json").read_text(encoding="utf-8"))
    for row in rows:
        if row.get("error"):
            continue
        for metric in ("video", "temporal_iou_0.1", "temporal_iou_0.3"):
            previous = -1
            for key in ("@1", "@3", "@5", "@10", "@20", "@50"):
                entry = row["coverage"][key][metric]
                assert 0 <= entry["coverage"] <= 1
                assert 0 <= entry["precision"] <= 1
                assert entry["matched"] >= previous
                previous = entry["matched"]
