import base64
import logging
import socket
import threading
import time
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Mapping, Optional, Tuple, Union
from urllib import parse

import grpc
import orjson
from grpc._cython import cygrpc

from pymilvus.client.call_context import CallContext, _api_level_md
from pymilvus.decorators import (
    ignore_unimplemented,
    retry_on_rpc_failure,
    retry_on_schema_mismatch,
    upgrade_reminder,
)
from pymilvus.exceptions import (
    AmbiguousIndexName,
    DescribeCollectionException,
    ErrorCode,
    ExceptionsMessage,
    MilvusException,
    ParamError,
)
from pymilvus.grpc_gen import common_pb2, milvus_pb2_grpc
from pymilvus.grpc_gen import milvus_pb2 as milvus_types
from pymilvus.orm.schema import Function, FunctionScore, Highlighter
from pymilvus.settings import Config

from . import entity_helper, interceptor, ts_utils, utils
from .abstract import (
    AnnSearchRequest,
    BaseRanker,
    CollectionSchema,
    FieldSchema,
    MutationResult,
)
from .asynch import (
    CreateIndexFuture,
    FlushFuture,
    MutationFuture,
    SearchFuture,
)
from .cache import GlobalCache
from .check import (
    check_id_and_data,
    check_pass_param,
    is_legal_host,
    is_legal_port,
)
from .constants import ITERATOR_SESSION_TS_FIELD
from .embedding_list import EmbeddingList
from .prepare import Prepare
from .search_result import SearchResult
from .types import (
    AnalyzeResult,
    BulkInsertState,
    CompactionPlans,
    CompactionState,
    DatabaseInfo,
    GrantInfo,
    Group,
    HybridExtraList,
    IndexState,
    LoadState,
    Plan,
    PrivilegeGroupInfo,
    Replica,
    ReplicaInfo,
    ResourceGroupConfig,
    ResourceGroupInfo,
    RoleInfo,
    Shard,
    State,
    Status,
    UserInfo,
    get_extra_info,
)
from .utils import (
    check_invalid_binary_vector,
    check_status,
    get_server_type,
    immutable_message_to_dict,
    is_successful,
    len_of,
    replicate_checkpoint_to_dict,
)

logger = logging.getLogger(__name__)


class ReconnectHandler:
    def __init__(self, conns: object, connection_name: str, kwargs: object) -> None:
        self.connection_name = connection_name
        self.conns = conns
        self._kwargs = kwargs
        self.is_idle_state = False
        self.reconnect_lock = threading.Lock()

    def reset_db_name(self, db_name: str):
        self._kwargs["db_name"] = db_name

    def check_state_and_reconnect_later(self):
        check_after_seconds = 3
        logger.debug(f"state is idle, schedule reconnect in {check_after_seconds} seconds")
        time.sleep(check_after_seconds)
        if not self.is_idle_state:
            logger.debug("idle state changed, skip reconnect")
            return
        with self.reconnect_lock:
            logger.info("reconnect on idle state")
            self.is_idle_state = False
            try:
                logger.debug("try disconnecting old connection...")
                self.conns.disconnect(self.connection_name)
            except Exception:
                logger.warning("disconnect failed: {e}")
            finally:
                reconnected = False
                while not reconnected:
                    try:
                        logger.debug("try reconnecting...")
                        self.conns.connect(self.connection_name, **self._kwargs)
                        reconnected = True
                    except Exception as e:
                        logger.warning(
                            f"reconnect failed: {e}, try again after {check_after_seconds} seconds"
                        )
                        time.sleep(check_after_seconds)
            logger.info("reconnected")

    def reconnect_on_idle(self, state: object):
        logger.debug(f"state change to: {state}")
        with self.reconnect_lock:
            if state.value[1] != "idle":
                self.is_idle_state = False
                return
            self.is_idle_state = True
            threading.Thread(target=self.check_state_and_reconnect_later).start()


class GrpcHandler:
    # pylint: disable=too-many-instance-attributes

    def __init__(
        self,
        uri: str = Config.GRPC_URI,
        host: str = "",
        port: str = "",
        channel: Optional[grpc.Channel] = None,
        **kwargs,
    ) -> None:
        self._stub = None
        self._channel = channel
        self._channel_swap_lock = threading.Lock()

        addr = kwargs.get("address")
        self._address = addr if addr is not None else self.__get_address(uri, host, port)
        self._log_level = None
        self._user = kwargs.get("user")
        self._connect_reserved = kwargs.get("option", {})
        self._server_info_cache = None
        self._grpc_options = kwargs.get("grpc_options", {})
        self._set_authorization(**kwargs)
        self._setup_grpc_channel()
        self.callbacks = []
        self._reconnect_handler = None

    def register_reconnect_handler(self, handler: ReconnectHandler):
        if handler is not None:
            self._reconnect_handler = handler
            self.register_state_change_callback(handler.reconnect_on_idle)

    def register_state_change_callback(self, callback: Callable):
        self.callbacks.append(callback)
        self._channel.subscribe(callback, try_to_connect=True)

    def deregister_state_change_callbacks(self):
        for callback in self.callbacks:
            self._channel.unsubscribe(callback)
        self.callbacks = []

    def __get_address(self, uri: str, host: str, port: str) -> str:
        if host != "" and port != "" and is_legal_host(host) and is_legal_port(port):
            return f"{host}:{port}"

        try:
            parsed_uri = parse.urlparse(uri)
        except Exception as e:
            raise ParamError(message=f"Illegal uri: [{uri}], {e}") from e
        return parsed_uri.netloc

    def _set_authorization(self, **kwargs):
        secure = kwargs.get("secure", False)
        if not isinstance(secure, bool):
            raise ParamError(message="secure must be bool type")
        self._secure = secure
        self._client_pem_path = kwargs.get("client_pem_path", "")
        self._client_key_path = kwargs.get("client_key_path", "")
        self._ca_pem_path = kwargs.get("ca_pem_path", "")
        self._server_pem_path = kwargs.get("server_pem_path", "")
        self._server_name = kwargs.get("server_name", "")

        self._authorization_interceptor = None
        self._setup_authorization_interceptor(
            kwargs.get("user"),
            kwargs.get("password"),
            kwargs.get("token"),
        )

    def __enter__(self):
        return self

    def __exit__(self: object, exc_type: object, exc_val: object, exc_tb: object):
        pass

    def _wait_for_channel_ready(
        self,
        timeout: Optional[float] = 10,
        channel: Optional[grpc.Channel] = None,
        final_channel: Optional[grpc.Channel] = None,
        stub: Optional[milvus_pb2_grpc.MilvusServiceStub] = None,
        address: Optional[str] = None,
    ) -> Tuple[grpc.Channel, milvus_pb2_grpc.MilvusServiceStub]:
        update_self = channel is None
        target_channel = channel if channel is not None else self._channel
        target_final_channel = final_channel if final_channel is not None else self._final_channel
        target_stub = stub if stub is not None else self._stub

        if target_channel is None:
            raise MilvusException(
                code=Status.CONNECT_FAILED,
                message="No channel in handler, please setup grpc channel first",
            )

        # grpc.Future.result(timeout=None) blocks indefinitely.  Normalise None
        # to the default 10 s so that an unreachable URI raises MilvusException
        # instead of hanging forever (mirrors async ensure_channel_ready behaviour).
        effective_timeout = timeout if timeout is not None else 10

        setup_kwargs: Dict[str, Any] = {"timeout": effective_timeout}
        if not update_self:
            setup_kwargs.update(final_channel=target_final_channel, stub=target_stub)

        try:
            target_final_channel, target_stub = self._setup_identifier_interceptor(
                self._user, **setup_kwargs
            )
        except grpc.RpcError as e:
            if update_self:
                self.close()
            target_address = address or self._address
            raise MilvusException(
                code=Status.CONNECT_FAILED,
                message=f"Fail connecting to server on {target_address}, illegal connection params or server unavailable",
            ) from e
        except Exception:
            if update_self:
                self.close()
            raise
        else:
            return target_final_channel, target_stub

    def close(self):
        with self._channel_swap_lock:
            self.deregister_state_change_callbacks()
            if self._channel:
                self._channel.close()
            self._channel = None

    def _close_channel_safely(self, channel: Optional[grpc.Channel]):
        if channel is None:
            return
        try:
            channel.close()
        except Exception as exc:
            logger.warning("failed to close retired grpc channel: %s", exc)

    def _move_state_change_callbacks(
        self, old_channel: Optional[grpc.Channel], new_channel: grpc.Channel
    ):
        for callback in self.callbacks:
            if old_channel is not None:
                try:
                    old_channel.unsubscribe(callback)
                except Exception as exc:
                    logger.warning("failed to unsubscribe grpc channel callback: %s", exc)
            try:
                new_channel.subscribe(callback, try_to_connect=True)
            except Exception as exc:
                logger.warning("failed to subscribe grpc channel callback: %s", exc)

    def reconnect(self, address: Optional[str] = None, timeout: float = 10):
        """Reset the gRPC channel, reconnecting to the same or a new address.

        Preserves the handler object identity so that all existing references
        (MilvusClient._handler, in-flight retry loops) continue to work.

        Args:
            address: Optional new address to connect to.
            timeout: Connection timeout in seconds.
        """
        target_address = address or self._address
        new_channel = self._create_grpc_channel(target_address)
        try:
            new_final_channel, new_stub = self._setup_grpc_channel(channel=new_channel)
            new_final_channel, new_stub = self._wait_for_channel_ready(
                timeout=timeout,
                channel=new_channel,
                final_channel=new_final_channel,
                stub=new_stub,
                address=target_address,
            )
        except Exception:
            self._close_channel_safely(new_channel)
            raise

        with self._channel_swap_lock:
            old_channel = self._channel
            self._channel = new_channel
            self._final_channel = new_final_channel
            self._stub = new_stub
            self._address = target_address
            self._move_state_change_callbacks(old_channel, new_channel)

    def reset_db_name(self, db_name: str):
        """Deprecated: db_name is now passed per-request via kwargs.

        This method is kept for backward compatibility but does nothing.
        Use MilvusClient.use_database() instead.
        """

    def _setup_authorization_interceptor(self, user: str, password: str, token: str):
        keys = []
        values = []
        if token:
            authorization = base64.b64encode(f"{token}".encode())
            keys.append("authorization")
            values.append(authorization)
        elif user and password:
            authorization = base64.b64encode(f"{user}:{password}".encode())
            keys.append("authorization")
            values.append(authorization)
        if len(keys) > 0 and len(values) > 0:
            self._authorization_interceptor = interceptor.header_adder_interceptor(keys, values)

    def _create_grpc_channel(self, address: Optional[str] = None):
        """Create a ddl grpc channel"""
        default_opts = {
            cygrpc.ChannelArgKey.max_send_message_length: -1,
            cygrpc.ChannelArgKey.max_receive_message_length: -1,
            "grpc.enable_retries": 1,
            "grpc.keepalive_time_ms": 10000,
            "grpc.keepalive_timeout_ms": 5000,
            "grpc.keepalive_permit_without_calls": True,
        }
        # Merge user-provided options (user options override defaults)
        default_opts.update(self._grpc_options)
        opts = list(default_opts.items())
        target_address = address or self._address

        if not self._secure:
            return grpc.insecure_channel(
                target_address,
                options=opts,
            )

        if self._server_name != "":
            opts.append(("grpc.ssl_target_name_override", self._server_name))

        root_cert, private_k, cert_chain = None, None, None
        if self._server_pem_path != "":
            with Path(self._server_pem_path).open("rb") as f:
                root_cert = f.read()
        elif (
            self._client_pem_path != "" and self._client_key_path != "" and self._ca_pem_path != ""
        ):
            with Path(self._ca_pem_path).open("rb") as f:
                root_cert = f.read()
            with Path(self._client_key_path).open("rb") as f:
                private_k = f.read()
            with Path(self._client_pem_path).open("rb") as f:
                cert_chain = f.read()

        creds = grpc.ssl_channel_credentials(
            root_certificates=root_cert,
            private_key=private_k,
            certificate_chain=cert_chain,
        )
        return grpc.secure_channel(
            target_address,
            creds,
            options=opts,
        )

    def _setup_grpc_channel(
        self, channel: Optional[grpc.Channel] = None
    ) -> Tuple[grpc.Channel, milvus_pb2_grpc.MilvusServiceStub]:
        update_self = channel is None
        if update_self and self._channel is None:
            self._channel = self._create_grpc_channel()

        target_channel = channel if channel is not None else self._channel

        # avoid to add duplicate headers.
        final_channel = target_channel
        if self._authorization_interceptor:
            final_channel = grpc.intercept_channel(final_channel, self._authorization_interceptor)
        if self._log_level:
            log_level_interceptor = interceptor.header_adder_interceptor(
                ["log_level"], [self._log_level]
            )
            final_channel = grpc.intercept_channel(final_channel, log_level_interceptor)
            self._log_level = None
        stub = milvus_pb2_grpc.MilvusServiceStub(final_channel)
        if update_self:
            self._final_channel = final_channel
            self._stub = stub
        return final_channel, stub

    def set_onetime_loglevel(self, log_level: str):
        self._log_level = log_level
        self._setup_grpc_channel()

    def _setup_identifier_interceptor(
        self,
        user: str,
        timeout: int = 10,
        final_channel: Optional[grpc.Channel] = None,
        stub: Optional[milvus_pb2_grpc.MilvusServiceStub] = None,
    ) -> Tuple[grpc.Channel, milvus_pb2_grpc.MilvusServiceStub]:
        update_self = final_channel is None and stub is None
        target_final_channel = final_channel if final_channel is not None else self._final_channel
        target_stub = stub if stub is not None else self._stub
        host = socket.gethostname()
        identifier = (
            self.__internal_register(user, host, timeout=timeout)
            if update_self
            else self._internal_register(user, host, stub=target_stub, timeout=timeout)
        )
        identifier_interceptor = interceptor.header_adder_interceptor(
            ["identifier"], [str(identifier)]
        )
        target_final_channel = grpc.intercept_channel(target_final_channel, identifier_interceptor)
        target_stub = milvus_pb2_grpc.MilvusServiceStub(target_final_channel)
        if update_self:
            self._identifier = identifier
            self._identifier_interceptor = identifier_interceptor
            self._final_channel = target_final_channel
            self._stub = target_stub
        return target_final_channel, target_stub

    @property
    def server_address(self):
        return self._address

    def get_server_type(self):
        return get_server_type(self.server_address.split(":")[0])

    def reset_password(
        self,
        user: str,
        old_password: str,
        new_password: str,
        timeout: Optional[float] = None,
        **kwargs,
    ):
        """
        reset password and then setup the grpc channel.
        """
        self.update_password(user, old_password, new_password, timeout=timeout, **kwargs)
        self._setup_authorization_interceptor(user, new_password, None)
        self._setup_grpc_channel()

    @retry_on_rpc_failure()
    def create_collection(
        self,
        collection_name: str,
        fields: Union[CollectionSchema, Dict[str, Iterable]],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.create_collection_request(collection_name, fields, **kwargs)

        rf = self._stub.CreateCollection.future(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        if kwargs.get("_async", False):
            return rf
        status = rf.result()
        check_status(status)
        return None

    @retry_on_rpc_failure()
    def drop_collection(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.drop_collection_request(collection_name)

        status = self._stub.DropCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)
        # Invalidate global schema cache
        self._invalidate_schema(collection_name, db_name=(context.get_db_name() if context else ""))

    @retry_on_rpc_failure()
    def truncate_collection(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.truncate_collection_request(collection_name)

        response = self._stub.TruncateCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)

    @retry_on_rpc_failure()
    def add_collection_field(
        self,
        collection_name: str,
        field_schema: FieldSchema,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.add_collection_field_request(collection_name, field_schema)
        status = self._stub.AddCollectionField(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def drop_collection_function(
        self,
        collection_name: str,
        function_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.drop_collection_function_request(collection_name, function_name)

        status = self._stub.DropCollectionFunction(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def add_collection_function(
        self,
        collection_name: str,
        function: Function,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.add_collection_function_request(collection_name, function)

        status = self._stub.AddCollectionFunction(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def alter_collection_function(
        self,
        collection_name: str,
        function_name: str,
        function: Function,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.alter_collection_function_request(
            collection_name, function_name, function
        )

        status = self._stub.AlterCollectionFunction(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def alter_collection_properties(
        self,
        collection_name: str,
        properties: List,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, properties=properties, timeout=timeout)
        request = Prepare.alter_collection_request(collection_name, properties=properties)
        status = self._stub.AlterCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def alter_collection_field_properties(
        self,
        collection_name: str,
        field_name: str,
        field_params: Dict[str, Any],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, properties=field_params, timeout=timeout)
        request = Prepare.alter_collection_field_request(
            collection_name=collection_name, field_name=field_name, field_param=field_params
        )
        status = self._stub.AlterCollectionField(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def drop_collection_properties(
        self,
        collection_name: str,
        property_keys: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.alter_collection_request(collection_name, delete_keys=property_keys)
        status = self._stub.AlterCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def has_collection(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.describe_collection_request(collection_name)
        reply = self._stub.DescribeCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )

        # For compatibility with Milvus less than 2.3.2, which does not support status.code.
        if (
            reply.status.error_code == common_pb2.UnexpectedError
            and "can't find collection" in reply.status.reason
        ):
            return False

        if reply.status.error_code == common_pb2.CollectionNotExists:
            return False

        if is_successful(reply.status):
            return True

        if reply.status.code == ErrorCode.COLLECTION_NOT_FOUND:
            return False

        raise MilvusException(reply.status.code, reply.status.reason, reply.status.error_code)

    @retry_on_rpc_failure()
    def describe_collection(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.describe_collection_request(collection_name)
        response = self._stub.DescribeCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status

        if is_successful(status):
            return CollectionSchema(raw=response).dict()

        raise DescribeCollectionException(status.code, status.reason, status.error_code)

    @retry_on_rpc_failure()
    def list_collections(
        self,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.show_collections_request()
        response = self._stub.ShowCollections(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)
        return list(response.collection_names)

    @retry_on_rpc_failure()
    def rename_collections(
        self,
        old_name: str,
        new_name: str,
        new_db_name: str = "",
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=new_name, timeout=timeout)
        check_pass_param(collection_name=old_name)
        if new_db_name:
            check_pass_param(db_name=new_db_name)
        request = Prepare.rename_collections_request(old_name, new_name, new_db_name)
        status = self._stub.RenameCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def create_partition(
        self,
        collection_name: str,
        partition_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(
            collection_name=collection_name, partition_name=partition_name, timeout=timeout
        )
        request = Prepare.create_partition_request(collection_name, partition_name)
        response = self._stub.CreatePartition(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response)

    @retry_on_rpc_failure()
    def drop_partition(
        self,
        collection_name: str,
        partition_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(
            collection_name=collection_name, partition_name=partition_name, timeout=timeout
        )
        request = Prepare.drop_partition_request(collection_name, partition_name)

        response = self._stub.DropPartition(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response)

    @retry_on_rpc_failure()
    def has_partition(
        self,
        collection_name: str,
        partition_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(
            collection_name=collection_name, partition_name=partition_name, timeout=timeout
        )
        request = Prepare.has_partition_request(collection_name, partition_name)
        response = self._stub.HasPartition(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)
        return response.value

    @retry_on_rpc_failure()
    def list_partitions(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.show_partitions_request(collection_name)

        response = self._stub.ShowPartitions(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)
        return list(response.partition_names)

    @retry_on_rpc_failure()
    def get_partition_stats(
        self,
        collection_name: str,
        partition_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        req = Prepare.get_partition_stats_request(collection_name, partition_name)
        response = self._stub.GetPartitionStatistics(
            req, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)
        return response.stats

    @retry_on_rpc_failure()
    @retry_on_schema_mismatch()
    def insert_rows(
        self,
        collection_name: str,
        entities: Union[Dict, List[Dict]],
        partition_name: Optional[str] = None,
        schema: Optional[dict] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = self._prepare_row_insert_request(
            collection_name, entities, partition_name, schema, timeout, context=context, **kwargs
        )
        resp = self._stub.Insert(
            request=request,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        ts_utils.update_collection_ts(
            collection_name,
            resp.timestamp,
            self.server_address,
            (context.get_db_name() if context else ""),
        )
        return MutationResult(resp)

    def _prepare_row_insert_request(
        self,
        collection_name: str,
        entity_rows: Union[List[Dict], Dict],
        partition_name: Optional[str] = None,
        schema: Optional[dict] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if isinstance(entity_rows, dict):
            entity_rows = [entity_rows]

        schema, schema_timestamp = self._get_schema(
            collection_name, timeout=timeout, context=context, **kwargs
        )
        fields_info = schema.get("fields")
        struct_fields_info = schema.get("struct_array_fields", [])  # Default to empty list
        enable_dynamic = schema.get("enable_dynamic_field", False)
        namespace = kwargs.get("namespace")

        return Prepare.row_insert_param(
            collection_name,
            entity_rows,
            partition_name,
            fields_info,
            struct_fields_info,
            enable_dynamic=enable_dynamic,
            schema_timestamp=schema_timestamp,
            namespace=namespace,
        )

    def _get_schema(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> tuple:
        """
        Get collection schema, using cache when available.

        Returns:
            Tuple of (schema_dict, schema_timestamp)
        """
        cache = GlobalCache.schema
        endpoint = self.server_address
        db_name = context.get_db_name() if context else ""

        cached = cache.get(endpoint, db_name, collection_name)
        if cached is not None:
            return cached, cached.get("update_timestamp", 0)

        # Fetch from server and cache
        schema = self.describe_collection(
            collection_name, timeout=timeout, context=context, **kwargs
        )
        cache.set(endpoint, db_name, collection_name, schema)
        return schema, schema.get("update_timestamp", 0)

    def _invalidate_schema(self, collection_name: str, db_name: str = "") -> None:
        """Invalidate cached schema for a collection."""
        GlobalCache.schema.invalidate(self.server_address, db_name, collection_name)

    def _invalidate_db_schemas(self, db_name: str) -> None:
        """Invalidate all cached schemas for a database."""
        GlobalCache.schema.invalidate_db(self.server_address, db_name)

    def _prepare_batch_insert_request(
        self,
        collection_name: str,
        entities: List,
        partition_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        param = kwargs.get("insert_param")
        if param and not isinstance(param, milvus_types.InsertRequest):
            raise ParamError(message="The value of key 'insert_param' is invalid")
        if not isinstance(entities, list):
            raise ParamError(message="'entities' must be a list, please provide valid entity data.")

        schema = kwargs.get("schema")
        if not schema:
            schema = self.describe_collection(
                collection_name, timeout=timeout, context=context, **kwargs
            )

        fields_info = schema["fields"]

        return (
            param
            if param
            else Prepare.batch_insert_param(collection_name, entities, partition_name, fields_info)
        )

    @retry_on_rpc_failure()
    def batch_insert(
        self,
        collection_name: str,
        entities: List,
        partition_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if not check_invalid_binary_vector(entities):
            raise ParamError(message="Invalid binary vector data exists")

        try:
            request = self._prepare_batch_insert_request(
                collection_name, entities, partition_name, timeout, context=context, **kwargs
            )
            rf = self._stub.Insert.future(request, timeout=timeout, metadata=_api_level_md(context))
            if kwargs.get("_async", False):
                cb = kwargs.get("_callback")
                f = MutationFuture(rf, cb, timeout=timeout, **kwargs)
                f.add_callback(
                    ts_utils.update_ts_on_mutation(
                        collection_name,
                        self.server_address,
                        (context.get_db_name() if context else ""),
                    )
                )
                return f

            response = rf.result()
            check_status(response.status)
            m = MutationResult(response)
            ts_utils.update_collection_ts(
                collection_name,
                m.timestamp,
                self.server_address,
                (context.get_db_name() if context else ""),
            )
        except Exception as err:
            if kwargs.get("_async", False):
                return MutationFuture(None, None, err)
            raise
        else:
            return m

    @retry_on_rpc_failure()
    def delete(
        self,
        collection_name: str,
        expression: str,
        partition_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        try:
            req = Prepare.delete_request(
                collection_name=collection_name,
                filter=expression,
                partition_name=partition_name,
                consistency_level=kwargs.pop("consistency_level", 0),
                **kwargs,
            )
            future = self._stub.Delete.future(req, timeout=timeout, metadata=_api_level_md(context))
            if kwargs.get("_async", False):
                cb = kwargs.pop("_callback", None)
                f = MutationFuture(future, cb, timeout=timeout, **kwargs)
                f.add_callback(
                    ts_utils.update_ts_on_mutation(
                        collection_name,
                        self.server_address,
                        (context.get_db_name() if context else ""),
                    )
                )
                return f

            response = future.result()
            check_status(response.status)
            m = MutationResult(response)
            ts_utils.update_collection_ts(
                collection_name,
                m.timestamp,
                self.server_address,
                (context.get_db_name() if context else ""),
            )
        except Exception as err:
            if kwargs.get("_async", False):
                return MutationFuture(None, None, err)
            raise
        else:
            return m

    def _prepare_batch_upsert_request(
        self,
        collection_name: str,
        entities: List,
        partition_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        param = kwargs.get("upsert_param")
        if param and not isinstance(param, milvus_types.UpsertRequest):
            raise ParamError(message="The value of key 'upsert_param' is invalid")
        if not isinstance(entities, list):
            raise ParamError(message="'entities' must be a list, please provide valid entity data.")

        # Extract partial_update parameter from kwargs
        partial_update = kwargs.get("partial_update", False)
        field_ops = kwargs.get("field_ops")

        schema = kwargs.get("schema")
        if not schema:
            schema = self.describe_collection(
                collection_name, timeout=timeout, context=context, **kwargs
            )

        fields_info = schema["fields"]

        return (
            param
            if param
            else Prepare.batch_upsert_param(
                collection_name,
                entities,
                partition_name,
                fields_info,
                partial_update=partial_update,
                field_ops=field_ops,
            )
        )

    @retry_on_rpc_failure()
    def upsert(
        self,
        collection_name: str,
        entities: List,
        partition_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if not check_invalid_binary_vector(entities):
            raise ParamError(message="Invalid binary vector data exists")

        try:
            request = self._prepare_batch_upsert_request(
                collection_name, entities, partition_name, timeout, context=context, **kwargs
            )
            rf = self._stub.Upsert.future(request, timeout=timeout, metadata=_api_level_md(context))
            if kwargs.get("_async", False) is True:
                cb = kwargs.get("_callback")
                f = MutationFuture(rf, cb, timeout=timeout, **kwargs)
                f.add_callback(
                    ts_utils.update_ts_on_mutation(
                        collection_name,
                        self.server_address,
                        (context.get_db_name() if context else ""),
                    )
                )
                return f

            response = rf.result()
            check_status(response.status)
            m = MutationResult(response)
            ts_utils.update_collection_ts(
                collection_name,
                m.timestamp,
                self.server_address,
                (context.get_db_name() if context else ""),
            )
        except Exception as err:
            if kwargs.get("_async", False):
                return MutationFuture(None, None, err)
            raise
        else:
            return m

    def _prepare_row_upsert_request(
        self,
        collection_name: str,
        rows: List,
        partition_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if not isinstance(rows, list):
            raise ParamError(message="'rows' must be a list, please provide valid row data.")

        # Extract partial_update parameter from kwargs
        partial_update = kwargs.get("partial_update", False)
        field_ops = kwargs.get("field_ops")

        schema, schema_timestamp = self._get_schema(
            collection_name, timeout=timeout, context=context, **kwargs
        )
        fields_info = schema.get("fields")
        struct_fields_info = schema.get("struct_array_fields", [])  # Default to empty list
        enable_dynamic = schema.get("enable_dynamic_field", False)
        return Prepare.row_upsert_param(
            collection_name,
            rows,
            partition_name,
            fields_info,
            struct_fields_info,
            enable_dynamic=enable_dynamic,
            schema_timestamp=schema_timestamp,
            partial_update=partial_update,
            field_ops=field_ops,
        )

    @retry_on_rpc_failure()
    @retry_on_schema_mismatch()
    def upsert_rows(
        self,
        collection_name: str,
        entities: List,
        partition_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if isinstance(entities, dict):
            entities = [entities]

        request = self._prepare_row_upsert_request(
            collection_name, entities, partition_name, timeout, context=context, **kwargs
        )
        response = self._stub.Upsert(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response.status)
        m = MutationResult(response)
        ts_utils.update_collection_ts(
            collection_name,
            m.timestamp,
            self.server_address,
            (context.get_db_name() if context else ""),
        )
        return m

    def _execute_search(
        self,
        request: milvus_types.SearchRequest,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        try:
            if kwargs.get("_async", False):
                future = self._stub.Search.future(
                    request,
                    timeout=timeout,
                    metadata=_api_level_md(context),
                )
                func = kwargs.get("_callback")
                return SearchFuture(future, func)

            response = self._stub.Search(request, timeout=timeout, metadata=_api_level_md(context))
            if response is None:
                raise MilvusException(message="Received None response from server during search")
            check_status(response.status)
            round_decimal = kwargs.get("round_decimal", -1)
            return SearchResult(
                response.results,
                round_decimal,
                status=response.status,
                session_ts=response.session_ts,
            )
        except Exception as e:
            if kwargs.get("_async", False):
                return SearchFuture(None, None, e)
            raise

    def _execute_hybrid_search(
        self,
        request: milvus_types.HybridSearchRequest,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        try:
            if kwargs.get("_async", False):
                future = self._stub.HybridSearch.future(
                    request,
                    timeout=timeout,
                    metadata=_api_level_md(context),
                )
                func = kwargs.get("_callback")
                return SearchFuture(future, func)

            response = self._stub.HybridSearch(
                request, timeout=timeout, metadata=_api_level_md(context)
            )
            if response is None:
                raise MilvusException(message="Received None response from server during search")
            check_status(response.status)
            round_decimal = kwargs.get("round_decimal", -1)
            return SearchResult(response.results, round_decimal, status=response.status)

        except Exception as e:
            if kwargs.get("_async", False):
                return SearchFuture(None, None, e)
            raise

    @retry_on_rpc_failure()
    def search(
        self,
        collection_name: str,
        anns_field: str,
        param: Dict,
        limit: int,
        data: Optional[Union[List[List[float]], utils.SparseMatrixInputType]] = None,
        ids: Optional[Union[List[int], List[str], str, int]] = None,
        expression: Optional[str] = None,
        partition_names: Optional[List[str]] = None,
        output_fields: Optional[List[str]] = None,
        round_decimal: int = -1,
        timeout: Optional[float] = None,
        ranker: Union[Function, FunctionScore] = None,
        highlighter: Optional[Highlighter] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if isinstance(ids, (int, str)):
            ids = [ids]
        check_id_and_data(ids, data)

        check_pass_param(
            limit=limit,
            round_decimal=round_decimal,
            anns_field=anns_field,
            partition_name_array=partition_names,
            output_fields=output_fields,
            guarantee_timestamp=kwargs.get("guarantee_timestamp"),
            timeout=timeout,
        )

        use_default_consistency = ts_utils.construct_guarantee_ts(
            collection_name, kwargs, self.server_address, (context.get_db_name() if context else "")
        )

        if (
            not kwargs.get("schema")
            and data is not None
            and len(data) > 0
            and isinstance(data[0], bytes)
        ):
            schema_dict, _ = self._get_schema(
                collection_name, timeout=timeout, context=context, **kwargs
            )
            kwargs["schema"] = schema_dict

        request = Prepare.search_requests_with_expr(
            collection_name=collection_name,
            anns_field=anns_field,
            param=param,
            limit=limit,
            data=data,
            ids=ids,
            expr=expression,
            partition_names=partition_names,
            output_fields=output_fields,
            round_decimal=round_decimal,
            ranker=ranker,
            highlighter=highlighter,
            use_default_consistency=use_default_consistency,
            **kwargs,
        )
        return self._execute_search(
            request, timeout, round_decimal=round_decimal, context=context, **kwargs
        )

    @retry_on_rpc_failure()
    def hybrid_search(
        self,
        collection_name: str,
        reqs: List[AnnSearchRequest],
        rerank: Union[BaseRanker, Function],
        limit: int,
        partition_names: Optional[List[str]] = None,
        output_fields: Optional[List[str]] = None,
        round_decimal: int = -1,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(
            limit=limit,
            round_decimal=round_decimal,
            partition_name_array=partition_names,
            output_fields=output_fields,
            guarantee_timestamp=kwargs.get("guarantee_timestamp"),
            timeout=timeout,
        )

        use_default_consistency = ts_utils.construct_guarantee_ts(
            collection_name, kwargs, self.server_address, (context.get_db_name() if context else "")
        )

        _cached_schema = kwargs.get("schema")
        if not _cached_schema:
            for req in reqs:
                if req.data is not None and len(req.data) > 0 and isinstance(req.data[0], bytes):
                    _cached_schema, _ = self._get_schema(
                        collection_name, timeout=timeout, context=context, **kwargs
                    )
                    break

        requests = []
        for req in reqs:
            # Convert EmbeddingList to flat array if present in the request data
            data = req.data
            req_kwargs = dict(kwargs)
            if isinstance(data, list) and data and isinstance(data[0], EmbeddingList):
                data = [emb_list.to_flat_array() for emb_list in data]
                req_kwargs["is_embedding_list"] = True

            if _cached_schema and not req_kwargs.get("schema"):
                req_kwargs["schema"] = _cached_schema

            search_request = Prepare.search_requests_with_expr(
                collection_name=collection_name,
                data=data,
                anns_field=req.anns_field,
                param=req.param,
                limit=req.limit,
                expr=req.expr,
                partition_names=partition_names,
                round_decimal=round_decimal,
                expr_params=req.expr_params,
                use_default_consistency=use_default_consistency,
                **req_kwargs,
            )
            requests.append(search_request)

        hybrid_search_request = Prepare.hybrid_search_request_with_ranker(
            collection_name,
            requests,
            rerank,
            limit,
            partition_names,
            output_fields,
            round_decimal,
            use_default_consistency=use_default_consistency,
            **kwargs,
        )
        return self._execute_hybrid_search(
            hybrid_search_request, timeout, round_decimal=round_decimal, context=context, **kwargs
        )

    @retry_on_rpc_failure()
    def get_query_segment_info(
        self,
        collection_name: str,
        timeout: float = 30,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> List[milvus_types.QuerySegmentInfo]:
        req = Prepare.get_query_segment_info_request(collection_name)
        response = self._stub.GetQuerySegmentInfo(
            req, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        return response.infos

    @retry_on_rpc_failure()
    def create_alias(
        self,
        collection_name: str,
        alias: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.create_alias_request(collection_name, alias)
        response = self._stub.CreateAlias(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response)

    @retry_on_rpc_failure()
    def drop_alias(
        self,
        alias: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.drop_alias_request(alias)
        response = self._stub.DropAlias(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response)

    @retry_on_rpc_failure()
    def alter_alias(
        self,
        collection_name: str,
        alias: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.alter_alias_request(collection_name, alias)
        response = self._stub.AlterAlias(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response)

    @retry_on_rpc_failure()
    def describe_alias(
        self,
        alias: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(alias=alias, timeout=timeout)
        request = Prepare.describe_alias_request(alias)
        response = self._stub.DescribeAlias(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        ret = {
            "alias": alias,
        }
        if response.collection:
            ret["collection_name"] = response.collection
        if response.db_name:
            ret["db_name"] = response.db_name
        return ret

    @retry_on_rpc_failure()
    def list_aliases(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(timeout=timeout)
        if collection_name:
            check_pass_param(collection_name=collection_name)
        request = Prepare.list_aliases_request(collection_name, kwargs.get("db_name", ""))
        response = self._stub.ListAliases(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response.status)
        ret = {
            "aliases": [],
        }
        if response.collection_name:
            ret["collection_name"] = response.collection_name
        if response.db_name:
            ret["db_name"] = response.db_name
        ret["aliases"].extend(response.aliases)
        return ret

    @retry_on_rpc_failure()
    def create_index(
        self,
        collection_name: str,
        field_name: str,
        params: Dict,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        # for historical reason, index_name contained in kwargs.
        index_name = kwargs.pop("index_name", Config.IndexName)

        _async = kwargs.get("_async", False)
        kwargs["_async"] = False

        index_param = Prepare.create_index_request(
            collection_name, field_name, params, index_name=index_name
        )
        future = self._stub.CreateIndex.future(
            index_param, timeout=timeout, metadata=_api_level_md(context)
        )

        if _async:

            def _check():
                if kwargs.get("sync", True):
                    index_success, fail_reason = self.wait_for_creating_index(
                        collection_name=collection_name,
                        index_name=index_name,
                        timeout=timeout,
                        field_name=field_name,
                        context=context,
                        **kwargs,
                    )
                    if not index_success:
                        raise MilvusException(message=fail_reason)

            index_future = CreateIndexFuture(future)
            index_future.add_callback(_check)
            user_cb = kwargs.get("_callback")
            if user_cb:
                index_future.add_callback(user_cb)
            return index_future

        status = future.result()
        check_status(status)

        if kwargs.get("sync", True):
            index_success, fail_reason = self.wait_for_creating_index(
                collection_name=collection_name,
                index_name=index_name,
                timeout=timeout,
                field_name=field_name,
                context=context,
                **kwargs,
            )
            if not index_success:
                raise MilvusException(message=fail_reason)

        return Status(status.code, status.reason)

    @retry_on_rpc_failure()
    def alter_index_properties(
        self,
        collection_name: str,
        index_name: str,
        properties: dict,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, index_name=index_name, timeout=timeout)
        if properties is None:
            raise ParamError(message="properties should not be None")

        request = Prepare.alter_index_properties_request(collection_name, index_name, properties)
        response = self._stub.AlterIndex(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response)

    @retry_on_rpc_failure()
    def drop_index_properties(
        self,
        collection_name: str,
        index_name: str,
        property_keys: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, index_name=index_name, timeout=timeout)
        request = Prepare.drop_index_properties_request(
            collection_name, index_name, delete_keys=property_keys
        )
        response = self._stub.AlterIndex(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response)

    @retry_on_rpc_failure()
    def list_indexes(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.describe_index_request(collection_name, "")

        response = self._stub.DescribeIndex(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        if is_successful(status):
            return response.index_descriptions
        if status.code == ErrorCode.INDEX_NOT_FOUND or status.error_code == Status.INDEX_NOT_EXIST:
            return []
        raise MilvusException(status.code, status.reason, status.error_code)

    @retry_on_rpc_failure()
    def describe_index(
        self,
        collection_name: str,
        index_name: str,
        timeout: Optional[float] = None,
        timestamp: Optional[int] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.describe_index_request(collection_name, index_name, timestamp=timestamp)

        response = self._stub.DescribeIndex(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        if status.code == ErrorCode.INDEX_NOT_FOUND or status.error_code == Status.INDEX_NOT_EXIST:
            return None
        check_status(status)
        if len(response.index_descriptions) == 1:
            info_dict = {kv.key: kv.value for kv in response.index_descriptions[0].params}
            info_dict["field_name"] = response.index_descriptions[0].field_name
            info_dict["index_name"] = response.index_descriptions[0].index_name
            if info_dict.get("params"):
                info_dict["params"] = orjson.loads(info_dict["params"])
            info_dict["total_rows"] = response.index_descriptions[0].total_rows
            info_dict["indexed_rows"] = response.index_descriptions[0].indexed_rows
            info_dict["pending_index_rows"] = response.index_descriptions[0].pending_index_rows
            info_dict["state"] = common_pb2.IndexState.Name(response.index_descriptions[0].state)
            return info_dict

        raise AmbiguousIndexName(message=ExceptionsMessage.AmbiguousIndexName)

    @retry_on_rpc_failure()
    def get_index_build_progress(
        self,
        collection_name: str,
        index_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.describe_index_request(collection_name, index_name)
        response = self._stub.DescribeIndex(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)
        if len(response.index_descriptions) == 1:
            index_desc = response.index_descriptions[0]
            return {
                "total_rows": index_desc.total_rows,
                "indexed_rows": index_desc.indexed_rows,
                "pending_index_rows": index_desc.pending_index_rows,
                "state": common_pb2.IndexState.Name(index_desc.state),
            }
        raise AmbiguousIndexName(message=ExceptionsMessage.AmbiguousIndexName)

    @retry_on_rpc_failure()
    def get_index_state(
        self,
        collection_name: str,
        index_name: str,
        timeout: Optional[float] = None,
        timestamp: Optional[int] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.describe_index_request(collection_name, index_name, timestamp)
        response = self._stub.DescribeIndex(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)

        if len(response.index_descriptions) == 1:
            index_desc = response.index_descriptions[0]
            return index_desc.state, index_desc.index_state_fail_reason
        # just for create_index.
        field_name = kwargs.pop("field_name", "")
        if field_name != "":
            for index_desc in response.index_descriptions:
                if index_desc.field_name == field_name:
                    return index_desc.state, index_desc.index_state_fail_reason

        raise AmbiguousIndexName(message=ExceptionsMessage.AmbiguousIndexName)

    @retry_on_rpc_failure()
    def wait_for_creating_index(
        self,
        collection_name: str,
        index_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        timestamp = self.alloc_timestamp(context=context)
        start = time.time()
        while True:
            time.sleep(0.5)
            state, fail_reason = self.get_index_state(
                collection_name,
                index_name,
                timeout=timeout,
                timestamp=timestamp,
                context=context,
                **kwargs,
            )
            if state == IndexState.Finished:
                return True, fail_reason
            if state == IndexState.Failed:
                return False, fail_reason
            end = time.time()
            if isinstance(timeout, int) and end - start > timeout:
                msg = (
                    f"collection {collection_name} create index {index_name} timeout in {timeout}s"
                )
                raise MilvusException(message=msg)

    @retry_on_rpc_failure()
    def load_collection(
        self,
        collection_name: str,
        replica_number: Optional[int] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(timeout=timeout)

        request = Prepare.load_collection(collection_name, replica_number, **kwargs)
        response = self._stub.LoadCollection(
            request,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(response)

        if kwargs.get("_async", False):
            return

        self.wait_for_loading_collection(
            collection_name=collection_name,
            is_refresh=request.refresh,
            timeout=timeout,
            context=context,
            **kwargs,
        )

    @retry_on_rpc_failure()
    def load_collection_progress(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        """Return loading progress of collection"""
        progress = self.get_loading_progress(collection_name, timeout=timeout, context=context)
        return {
            "loading_progress": f"{progress:.0f}%",
        }

    @retry_on_rpc_failure()
    def wait_for_loading_collection(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        is_refresh: bool = False,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        start = time.time()

        def can_loop(t: int) -> bool:
            return True if timeout is None else t <= (start + timeout)

        while can_loop(time.time()):
            progress = self.get_loading_progress(
                collection_name,
                is_refresh=is_refresh,
                timeout=timeout,
                context=context,
                **kwargs,
            )
            if progress >= 100:
                return
            time.sleep(Config.WaitTimeDurationWhenLoad)
        raise MilvusException(
            message=f"wait for loading collection timeout, collection: {collection_name}"
        )

    @retry_on_rpc_failure()
    def release_collection(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.release_collection("", collection_name)
        response = self._stub.ReleaseCollection(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response)

    @retry_on_rpc_failure()
    def load_partitions(
        self,
        collection_name: str,
        partition_names: List[str],
        replica_number: Optional[int] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(timeout=timeout)

        request = Prepare.load_partitions(
            collection_name=collection_name,
            partition_names=partition_names,
            replica_number=replica_number,
            **kwargs,
        )
        response = self._stub.LoadPartitions(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response)

        if kwargs.get("sync", True) or not kwargs.get("_async", False):
            self.wait_for_loading_partitions(
                collection_name=collection_name,
                partition_names=partition_names,
                is_refresh=request.refresh,
                timeout=timeout,
                context=context,
                **kwargs,
            )

    @retry_on_rpc_failure()
    def wait_for_loading_partitions(
        self,
        collection_name: str,
        partition_names: List[str],
        timeout: Optional[float] = None,
        is_refresh: bool = False,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        start = time.time()

        def can_loop(t: int) -> bool:
            return True if timeout is None else t <= (start + timeout)

        while can_loop(time.time()):
            progress = self.get_loading_progress(
                collection_name=collection_name,
                partition_names=partition_names,
                timeout=timeout,
                is_refresh=is_refresh,
                context=context,
                **kwargs,
            )
            if progress >= 100:
                return
            time.sleep(Config.WaitTimeDurationWhenLoad)
        raise MilvusException(
            message=f"wait for loading partition timeout, collection: {collection_name}, partitions: {partition_names}"
        )

    @retry_on_rpc_failure()
    def get_loading_progress(
        self,
        collection_name: str,
        partition_names: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        is_refresh: bool = False,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.get_loading_progress(collection_name, partition_names)
        response = self._stub.GetLoadingProgress(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        if is_refresh:
            return response.refresh_progress
        return response.progress

    @retry_on_rpc_failure()
    def create_database(
        self,
        db_name: str,
        properties: Optional[dict] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(db_name=db_name, timeout=timeout)
        request = Prepare.create_database_req(db_name, properties=properties)
        status = self._stub.CreateDatabase(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)

    @retry_on_rpc_failure()
    def drop_database(
        self,
        db_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.drop_database_req(db_name)
        status = self._stub.DropDatabase(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(status)

    @retry_on_rpc_failure()
    def list_database(
        self, timeout: Optional[float] = None, context: Optional[CallContext] = None, **kwargs
    ):
        check_pass_param(timeout=timeout)
        request = Prepare.list_database_req()
        response = self._stub.ListDatabases(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        return list(response.db_names)

    @retry_on_rpc_failure()
    def alter_database(
        self,
        db_name: str,
        properties: dict,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.alter_database_properties_req(db_name, properties)
        status = self._stub.AlterDatabase(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(status)

    @retry_on_rpc_failure()
    def drop_database_properties(
        self,
        db_name: str,
        property_keys: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.drop_database_properties_req(db_name, property_keys)
        status = self._stub.AlterDatabase(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(status)

    @retry_on_rpc_failure()
    def describe_database(
        self,
        db_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.describe_database_req(db_name=db_name)
        resp = self._stub.DescribeDatabase(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(resp.status)
        return DatabaseInfo(resp).to_dict()

    @retry_on_rpc_failure()
    def get_load_state(
        self,
        collection_name: str,
        partition_names: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.get_load_state(collection_name, partition_names)
        response = self._stub.GetLoadState(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        return LoadState(response.state)

    @retry_on_rpc_failure()
    def load_partitions_progress(
        self,
        collection_name: str,
        partition_names: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        """Return loading progress of partitions"""
        progress = self.get_loading_progress(
            collection_name, partition_names, timeout, context=context, **kwargs
        )
        return {
            "loading_progress": f"{progress:.0f}%",
        }

    @retry_on_rpc_failure()
    def release_partitions(
        self,
        collection_name: str,
        partition_names: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(
            collection_name=collection_name, partition_name_array=partition_names, timeout=timeout
        )
        request = Prepare.release_partitions("", collection_name, partition_names)
        response = self._stub.ReleasePartitions(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response)

    @retry_on_rpc_failure()
    def get_collection_stats(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        index_param = Prepare.get_collection_stats_request(collection_name)
        response = self._stub.GetCollectionStatistics(
            index_param, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)
        return response.stats

    @retry_on_rpc_failure()
    def get_flush_state(
        self,
        segment_ids: List[int],
        collection_name: str,
        flush_ts: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.get_flush_state_request(segment_ids, collection_name, flush_ts)
        response = self._stub.GetFlushState(req, timeout=timeout, metadata=_api_level_md(context))
        status = response.status
        check_status(status)
        return response.flushed

    @retry_on_rpc_failure()
    def get_persistent_segment_infos(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> List[milvus_types.PersistentSegmentInfo]:
        req = Prepare.get_persistent_segment_info_request(collection_name)
        response = self._stub.GetPersistentSegmentInfo(
            req, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        return response.infos

    def _wait_for_flushed(
        self,
        segment_ids: List[int],
        collection_name: str,
        flush_ts: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        flush_ret = False
        start = time.time()
        while not flush_ret:
            flush_ret = self.get_flush_state(
                segment_ids, collection_name, flush_ts, timeout, context=context, **kwargs
            )
            end = time.time()
            if timeout is not None and end - start > timeout:
                raise MilvusException(
                    message=f"wait for flush timeout, collection: {collection_name}, flusht_ts: {flush_ts}"
                )

            if not flush_ret:
                time.sleep(0.5)

    @retry_on_rpc_failure(initial_back_off=1)
    def flush(
        self,
        collection_names: list,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if collection_names in (None, []) or not isinstance(collection_names, list):
            raise ParamError(message="Collection name list can not be None or empty")

        check_pass_param(timeout=timeout)
        for name in collection_names:
            check_pass_param(collection_name=name)

        request = Prepare.flush_param(collection_names)
        future = self._stub.Flush.future(request, timeout=timeout, metadata=_api_level_md(context))
        response = future.result()
        check_status(response.status)

        def _check():
            for collection_name in collection_names:
                segment_ids = future.result().coll_segIDs[collection_name].data
                flush_ts = future.result().coll_flush_ts[collection_name]
                self._wait_for_flushed(
                    segment_ids, collection_name, flush_ts, timeout=timeout, context=context
                )

        if kwargs.get("_async", False):
            flush_future = FlushFuture(future)
            flush_future.add_callback(_check)

            user_cb = kwargs.get("_callback")
            if user_cb:
                flush_future.add_callback(user_cb)

            return flush_future

        _check()
        return None

    @retry_on_rpc_failure()
    def drop_index(
        self,
        collection_name: str,
        field_name: str,
        index_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(collection_name=collection_name, timeout=timeout)
        request = Prepare.drop_index_request(collection_name, field_name, index_name)
        response = self._stub.DropIndex(request, timeout=timeout, metadata=_api_level_md(context))
        check_status(response)

    @retry_on_rpc_failure()
    def dummy(
        self,
        request_type: Any,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.dummy_request(request_type)
        return self._stub.Dummy(request, timeout=timeout, metadata=_api_level_md(context))

    @retry_on_rpc_failure()
    def query(
        self,
        collection_name: str,
        expr: str,
        output_fields: Optional[List[str]] = None,
        partition_names: Optional[List[str]] = None,
        timeout: Optional[float] = None,
        strict_float32: bool = False,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        if output_fields is not None and not isinstance(output_fields, (list,)):
            raise ParamError(message="Invalid query format. 'output_fields' must be a list")

        use_default_consistency = ts_utils.construct_guarantee_ts(
            collection_name, kwargs, self.server_address, (context.get_db_name() if context else "")
        )

        request = Prepare.query_request(
            collection_name,
            expr,
            output_fields,
            partition_names,
            use_default_consistency=use_default_consistency,
            **kwargs,
        )

        response = self._stub.Query(request, timeout=timeout, metadata=_api_level_md(context))
        if Status.EMPTY_COLLECTION in {response.status.code, response.status.error_code}:
            return []
        check_status(response.status)

        num_fields = len(response.fields_data)
        # check has fields
        if num_fields == 0:
            raise MilvusException(message="No fields returned")

        # check if all lists are of the same length
        it = iter(response.fields_data)
        num_entities = len_of(next(it))
        if not all(len_of(field_data) == num_entities for field_data in it):
            raise MilvusException(message="The length of fields data is inconsistent")

        _, dynamic_fields = entity_helper.extract_dynamic_field_from_result(response)

        keys = [field_data.field_name for field_data in response.fields_data]
        filtered_keys = [k for k in keys if k != "$meta"]
        template = dict.fromkeys(filtered_keys)
        results = [template.copy() for _ in range(num_entities)]
        lazy_field_data = []
        for field_data in response.fields_data:
            lazy_extracted = entity_helper.extract_row_data_from_fields_data_v2(field_data, results)
            if lazy_extracted:
                lazy_field_data.append(field_data)

        extra_dict = get_extra_info(response.status)
        extra_dict[ITERATOR_SESSION_TS_FIELD] = response.session_ts
        return HybridExtraList(
            lazy_field_data,
            results,
            extra=extra_dict,
            dynamic_fields=dynamic_fields,
            strict_float32=strict_float32,
        )

    @retry_on_rpc_failure()
    def load_balance(
        self,
        collection_name: str,
        src_node_id: int,
        dst_node_ids: List[int],
        sealed_segment_ids: List[int],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.load_balance_request(
            collection_name, src_node_id, dst_node_ids, sealed_segment_ids
        )
        status = self._stub.LoadBalance(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(status)

    @retry_on_rpc_failure()
    def compact(
        self,
        collection_name: str,
        is_clustering: Optional[bool] = False,
        is_l0: Optional[bool] = False,
        target_size: Optional[int] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> int:
        # try with only collection_name
        req = Prepare.manual_compaction(
            collection_name=collection_name,
            is_clustering=is_clustering,
            is_l0=is_l0,
            target_size=target_size,
        )
        response = self._stub.ManualCompaction(
            req, timeout=timeout, metadata=_api_level_md(context)
        )
        if response.status.error_code == common_pb2.CollectionNameNotFound:
            # should be removed, but to be compatible with old milvus server, keep it for now.
            request = Prepare.describe_collection_request(collection_name)
            response = self._stub.DescribeCollection(
                request, timeout=timeout, metadata=_api_level_md(context)
            )
            check_status(response.status)

            req = Prepare.manual_compaction(
                collection_name=collection_name,
                is_clustering=is_clustering,
                is_l0=is_l0,
                collection_id=response.collectionID,
                target_size=target_size,
            )
            response = self._stub.ManualCompaction(
                req, timeout=timeout, metadata=_api_level_md(context)
            )
        check_status(response.status)
        return response.compactionID

    @retry_on_rpc_failure()
    def get_compaction_state(
        self,
        compaction_id: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> CompactionState:
        req = Prepare.get_compaction_state(compaction_id)
        response = self._stub.GetCompactionState(
            req, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)

        return CompactionState(
            compaction_id,
            State.new(response.state),
            response.executingPlanNo,
            response.timeoutPlanNo,
            response.completedPlanNo,
        )

    @retry_on_rpc_failure()
    def wait_for_compaction_completed(
        self,
        compaction_id: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        start = time.time()
        while True:
            time.sleep(0.5)
            compaction_state = self.get_compaction_state(
                compaction_id, timeout, context=context, **kwargs
            )
            if compaction_state.state == State.Completed:
                return True
            if compaction_state == State.UndefiedState:
                return False
            end = time.time()
            if timeout is not None and end - start > timeout:
                raise MilvusException(
                    message=f"get compaction state timeout, compaction id: {compaction_id}"
                )

    @retry_on_rpc_failure()
    def get_compaction_plans(
        self,
        compaction_id: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> CompactionPlans:
        req = Prepare.get_compaction_state_with_plans(compaction_id)

        response = self._stub.GetCompactionStateWithPlans(
            req, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)

        cp = CompactionPlans(compaction_id, response.state)

        cp.plans = [Plan(m.sources, m.target) for m in response.mergeInfos]

        return cp

    @retry_on_rpc_failure()
    def get_replicas(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> Replica:
        collection_id = self.describe_collection(
            collection_name, timeout, context=context, **kwargs
        )["collection_id"]

        req = Prepare.get_replicas(collection_id)
        response = self._stub.GetReplicas(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(response.status)

        groups = []
        for replica in response.replicas:
            shards = [
                Shard(s.dm_channel_name, s.node_ids, s.leaderID) for s in replica.shard_replicas
            ]
            groups.append(
                Group(
                    replica.replicaID,
                    shards,
                    replica.node_ids,
                    replica.resource_group_name,
                    replica.num_outbound_node,
                )
            )

        return Replica(groups)

    @retry_on_rpc_failure()
    def describe_replica(
        self,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> List[ReplicaInfo]:
        collection_id = self.describe_collection(
            collection_name, timeout, context=context, **kwargs
        )["collection_id"]

        req = Prepare.get_replicas(collection_id)
        response = self._stub.GetReplicas(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(response.status)

        groups = []
        for replica in response.replicas:
            shards = [
                Shard(s.dm_channel_name, s.node_ids, s.leaderID) for s in replica.shard_replicas
            ]
            groups.append(
                ReplicaInfo(
                    replica.replicaID,
                    shards,
                    replica.node_ids,
                    replica.resource_group_name,
                    replica.num_outbound_node,
                )
            )

        return groups

    @retry_on_rpc_failure()
    def do_bulk_insert(
        self,
        collection_name: str,
        partition_name: str,
        files: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> int:
        req = Prepare.do_bulk_insert(collection_name, partition_name, files, **kwargs)
        response = self._stub.Import(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(response.status)
        if len(response.tasks) == 0:
            raise MilvusException(
                ErrorCode.UNEXPECTED_ERROR,
                "no task id returned from server",
                common_pb2.UnexpectedError,
            )
        return response.tasks[0]

    @retry_on_rpc_failure()
    def get_bulk_insert_state(
        self,
        task_id: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> BulkInsertState:
        req = Prepare.get_bulk_insert_state(task_id)
        resp = self._stub.GetImportState(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp.status)
        return BulkInsertState(
            task_id, resp.state, resp.row_count, resp.id_list, resp.infos, resp.create_ts
        )

    @retry_on_rpc_failure()
    def list_bulk_insert_tasks(
        self,
        limit: int,
        collection_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> list:
        req = Prepare.list_bulk_insert_tasks(limit, collection_name)
        resp = self._stub.ListImportTasks(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp.status)

        return [
            BulkInsertState(t.id, t.state, t.row_count, t.id_list, t.infos, t.create_ts)
            for t in resp.tasks
        ]

    @retry_on_rpc_failure()
    def create_user(
        self,
        user: str,
        password: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        description: Optional[str] = None,
        **kwargs,
    ):
        check_pass_param(user=user, password=password, timeout=timeout)
        req = Prepare.create_user_request(user, password, description=description)
        resp = self._stub.CreateCredential(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp)

    @retry_on_rpc_failure()
    def update_password(
        self,
        user: str,
        old_password: str,
        new_password: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        description: Optional[str] = None,
        **kwargs,
    ):
        req = Prepare.update_password_request(
            user, old_password, new_password, description=description
        )
        resp = self._stub.UpdateCredential(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp)

    @retry_on_rpc_failure()
    def update_user(
        self,
        user: str,
        description: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.update_password_request(user, "", "", description=description)
        resp = self._stub.UpdateCredential(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp)

    @retry_on_rpc_failure()
    def delete_user(
        self,
        user: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.delete_user_request(user)
        resp = self._stub.DeleteCredential(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp)

    @retry_on_rpc_failure()
    def list_usernames(
        self, timeout: Optional[float] = None, context: Optional[CallContext] = None, **kwargs
    ):
        req = Prepare.list_usernames_request()
        resp = self._stub.ListCredUsers(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp.status)
        return resp.usernames

    @retry_on_rpc_failure()
    def create_role(
        self,
        role_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        description: str = "",
        **kwargs,
    ):
        req = Prepare.create_role_request(role_name, description)
        resp = self._stub.CreateRole(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def alter_role(
        self,
        role_name: str,
        description: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.alter_role_request(role_name, description)
        resp = self._stub.AlterRole(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def drop_role(
        self,
        role_name: str,
        force_drop: bool = False,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.drop_role_request(role_name, force_drop=force_drop)
        resp = self._stub.DropRole(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def add_user_to_role(
        self,
        username: str,
        role_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_user_role_request(
            username, role_name, milvus_types.OperateUserRoleType.AddUserToRole
        )
        resp = self._stub.OperateUserRole(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def remove_user_from_role(
        self,
        username: str,
        role_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_user_role_request(
            username, role_name, milvus_types.OperateUserRoleType.RemoveUserFromRole
        )
        resp = self._stub.OperateUserRole(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def select_one_role(
        self,
        role_name: str,
        include_user_info: bool,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.select_role_request(role_name, include_user_info)
        resp = self._stub.SelectRole(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return RoleInfo(resp.results)

    @retry_on_rpc_failure()
    def select_all_role(
        self,
        include_user_info: bool,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.select_role_request(None, include_user_info)
        resp = self._stub.SelectRole(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return RoleInfo(resp.results)

    @retry_on_rpc_failure()
    def select_one_user(
        self,
        username: str,
        include_role_info: bool,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.select_user_request(username, include_role_info)
        resp = self._stub.SelectUser(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return UserInfo(resp.results)

    @retry_on_rpc_failure()
    def select_all_user(
        self,
        include_role_info: bool,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.select_user_request(None, include_role_info)
        resp = self._stub.SelectUser(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return UserInfo(resp.results)

    @retry_on_rpc_failure()
    def grant_privilege(
        self,
        role_name: str,
        object: str,
        object_name: str,
        privilege: str,
        db_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_privilege_request(
            role_name,
            object,
            object_name,
            privilege,
            db_name,
            milvus_types.OperatePrivilegeType.Grant,
        )
        resp = self._stub.OperatePrivilege(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def revoke_privilege(
        self,
        role_name: str,
        object: str,
        object_name: str,
        privilege: str,
        db_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_privilege_request(
            role_name,
            object,
            object_name,
            privilege,
            db_name,
            milvus_types.OperatePrivilegeType.Revoke,
        )
        resp = self._stub.OperatePrivilege(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def grant_privilege_v2(
        self,
        role_name: str,
        privilege: str,
        collection_name: str,
        db_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_privilege_v2_request(
            role_name,
            privilege,
            milvus_types.OperatePrivilegeType.Grant,
            db_name,
            collection_name,
        )
        resp = self._stub.OperatePrivilegeV2(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def revoke_privilege_v2(
        self,
        role_name: str,
        privilege: str,
        collection_name: str,
        db_name: Optional[str] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_privilege_v2_request(
            role_name,
            privilege,
            milvus_types.OperatePrivilegeType.Revoke,
            db_name,
            collection_name,
        )
        resp = self._stub.OperatePrivilegeV2(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def select_grant_for_one_role(
        self,
        role_name: str,
        db_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.select_grant_request(role_name, None, None, db_name)
        resp = self._stub.SelectGrant(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return GrantInfo(resp.entities)

    @retry_on_rpc_failure()
    def select_grant_for_role_and_object(
        self,
        role_name: str,
        object: str,
        object_name: str,
        db_name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.select_grant_request(role_name, object, object_name, db_name)
        resp = self._stub.SelectGrant(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return GrantInfo(resp.entities)

    @retry_on_rpc_failure()
    def get_server_version(
        self,
        timeout: Optional[float] = None,
        detail: bool = False,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> Union[str, dict]:
        if detail:
            if self._server_info_cache is None:
                req = Prepare.register_request("", "")
                resp = self._stub.Connect(request=req, timeout=timeout)
                check_status(resp.status)
                info = resp.server_info
                self._server_info_cache = {
                    "version": info.build_tags,
                    "build_time": info.build_time,
                    "git_commit": info.git_commit,
                    "go_version": info.go_version,
                    "deploy_mode": info.deploy_mode,
                }
            return self._server_info_cache
        req = Prepare.get_server_version()
        resp = self._stub.GetVersion(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp.status)
        return resp.version

    @retry_on_rpc_failure()
    def create_resource_group(
        self,
        name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.create_resource_group(name, **kwargs)
        resp = self._stub.CreateResourceGroup(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def update_resource_groups(
        self,
        configs: Mapping[str, ResourceGroupConfig],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.update_resource_groups(configs)
        resp = self._stub.UpdateResourceGroups(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def drop_resource_group(
        self,
        name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.drop_resource_group(name)
        resp = self._stub.DropResourceGroup(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def list_resource_groups(
        self, timeout: Optional[float] = None, context: Optional[CallContext] = None, **kwargs
    ):
        req = Prepare.list_resource_groups()
        resp = self._stub.ListResourceGroups(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return list(resp.resource_groups)

    @retry_on_rpc_failure()
    def describe_resource_group(
        self,
        name: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> ResourceGroupInfo:
        req = Prepare.describe_resource_group(name)
        resp = self._stub.DescribeResourceGroup(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return ResourceGroupInfo(resp.resource_group)

    @retry_on_rpc_failure()
    def transfer_node(
        self,
        source: str,
        target: str,
        num_node: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.transfer_node(source, target, num_node)
        resp = self._stub.TransferNode(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def transfer_replica(
        self,
        source: str,
        target: str,
        collection_name: str,
        num_replica: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.transfer_replica(source, target, collection_name, num_replica)
        resp = self._stub.TransferReplica(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def get_flush_all_state(
        self,
        flush_all_ts: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.get_flush_all_state_request(flush_all_ts, kwargs.get("db", ""))
        response = self._stub.GetFlushAllState(
            req, timeout=timeout, metadata=_api_level_md(context)
        )
        status = response.status
        check_status(status)
        return response.flushed

    def _wait_for_flush_all(
        self,
        flush_all_ts: int,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        flush_ret = False
        start = time.time()
        while not flush_ret:
            flush_ret = self.get_flush_all_state(flush_all_ts, timeout, context=context, **kwargs)
            end = time.time()
            if timeout is not None and end - start > timeout:
                raise MilvusException(
                    message=f"wait for flush all timeout, flush_all_ts: {flush_all_ts}"
                )

            if not flush_ret:
                time.sleep(5)

    @retry_on_rpc_failure()
    def flush_all(
        self,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        request = Prepare.flush_all_request(kwargs.get("db", ""))
        future = self._stub.FlushAll.future(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        response = future.result()
        check_status(response.status)

        def _check():
            self._wait_for_flush_all(response.flush_all_ts, timeout, context=context, **kwargs)

        if kwargs.get("_async", False):
            flush_future = FlushFuture(future)
            flush_future.add_callback(_check)

            user_cb = kwargs.get("_callback")
            if user_cb:
                flush_future.add_callback(user_cb)

            return flush_future

        _check()
        return None

    def _internal_register(
        self,
        user: str,
        host: str,
        stub: Optional[milvus_pb2_grpc.MilvusServiceStub] = None,
        **kwargs,
    ) -> int:
        target_stub = stub if stub is not None else self._stub
        req = Prepare.register_request(user, host, **self._connect_reserved)
        response = target_stub.Connect(request=req, timeout=kwargs.get("timeout"))
        check_status(response.status)
        return response.identifier

    @upgrade_reminder
    def __internal_register(self, user: str, host: str, **kwargs) -> int:
        return self._internal_register(user, host, **kwargs)

    @retry_on_rpc_failure()
    @ignore_unimplemented(0)
    def alloc_timestamp(
        self,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ) -> int:
        request = milvus_types.AllocTimestampRequest()
        response = self._stub.AllocTimestamp(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        return response.timestamp

    @retry_on_rpc_failure()
    def create_privilege_group(
        self,
        privilege_group: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.create_privilege_group_req(privilege_group)
        resp = self._stub.CreatePrivilegeGroup(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def drop_privilege_group(
        self,
        privilege_group: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.drop_privilege_group_req(privilege_group)
        resp = self._stub.DropPrivilegeGroup(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def list_privilege_groups(
        self, timeout: Optional[float] = None, context: Optional[CallContext] = None, **kwargs
    ):
        req = Prepare.list_privilege_groups_req()
        resp = self._stub.ListPrivilegeGroups(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp.status)
        return PrivilegeGroupInfo(resp.privilege_groups)

    @retry_on_rpc_failure()
    def add_privileges_to_group(
        self,
        privilege_group: str,
        privileges: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_privilege_group_req(
            privilege_group, privileges, milvus_types.OperatePrivilegeGroupType.AddPrivilegesToGroup
        )
        resp = self._stub.OperatePrivilegeGroup(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def remove_privileges_from_group(
        self,
        privilege_group: str,
        privileges: List[str],
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        req = Prepare.operate_privilege_group_req(
            privilege_group,
            privileges,
            milvus_types.OperatePrivilegeGroupType.RemovePrivilegesFromGroup,
        )
        resp = self._stub.OperatePrivilegeGroup(
            req,
            wait_for_ready=True,
            timeout=timeout,
            metadata=_api_level_md(context),
        )
        check_status(resp)

    @retry_on_rpc_failure()
    def run_analyzer(
        self,
        texts: Union[str, List[str]],
        analyzer_params: Optional[Union[str, Dict]] = None,
        with_hash: bool = False,
        with_detail: bool = False,
        collection_name: Optional[str] = None,
        field_name: Optional[str] = None,
        analyzer_names: Optional[Union[str, List[str]]] = None,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        check_pass_param(timeout=timeout)
        req = Prepare.run_analyzer(
            texts,
            analyzer_params=analyzer_params,
            with_hash=with_hash,
            with_detail=with_detail,
            collection_name=collection_name,
            field_name=field_name,
            analyzer_names=analyzer_names,
        )
        resp = self._stub.RunAnalyzer(req, timeout=timeout, metadata=_api_level_md(context))
        check_status(resp.status)

        if isinstance(texts, str):
            return AnalyzeResult(resp.results[0], with_hash, with_detail)
        return [AnalyzeResult(result, with_hash, with_detail) for result in resp.results]

    @retry_on_rpc_failure()
    def update_replicate_configuration(
        self,
        clusters: Optional[List[Dict]] = None,
        cross_cluster_topology: Optional[List[Dict]] = None,
        force_promote: bool = False,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        """
        Update replication configuration across Milvus clusters.

        Args:
            clusters: List of cluster configurations to apply
            cross_cluster_topology: List of cross-cluster topology relationships to apply
            force_promote: If true, force promote the current cluster to primary
            timeout: An optional duration of time in seconds to allow for the RPC
            **kwargs: Additional arguments

        Returns:
            Status: The status of the operation
        """
        request = Prepare.update_replicate_configuration_request(
            clusters=clusters,
            cross_cluster_topology=cross_cluster_topology,
            force_promote=force_promote,
        )

        status = self._stub.UpdateReplicateConfiguration(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(status)
        return status

    @retry_on_rpc_failure()
    def get_replicate_configuration(
        self,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        """
        Get replication configuration from Milvus.

        Args:
            timeout: An optional duration of time in seconds to allow for the RPC
            **kwargs: Additional arguments

        Returns:
            ReplicateConfiguration: The current replication configuration
        """
        request = milvus_types.GetReplicateConfigurationRequest()
        response = self._stub.GetReplicateConfiguration(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        check_status(response.status)
        return response.configuration

    @retry_on_rpc_failure()
    def get_replicate_info(
        self,
        source_cluster_id: str,
        target_pchannel: str,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        """
        Get the replication checkpoint that this (typically secondary) cluster
        has recorded for a given source cluster and source pchannel.

        Args:
            source_cluster_id: ID of the source cluster.
            target_pchannel: NOTE this is the SOURCE cluster's pchannel name.
                The proto field naming is historical and misleading; the value
                expected here is the pchannel belonging to source_cluster_id.
            timeout: Optional RPC timeout in seconds.

        Returns:
            dict with two keys, each a dict or None:
              - "checkpoint": current replication position
              - "salvage_checkpoint": last-known position from a prior force_promote
        """
        request = Prepare.get_replicate_info_request(
            source_cluster_id=source_cluster_id,
            target_pchannel=target_pchannel,
        )
        resp = self._stub.GetReplicateInfo(
            request, timeout=timeout, metadata=_api_level_md(context)
        )
        return {
            "checkpoint": replicate_checkpoint_to_dict(
                resp.checkpoint if resp.HasField("checkpoint") else None
            ),
            "salvage_checkpoint": replicate_checkpoint_to_dict(
                resp.salvage_checkpoint if resp.HasField("salvage_checkpoint") else None
            ),
        }

    # NOTE: no @retry_on_rpc_failure — retrying a streaming RPC would replay
    # already-yielded messages, and errors surface during iteration, not at call time.
    def dump_messages(
        self,
        pchannel: str,
        start_message_id: Dict,
        start_timetick: int = 0,
        end_timetick: int = 0,
        timeout: Optional[float] = None,
        context: Optional[CallContext] = None,
        **kwargs,
    ):
        """
        Dump messages from a WAL range for data salvage (server-streaming RPC).

        Args:
            pchannel: Physical channel name to dump from.
            start_message_id: Start position in WAL, a dict {"id": str, "wal_name": str}.
                Accepts get_replicate_info()["salvage_checkpoint"]["message_id"] directly.
            start_timetick: Only dump messages with timetick >= start_timetick. 0 = no filter.
            end_timetick: Only dump messages with timetick <= end_timetick.
                0 = no limit; the server streams until the RPC is cancelled.
            timeout: Optional timeout in seconds applied to the entire stream.

        Returns:
            A generator yielding one dict per message:
            {"message_id": {"id": str, "wal_name": str} or None,
             "payload": bytes, "properties": dict}.

        Raises:
            ParamError: If pchannel or start_message_id is missing/invalid (at call time).
            MilvusException: If the server reports an error (during iteration).
        """
        request = Prepare.dump_messages_request(
            pchannel=pchannel,
            start_message_id=start_message_id,
            start_timetick=start_timetick,
            end_timetick=end_timetick,
        )
        stream = self._stub.DumpMessages(request, timeout=timeout, metadata=_api_level_md(context))

        def _message_generator():
            for resp in stream:
                which = resp.WhichOneof("response")
                if which == "status":
                    check_status(resp.status)
                elif which == "message":
                    yield immutable_message_to_dict(resp.message)
                else:
                    msg = f"unexpected DumpMessagesResponse oneof arm: {which!r}"
                    raise MilvusException(message=msg)

        return _message_generator()
